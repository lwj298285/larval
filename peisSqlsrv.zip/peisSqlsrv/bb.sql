USE [PEIS999]
GO
/****** Object:  Table [dbo].[peis_TJJLB]    Script Date: 05/10/2017 10:09:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[peis_TJJLB](
	[xh] [int] NULL,
	[tjbh] [varchar](14) NOT NULL,
	[tjcs] [int] NOT NULL,
	[lxbh] [varchar](6) NULL,
	[xj] [varchar](500) NULL,
	[ydtjrq] [varchar](12) NULL,
	[jcrq] [varchar](12) NULL,
	[jcys] [int] NULL,
	[zhxmid] [int] NULL,
	[xmlx] [tinyint] NULL,
	[sj] [decimal](8, 2) NULL,
	[dzbl] [decimal](8, 2) NULL,
	[jsover] [tinyint] NULL,
	[jsfs] [tinyint] NULL,
	[charged] [tinyint] NULL,
	[jsr] [varchar](6) NULL,
	[jsrq] [varchar](12) NULL,
	[sjh] [varchar](14) NULL,
	[sflb] [varchar](4) NULL,
	[czy] [varchar](6) NULL,
	[czsj] [varchar](12) NULL,
	[sfjz] [tinyint] NULL,
	[dyyjsb] [varchar](4) NULL,
	[zxks] [varchar](6) NULL,
	[jyys] [varchar](10) NULL,
	[hospitalid] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[peis_TJDJB]    Script Date: 05/10/2017 10:09:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[peis_TJDJB](
	[tjbh] [varchar](14) NOT NULL,
	[tjcs] [int] NOT NULL,
	[xm] [varchar](40) NOT NULL,
	[xm_pym] [varchar](6) NULL,
	[mz] [int] NULL,
	[xb] [tinyint] NULL,
	[nl] [int] NULL,
	[jmfs] [int] NULL,
	[tcid] [int] NULL,
	[fzid] [int] NULL,
	[dwid] [int] NULL,
	[tjrq] [varchar](12) NOT NULL,
	[djrq] [varchar](12) NOT NULL,
	[djry] [varchar](6) NOT NULL,
	[zs] [text] NULL,
	[jy] [text] NULL,
	[jcrq] [int] NULL,
	[jcys] [varchar](6) NULL,
	[gdyq] [int] NULL,
	[gdys] [varchar](6) NULL,
	[sfzh] [varchar](18) NULL,
	[zc] [varchar](16) NULL,
	[zw] [varchar](16) NULL,
	[tjlb] [tinyint] NULL,
	[rylb] [tinyint] NULL,
	[hyzk] [tinyint] NULL,
	[fzfs] [tinyint] NULL,
	[fzbh] [int] NULL,
	[jg] [decimal](8, 2) NULL,
	[sj] [decimal](8, 2) NULL,
	[jsfs] [tinyint] NULL,
	[yybh] [char](16) NULL,
	[sumover] [tinyint] NOT NULL,
	[depart] [varchar](64) NULL,
	[djlsh] [varchar](5) NULL,
	[rybh] [varchar](50) NULL,
	[address] [varchar](128) NULL,
	[phone] [varchar](32) NULL,
	[bmid] [int] NULL,
	[sjcxxh] [varchar](12) NULL,
	[fcrq] [int] NULL,
	[fcrqend] [int] NULL,
	[fcts] [int] NULL,
	[fcgy] [varchar](64) NULL,
	[tjbz] [tinyint] NULL,
	[fzrq] [int] NULL,
	[picture] [varchar](255) NULL,
	[bzr] [char](12) NULL,
	[csnyr] [varchar](12) NULL,
	[gzrq] [varchar](12) NULL,
	[jcsj] [varchar](4) NULL,
	[gz] [varchar](20) NULL,
	[gh] [varchar](20) NULL,
	[yhys] [varchar](24) NULL,
	[whcd] [tinyint] NULL,
	[zdyj] [varchar](50) NULL,
	[sftz] [tinyint] NULL,
	[tzqk] [tinyint] NULL,
	[tzr] [char](12) NULL,
	[yf] [int] NULL,
	[dycs] [int] NULL,
	[dysj] [int] NULL,
	[dyrxm] [varchar](10) NULL,
	[mobile] [varchar](15) NULL,
	[ywlx] [int] NULL,
	[ywlb] [int] NULL,
	[email] [varchar](50) NULL,
	[sv_callback] [tinyint] NULL,
	[sv_sms] [tinyint] NULL,
	[sv_email] [tinyint] NULL,
	[nldw] [int] NULL,
	[zk] [int] NULL,
	[sv_web] [tinyint] NULL,
	[tjpc] [varchar](29) NULL,
	[codeprintdate] [int] NULL,
	[jycode] [varchar](10) NULL,
	[tzrq] [varchar](12) NULL,
	[tznr] [varchar](100) NULL,
	[tjrylxmc] [varchar](20) NULL,
	[sendmessdate] [int] NULL,
	[sendmesstxt] [varchar](50) NULL,
	[inputcs_id] [varchar](20) NULL,
	[sfrq] [int] NULL,
	[sfryxm] [varchar](50) NULL,
	[fphm] [varchar](50) NULL,
	[sendzt] [int] NOT NULL,
	[fplsh] [varchar](50) NULL,
	[zhid] [varchar](50) NULL,
	[sfzj] [tinyint] NOT NULL,
	[sfdzj] [tinyint] NOT NULL,
	[yddprintdate] [int] NULL,
	[yddprintczyxm] [varchar](50) NULL,
	[xb1] [char](4) NULL,
	[hylb] [varchar](100) NULL,
	[fbgr] [varchar](20) NULL,
	[lbgr] [varchar](20) NULL,
	[lqsj] [int] NULL,
	[bz] [varchar](100) NULL,
	[ypjg] [decimal](8, 2) NULL,
	[jdbz] [int] NULL,
	[qjtag] [tinyint] NULL,
	[hospitalid] [int] NOT NULL,
	[delete_time] [int] NULL,
 CONSTRAINT [PK_TJ_TJDJB] PRIMARY KEY CLUSTERED 
(
	[hospitalid] ASC,
	[tjbh] ASC,
	[tjcs] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Default [DF_peis_TJDJB_tcid]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF_peis_TJDJB_tcid]  DEFAULT ((0)) FOR [tcid]
GO
/****** Object:  Default [DF_peis_TJDJB_fzid]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF_peis_TJDJB_fzid]  DEFAULT ((0)) FOR [fzid]
GO
/****** Object:  Default [DF__peis_TJDJB__dwid__56B3DD81]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF__peis_TJDJB__dwid__56B3DD81]  DEFAULT ((0)) FOR [dwid]
GO
/****** Object:  Default [DF__peis_TJDJB__tjlb__57A801BA]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF__peis_TJDJB__tjlb__57A801BA]  DEFAULT ((0)) FOR [tjlb]
GO
/****** Object:  Default [DF__peis_TJDJ__sumov__589C25F3]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF__peis_TJDJ__sumov__589C25F3]  DEFAULT ((0)) FOR [sumover]
GO
/****** Object:  Default [DF_peis_TJDJB_sendzt]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF_peis_TJDJB_sendzt]  DEFAULT ((0)) FOR [sendzt]
GO
/****** Object:  Default [DF__peis_TJDJB__sfzj__59904A2C]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF__peis_TJDJB__sfzj__59904A2C]  DEFAULT ((0)) FOR [sfzj]
GO
/****** Object:  Default [DF__peis_TJDJ__sfdzj__5A846E65]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF__peis_TJDJ__sfdzj__5A846E65]  DEFAULT ((0)) FOR [sfdzj]
GO
/****** Object:  Default [DF_peis_TJDJB_jdbz]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF_peis_TJDJB_jdbz]  DEFAULT ((0)) FOR [jdbz]
GO
/****** Object:  Default [DF__peis_TJDJ__qjtag__5B78929E]    Script Date: 05/10/2017 10:09:03 ******/
ALTER TABLE [dbo].[peis_TJDJB] ADD  CONSTRAINT [DF__peis_TJDJ__qjtag__5B78929E]  DEFAULT ((1)) FOR [qjtag]
GO
