<?php

namespace com;

use mikkle\tp_wechat\support\Exception;
use think\db;
use think\db\connector;
use \Imagick;

class Datainterface
{
	/**
	 * [ 数据提取接口]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */

	/*protected $url="";
    protected $host="";
    protected $interface="";*/

    public $url="";
    public $host="";
    public $interface="";
    public static  $interfaceDb="";



    public function __get($vname)
    {
        return $this->$vname;
    }

    public  function  __set($vname,$value)
    {
       $this->$vname=$value;
      }

    public function  __call($name, $arguments)
    {
       // TODO: Implement __call() method.
    }







    public function __construct($url=null,$interface=null)
    {

        if ($url!=null) {
            $this->url = $url;
        }else{
            $this->host=Model('XtcsModel')->where('mc','sjjkdz')->value('value');
            $this->interface=$interface;
            $this->url=$this->host."interfacemanager/publicexecutor/33783DE1-040A-4B42-8C97-A6FD5CE8A4F8/". $this->interface;

        }

    }


    public function index(){

		return $this->fetch();

	}


  /* open_interface_db
     连接其他数据源
     $type,      数据库类型  支持mssql mysql  oracle
     $hostname,  数据库名称
     $database,  数据库名称
     $uid,       数据库登录名
     $pwd,       数据库登录密码
     $port       数据库端口号
  */

	 public  static function open_interface_db($type,$hostname,$database,$uid,$pwd,$port){

        try {

            self::$interfaceDb = Db::connect(
                [
                    'type' => $type,   // 'mysql',	     // 数据库类型
                    'hostname' => encrypt($hostname, 'E'),// 'q4HSifNZzX6p4gsYoVZF/G0',      // 服务器地址
                    'database' => encrypt($database, 'E'),// '+NLd2qICyCq16AEK9AcT',         // 数据库名
                    'username' => encrypt($uid, 'E'),// '+NLd2qICyCq16AEK9AcT',	        // 用户名
                    'password' => encrypt($pwd, 'E'),//'NXciKYLn373vl1I+wwe7ncr304',  // 密码
                    'hostport' => $port,// '3306',	         // 端口
                    'dsn' => '',                 // 连接dsn
                    'params' => [],                 // 数据库连接参数
                    'charset' => 'utf8',             // 数据库编码默认采用utf8
                    'prefix' => '',// '',	             // 数据库表前缀
                    'debug' => true,                 // 数据库调试模式
                    'deploy' => 0,                     // 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
                    'rw_separate' => false,             // 数据库读写是否分离 主从式有效
                    'master_num' => 1,                 // 读写分离后 主服务器数量
                    'slave_no' => '',                 // 指定从服务器序号
                    'fields_strict' => true,             // 是否严格检查字段是否存在
                    'resultset_type' => 'array',             // 数据集返回类型 array 数组 collection Collection对象
                    'auto_timestamp' => false,             // 是否自动写入时间戳字段
                    'sql_explain' => false,             // 是否需要进行SQL性能分析
                ]
            );
        }catch (\Exception $e){
            return $e->getMessage();

        }

           return self::$interfaceDb;

    }


    public function ftp_image($url){
       /**
        * 用cURL从FTP服务器上下载文件
        */

        //初始化
        $ch=curl_init();
        //文件的准确路径url
        curl_setopt($ch,CURLOPT_URL,"ftp://192.168.151.126/wwwroot/test.jpg");
        //不输出head头文件
        curl_setopt($ch,CURLOPT_HEADER,0);
        //执行后不打印
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        //重点来了
        //设置超时时间
        curl_setopt($ch,CURLOPT_TIMEOUT,300);
        //设置ftp服务器的账号密码，分号前是账号后面是密码
        curl_setopt($ch,CURLOPT_USERPWD,"abc:abc");
        //既然是要下载，在本地就需要先打开一个文件，用来接收下载的值
        //创建一个句柄
        $outfile=fopen('123456.jpg','wb');
        //把下载的数据存入这个句柄
        curl_setopt($ch,CURLOPT_FILE,$outfile);
        //执行这个文件
        $rtn=curl_exec($ch);
        //关闭句柄
        fclose($outfile);
        curl_close($ch);

    }



    public function ftp_file($ftpHost,$ftpPort,$ftpUser,$ftpPwd,$path,$fileSavePath)
    {


        $ch = curl_init();//初始化
        //传入ftp的目标文件，如'ftp://192.168.3.1/test/1.jpg'
        curl_setopt($ch, CURLOPT_URL, "ftp://" . $ftpHost . ":" . $ftpPort . "/" . $path);
        curl_setopt($ch, CURLOPT_HEADER, 0);//不输出header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);    //需要response header
        curl_setopt($ch, CURLOPT_NOBODY, FALSE);    //需要response body
        //time out after 300s
        curl_setopt($ch, CURLOPT_TIMEOUT, 2000);//超时时间
        //通过这个函数设置ftp的用户名和密码,没设置就不需要!
        curl_setopt($ch, CURLOPT_USERPWD, $ftpUser . ':' . $ftpPwd);

        $outfile = fopen($fileSavePath, 'w+'); //保存到本地文件的文件名
        curl_setopt($ch, CURLOPT_FILE, $outfile);

        $rtn = curl_exec($ch);
        if (curl_errno($ch)) {
            //writeLog('Curl error: ' . curl_error($ch));
        }
        fclose($outfile);
        curl_close($ch);
        if ($rtn == 1) {
            return true;
        } else {
            unlink($fileSavePath);//如果下载失败，但是本地open了这个文件，所以要删除
            return false;
        }


    }


   /*http_post_json
     接口调用 requset POST json字符串 respnose JSON字符
    $data_string  传递参数
    $url          $接口地址
   */
    public function http_post_json( $data_string=null,$url=null) {

        if ($url!=null)
            $this->url=$url;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);//参数设置，是否显示头部信息，1为显示，0为不显示
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//执行结果是否被返回，0不返回，1返回
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $this->url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "Content-Type:  application/json; charset=utf-8",    //text/html
                "Content-Length: " . strlen($data_string))
        );


       // ob_start( );

        //写入缓冲区
        //curl_exec($ch);
        $return_content =curl_exec($ch);//ob_get_contents(); //读缓冲区 ;
       // ob_end_clean(); //清理关闭缓冲区
       // $rtn = curl_exec($ch);
       //在入库的时候可以使用addslashes()函数处理一下字符串，给引号前加上斜杠。被改的字符包括单引号 (')、双引号 (")、反斜线 backslash (\) 以及空字符NULL。
        //return json(json_decode(stripslashes($return_content),true))
        //return json_decode(stripslashes($return_content));
       // return  ICONV('UTF-8','GB2312',$return_content);
       // mb_convert_encoding("妳係我的友仔", "UTF-8", "UTF-8");

        if (curl_errno($ch))
            return json(['resultCode'=>'faile','result'=>'','message'=>curl_error($ch)]);


        curl_close($ch);





        //print_r($return_content);
        return json_decode($return_content) ;// return stripslashes;  addslashes()




    }


    //接口调用 POST文件
   public  function http_post_form(array $data){


        // $params= input('post.');
        $file= $_FILES["inputfile"];//['name'];//$_FILE['file'];//request()->file('file');

        $data=array('text'=>input('text'),'file'=> new \CURLFile($file['tmp_name'],$file['type'],$file['name']));


        //初始化
        $ch = curl_init();
        //设置变量
        curl_setopt($ch, CURLOPT_URL, "http://192.168.0.111:8080/iexchange/interfacemanager/publicexecutor/filetransfer");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);//执行结果是否被返回，0是返回，1是不返回
        curl_setopt($ch, CURLOPT_HEADER, 0);//参数设置，是否显示头部信息，1为显示，0为不显示
        curl_setopt($ch, CURLOPT_REFERER, "http://192.168.0.111:8080/iexchange/interfacemanager/publicexecutor/filetransfer");
        //表单数据，是正规的表单设置值为非0
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);//设置curl执行超时时间最大是多少
        //使用数组提供post数据时，CURL组件大概是为了兼容@filename这种上传文件的写法，
        //默认把content_type设为了multipart/form-data。虽然对于大多数web服务器并
        //没有影响，但是还是有少部分服务器不兼容。本文得出的结论是，在没有需要上传文件的
        //情况下，尽量对post提交的数据进行http_build_query，然后发送出去，能实现更好的兼容性，更小的请求数据包。
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_INFILESIZE,$file['size']);
        // curl_setopt($ch,CURLOPT_FILE, $file);
        // 这个文件是你传送过来的输入文件。
        //执行并获取结果
       // ob_start();
        $output = curl_exec($ch);
        if($output === FALSE)
        {
            echo "<br/>","cUrl Error:".curl_error($ch);
        }
        //    释放cURL句柄
        //ob_end_clean();
        curl_close($ch);



    }



    /* pdf_dcm_toimage
    静态方法pdf和dcm转图片 PDF一页一张图片
    $sourceFile,      源文件路径
    $savePath,        转换后保存路径
    $saveType='jpg',  默认保存为JPG格式图片
    $page=-1          默认转换所有PDF页 DCM不用管
    */
    public static function  filetojpg($sourceFile,$savePath,$billno,$saveType='jpg',$page=-1)
    {


        try {

            if (!extension_loaded('imagick')) {
                return false;
            }

            if (!file_exists($savePath)) {
                //检查是否有该文件夹，如果没有就创建，并给予最高权限
                mkdir($savePath, 0700);
            }

            if (!file_exists($sourceFile)) {
                return false;
            }

            $im = new Imagick();
            $im->setResolution(100, 100);
            $im->setCompressionQuality(100);

            if ($page == -1)
                $im->readImage($sourceFile);
            else
                $im->readImage($sourceFile . "[" . $page . "]");

            foreach ($im as $Key => $Var) {
                $Var->setImageFormat('jpeg');
                $filename = $savePath . $billno . '@' . microtime() . '.' . $saveType;
                if ($Var->writeImage($filename) == true) {
                    $Return[] = $filename;
                }
            }


            return ['code' => 1, 'msg' => 'ok'];

        }catch (\Exception $e){

            return ['code'=>-1,'msg'=>$e->getMessage()];
        }


    }



   /*base64转文件(图片 pdf   DCM)
     $base64code  BASE64 编码
     $savePath    转为文件保存路径
   */
   public static function  base64tofile($base64code,$savePath){

      header('Content-type:text/html;charset=utf-8');
      // $base64_image_content = $_POST['imgBase64'];

      //匹配出图片的格式(jpg--jpeg---png  都存为jpg)
       if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64code, $result) ){  //
           $type = $result[2];


           if(!file_exists($savePath))
           {
             //检查是否有该文件夹，如果没有就创建，并给予最高权限
               mkdir($savePath, 0700);
           }
           $new_file = $savePath.time().".jpeg";

           if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $base64code)))){
               echo '新文件保存成功：', $new_file;
           }else{
               echo '新文件保存失败';
           }
       }


       //匹配pdf格式文件
       if (preg_match('/^(data:\s*application\/(pdf);base64,)/', $base64code, $result) ){  //	application/pdf
           $type = $result[2];

           if(!file_exists($savePath))
           {
               //检查是否有该文件夹，如果没有就创建，并给予最高权限
               mkdir($savePath, 0700);
           }
           $new_file = $savePath.time().".pdf";

           if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $base64code)))){

               self::filetojpg($new_file,$savePath,'jpg');
               @unlink($new_file);
               echo '新文件保存成功：', $new_file;

           }else{
               echo '新文件保存失败';
           }


       }



       //匹配dcm格式文件

       if (preg_match('/^(data:\s*application\/(dcm);base64,)/', $base64code, $result) ){
           $type = $result[2];


           if(!file_exists($savePath))
           {
             //检查是否有该文件夹，如果没有就创建，并给予最高权限
               mkdir($savePath, 0700);

           }
           $new_file = $savePath.time().".{$type}";

           if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $base64code)))){
               self::filetojpg($new_file,$savePath,'jpg');
               @unlink($new_file);
               echo '新文件保存成功：', $new_file;
           }else{
               echo '新文件保存失败';
           }
       }


   }





    /*  base64tojpg
   静态方法pdf和dcm 图片 base64 转图片文件 PDF一页一张图片
   $basecode,        base64编码
   $savePath,        转换后保存路径
   $billno           条码号
   $saveType='jpg',  默认保存为JPG格式图片
   $page=-1          默认转换所有PDF页 DCM不用管
  base64 编码由 blob ebase64_encode 转 所以用base64_decode转回 blob
   */
    public static function  base64tojpg($basecode,$savePath,$billno,$saveType='jpg',$page=-1)
    {

        try {

            if (empty($basecode)) {
                return ['code' => 0, 'file' => ''];
            }

            if (!file_exists($savePath)) {
                //检查是否有该文件夹，如果没有就创建，并给予最高权限
                mkdir($savePath, 0700, true);
            }

            $im = new Imagick();
            $im->setResolution(100, 100);
            $im->setComression(Imagick::COMPRESSION_JPEG);
            $im->setCompressionQuality(1);


            $img_array = explode('@', $basecode);

            foreach ($img_array as $key => $value){

                if (empty($value))
                   continue;


                if ($page == -1)
                    $im->readImageBlob(base64_decode($value));
                else
                    $im->readImageBlob(base64_decode($value) . "[" . $page . "]");

                foreach ($im as $Key => $Var) {
                    $Var->setImageFormat('jpeg');
                    // $filename = $savePath . $Key . time() . '.' . $saveType;
                    $filename = $savePath . $billno . '@' . microtime() . '.' . $saveType;
                    if ($Var->writeImage($filename) == true)
                       continue;
                       // return ['code' => 1, 'file' => $filename];
                    else
                        throw new \Exception();
                }
           }

            return ['code' => 1, 'msg' => 'ok'];

        }catch ( \Exception $e){

           // self::delete_file($savePath,$billno.'@');

            return ['code'=>-1,'msg'=>$e->getMessage()];
        }


    }






    /*  base64tojpg
   静态方法pdf和dcm 图片 base64 转图片文件 PDF一页一张图片
   $basecode,        base64编码
   $savePath,        转换后保存路径
   $billno           条码号
   $saveType='jpg',  默认保存为JPG格式图片
   $page=-1          默认转换所有PDF页 DCM不用管
  base64 编码由 blob ebase64_encode 转 所以用base64_decode转回 blob
   */
    public static function  tmp_base64tojpg($basecode,$savePath,$billno,$saveType='jpg',$page=-1)
    {

        try {

            if (empty($basecode)) {
                return ['code' => 0, 'file' => ''];
            }

            if (!file_exists($savePath)) {
                //检查是否有该文件夹，如果没有就创建，并给予最高权限
                mkdir($savePath, 0700, true);
            }

            $im = new Imagick();
            $im->setResolution(100, 100);
            $im->setComression(Imagick::COMPRESSION_JPEG);
            $im->setCompressionQuality(1);



            if ($page == -1)
                $im->readImageBlob(base64_decode($basecode));
            else
                $im->readImageBlob(base64_decode($basecode) . "[" . $page . "]");

            foreach ($im as $Key => $Var) {
                $Var->setImageFormat('jpeg');
                // $filename = $savePath . $Key . time() . '.' . $saveType;
                $filename = $savePath . $billno . '@' . microtime() . '.' . $saveType;
                if ($Var->writeImage($filename) == true)
                    continue;
                // return ['code' => 1, 'file' => $filename];
                else
                    throw new \Exception();
            }


            return ['code' => 1, 'msg' => 'ok'];

        }catch ( \Exception $e){

            // self::delete_file($savePath,$billno.'@');

          
            return ['code'=>-1,'msg'=>$e->getMessage()];
        }


    }


    /*streamtojpg
      静态方法 二进制流dcm ，pdf，图片转图片文件  PDF一页一张图片
      $contents 二进制数据流内容
       $saveType='jpg',  默认保存为JPG格式图片
       $page=-1          默认转换所有PDF页 DCM不用管
      contents 数据库blob ->bin2hex 所以用hex2bin 转为blob
    */
    public static function streamtojpg($contents,$savePath,$saveType='jpg',$page=-1)
    {


        /*fread stream (stream to content->blob)  fopen stream (stream to content->blob)  fcontents string* blob */

        try {

            if (empty($contents)) {
                return ['code'=>0,'file'=>''];
            }


            if(!file_exists($savePath))
            {
                //检查是否有该文件夹，如果没有就创建，并给予最高权限
                mkdir($savePath, 0700,true);

            }

            $im = new Imagick();
            //$im->readImageBlob( hex2bin( $contents));
            //echo "<br>".$im->getImagesBlob();
            //echo "<br>".$im->getImageMimeType();

            $im->setResolution(100, 100);
            $im->setComression(Imagick::COMPRESSION_JPEG);
            $im->setCompressionQuality(1);

            if ($page == -1)
                $im->readImageBlob(hex2bin($contents));
            else
                $im->readImageBlob(hex2bin($contents) . "[" . $page . "]");


            foreach ($im as $Key => $Var) {
                $Var->setImageFormat('jpeg');
                $filename = $savePath.$Key.time().'.'.$saveType;
                if ($Var->writeImage($filename) == true)
                    return ['code'=>1,'file'=> $filename];
                else
                    throw new \Exception();

            }
        }catch(\Exception $e){

            return ['code'=>-1,'file'=> $e->getMessage()];

        }


    }




 public static function delete_file($dir,$filestr){

        $list = scandir($dir); // 得到该文件下的所有文件和文件夹
        foreach($list as $file){//遍历
            $file_location=$dir."/".$file;//生成路径
            if(is_dir($file_location) && $file!="." &&$file!=".."){ //判断是不是文件夹
                delete_file($file_location); //继续遍历
            }else if($file!="."&&$file!=".."){
               // $str = "s";//指定字符串

                if(substr_count($file,$filestr)>0){//如果文件名包含该字符串
                    unlink($dir."/".$file);
                }
            }
        }
    }





/************按时间顺序输出文件夹中的文件******************/

   public static function find_dir_jpg($imagepath, $billno) {


           try {
               if (!file_exists($imagepath)) {
                   //检查是否有该文件夹，如果没有就创建，并给予最高权限
                   mkdir($imagepath, 0700, true);
                   return ['code'=>1,'data'=> [],'msg'=>'ok'];
               }


               //没传递条码号,调取所有报告

               if (empty($billno))
                    $fileList = glob($imagepath .'*.jpg');
               else
                    $fileList = glob($imagepath . $billno . '@*.jpg');


               if (count($fileList)<1)
                   return ['code'=>1,'data'=> [],'msg'=>'ok'];

               foreach ($fileList as $key=>$value) {
                   $filetime [] = date("Y-m-d H:i:s", filectime($value));
                   $return [] = $value;
               }

              //文件件按创建时间排序


               array_multisort($filetime, SORT_ASC, SORT_STRING, $return);//按时间排序

               $basecode_array=[];

               foreach ($return as $key=>$value) {


                   $basecode=self::base64EncodeImage($value);

                   $basecode_data=["pid"=>$key,"src"=>$basecode];

                   //,"thumb"=> self::resizeImage($value,300,600,Imagick::FILTER_LANCZOS,1,1,false)]
                   array_push($basecode_array, $basecode_data);

               }

               $image_array=["title"=> "影像报告", //相册标题
                                 "id"=>'billno_xybg', //相册id
                                 "start"=> 0, //初始显示的图片序号，默认0
                                 "data"=> $basecode_array
                            ];

               //array_push( $image_array['data'],$basecode_array);

               return ['code'=>1,'data'=> $image_array,'msg'=>'ok'];
              // return $return; // 返回文件

          }catch (\Exception $e){

               return ['code'=>0,'data'=>[],'msg'=>$e->getMessage()];

           }

    }



    //图片文件转base64
   public static function base64EncodeImage ($image_file) {


           $base64_image = '';
           $image_info = getimagesize($image_file);
           $image_data = fread(fopen($image_file, 'r'), filesize($image_file));
           $base64_image = 'data:' . $image_info['mime'] . ';base64,' . chunk_split(base64_encode($image_data));
           return $base64_image;

       }



     //缩放图片
    public static function resizeImage($imagePath, $width, $height, $filterType, $blur, $bestFit, $cropZoom) {
        //The blur factor where &gt; 1 is blurry, &lt; 1 is sharp.
        $imagick = new \Imagick(realpath($imagePath));

        $imagick->resizeImage($width, $height, $filterType, $blur, $bestFit);

        $cropWidth = $imagick->getImageWidth();
        $cropHeight = $imagick->getImageHeight();

        if ($cropZoom) {
            $newWidth = $cropWidth / 2;
            $newHeight = $cropHeight / 2;

            $imagick->cropimage(
                $newWidth,
                $newHeight,
                ($cropWidth - $newWidth) / 2,
                ($cropHeight - $newHeight) / 2
            );

            $imagick->scaleimage(
                $imagick->getImageWidth() * 4,
                $imagick->getImageHeight() * 4
            );
        }


       /* header("Content-Type: image/jpg");
        echo $imagick->getImageBlob();*/
        $base64_image = 'data:image/jpeg;base64,' . chunk_split(base64_encode($imagick->getImageBlob()));
        return $base64_image;



    }



}


