<?php



namespace download;

class download{
    protected $_filename;
    protected $_filepath;
    protected $_filesize;//文件大小
    protected $_savefile;//文件大小
    public function __construct($filename,$savepath,$savefile){
        $this->_filename=$filename;
        $this->_filepath=$savepath.$filename;
        $this->_savefile=$savefile;
    }
    //获取文件名
    public function getfilename(){
        return $this->_filename;
    }
    //获取文件路径（包含文件名）
    public function getfilepath(){
        return $this->_filepath;
    }
    //获取文件路径（包含文件名）
    public function getsavefile(){
        return $this->_savefile;
    }
    //获取文件大小
    public function getfilesize(){
        return $this->_filesize=number_format(filesize($this->_filepath)/(1024*1024),2);//去小数点后两位
    }
    //下载文件的功能
    public function getfiles()
    {

        try {
        $file = DOWNLOAD_PATH . $this->_filename;

        if (!file_exists($file)) {
            echo "文件不存在";
            exit();
            //return json(['code'=> 0,'data'=> '','msg'=>'文件不存在']);
        }
        $file_size = filesize($file);
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length:" . $file_size);
        header("Content-Disposition: attachment; filename=" . $fs);
        $fp = fopen($file, "r");
        if (!$fp){
            echo "文件无法打开";
            exit();
        }


        // return json(['code'=> 0,'data'=> '','msg'=>'文件不能打开']);

        $buffer_size = 1024;
        $cur_pos = 0;
        while (!feof($fp) && $file_size - $cur_pos > $buffer_size) {
            $buffer = fread($fp, $buffer_size);
            echo $buffer;
            $cur_pos += $buffer_size;
        }
        $buffer = fread($fp, $file_size - $cur_pos);
        echo $buffer;
        fclose($fp);
    }catch (Exception $e){

        echo "下载文件错误，请联系管理员！";

    }




        }




}
