INSERT INTO [PEIS999].[dbo].[peis_admin]
           ([id]
           ,[jobnum]
           ,[username]
           ,[sex]
           ,[idcard]
           ,[password]
           ,[mobile]
           ,[email]
           ,[loginnum]
           ,[last_login_ip]
           ,[last_login_time]
           ,[job]
           ,[jobtitle]
           ,[usertype]
           ,[real_name]
           ,[status]
           ,[groupid]
           ,[hospitalid]
           ,[isdel])
     VALUES
           (<id, int,>
           ,<jobnum, varchar(25),>
           ,<username, varchar(50),>
           ,<sex, tinyint,>
           ,<idcard, varchar(20),>
           ,<password, varchar(255),>
           ,<mobile, varchar(15),>
           ,<email, varchar(100),>
           ,<loginnum, int,>
           ,<last_login_ip, varchar(30),>
           ,<last_login_time, int,>
           ,<job, varchar(20),>
           ,<jobtitle, varchar(20),>
           ,<usertype, tinyint,>
           ,<real_name, varchar(255),>
           ,<status, int,>
           ,<groupid, int,>
           ,<hospitalid, int,>
           ,<isdel, tinyint,>)
GO

