<?php

return [

    'type'           => 'Sqlsrv',	     // 数据库类型
    //明文
    /* 'hostname'       => 'localhost',     // 服务器地址
     'database'       => 'peis999',    // 数据库名
     'username'       => 'peis999',	         // 用户名
     'password'       => '2351624anmas',	         // 密码*/
    //加密信息
    'hostname'       => 'q4HSifNZzX6p4gsYoVZF/G0',     // 服务器地址
    'database'       => '+NLd2qICyCq16AEK9AcT',  // 数据库名
    'username'       => 'roLa3PZenXv8tFE',	         // 用户名
    'password'       => '/NXciKYLn373vl1I+wwe7ncr304',     // 密码*/

//encrypt(str,'D'(E))
    'hostport'       => '1433',	         // 端口
    'dsn'            => '',	             // 连接dsn
    'params'         => [],	             // 数据库连接参数
    'charset'        => 'utf8',	         // 数据库编码默认采用utf8
    'prefix'         => 'peis_',	     // 数据库表前缀
    'debug'          => true,	         // 数据库调试模式
    'deploy'         => 0,	             // 数据库部署方式:0 集中式(单一服务器),1 分布式(主从服务器)
    'rw_separate'    => false,	         // 数据库读写是否分离 主从式有效
    'master_num'     => 1,	             // 读写分离后 主服务器数量
    'slave_no'       => '',	             // 指定从服务器序号
    'fields_strict'  => true,	         // 是否严格检查字段是否存在
    'resultset_type' => 'array',	     // 数据集返回类型 array 数组 collection Collection对象
    //'resultset_type' => 'collection',
    'auto_timestamp' => false,	         // 是否自动写入时间戳字段  
    'sql_explain'    => false,	         // 是否需要进行SQL性能分析
];
