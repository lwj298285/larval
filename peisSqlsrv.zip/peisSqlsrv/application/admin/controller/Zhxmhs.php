<?php

namespace app\admin\controller;
use app\admin\model\ZhxmhsModel;
use think\Db;
use think\exception\PDOException;


class Zhxmhs extends Base

{
    /**
     * [index 组合项目函数]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){


        $zhxmid = input('param.zhxmid');
        $tjlxid = input('param.tjlxid');

       // $zhxmitem=db('zhxm_dt as dt,peis_tjxm as xm')->field('id,mc')
      //           ->where(['dt.zhxmid'=>$zhxmid,'dt.tjxmid'=>['EXP','=xm.id'],'xm.isdel'=>1])->select();

        //组合项目所在科室诊断
        $zdlist=Model('XjjyModel')->field('id,zyzd')->where(['tjlxid'=>$tjlxid,'isdel'=>1])->select();

        //组合项目小项
        $zhxmitem=db('zhxm_dt as dt,peis_tjxm as xm')->field("convert(varchar(50),id)+'-'+convert(varchar(50),jglx) as id,mc")
            ->where(['dt.zhxmid'=>$zhxmid,'dt.tjxmid'=>['EXP','=xm.id'],'xm.isdel'=>1])->select();

        // 组合项目函数诊断条件
      //  $zhcondtion=ZhxmhsModel::where(['zhxmid'=>$zhxmid,'isdel'=>1,'hospitalid'=>session('hospitalid')])->select();


        $this->assign('zhxmitem', $zhxmitem);
        $this->assign('zdlist', $zdlist);
        $this->assign('zhxmid',  $zhxmid);
      //  $this->assign('zhcondtion', $zhcondtion);
        $this->assign('tjlxid', $tjlxid);
        $this->assign('zhxmid',$zhxmid);



        return $this->fetch();


    }



    public function editZhxmhs(){


        if(request()->isAjax()) { //ajax 提交

            if (request()->isPost()) { // 判断提交方式 post为 更新和新增


                $param = input('post.',null,null);
                $param['hospitalid']=session('hospitalid');

                $flag=Model('ZhxmhsModel')->zhxmhsEdit($param);

                return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);


            }
        }


    }




    /**
     * [delZhxmhs 删除'删除组合项目函数诊断条件]
     * @param $zhxmid组合项目ID ,$id组合条件ID
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function delZhxmhs($zhxmid,$id)
    {

        if(request()->isAjax()) { //ajax 提交

            Db::startTrans();
            try {


                $result = Model('ZhxmhsModel')->where(['zhxmid' => $zhxmid, 'id' => $id, 'hospitalid' => session('hospitalid')])->setField('isdel', 0);

                if ($result == false) {
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除组合项目函数诊断条件zhxmid=' . $zhxmid . ',id=' . $id . '失败', 2);
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => '删除组合项目函数诊断条件失败'];
                } else {
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除组合项目函数诊断条件zhxmid=' . $zhxmid . ',id=' . $id . '成功', 1);
                    Db::commit();
                    return ['code' => 1, 'data' => '', 'msg' => '删除组合项目函数诊断条件成功'];
                }
            } catch (PDOException $e) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }

        }
    }



    /**
     * [delZhxmhs 删除'删除组合项目函数诊断条件]
     * @param $zhxmid组合项目ID ,$id组合条件ID
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function getZhxmhs()
    {

        if(request()->isAjax()) { //ajax 提交


            $zhxmid=input('param.zhxmid');
            $result = Model('ZhxmhsModel')->alias('hs')->join('xjjy jy','hs.zdid=jy.id')
                                             ->field('hs.*,jy.zyzd,jy.jynr')
                                            -> where(['zhxmid' => $zhxmid, 'hs.isdel'=>1,'hospitalid' => session('hospitalid')])
                                            ->select();
            return(json($result));


        }
    }





}