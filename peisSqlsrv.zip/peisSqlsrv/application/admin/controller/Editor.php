<?php

namespace app\admin\controller;
use org\Formdesign;
use app\admin\model\EditorModel;
class Editor extends Base
{


	/**
	 * [Editor 编辑器]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function index()
	{

		return $this->fetch();

		
		
	}



    public function editTemple(){

        if (request()->isAjax()) {

            $param = input('post.',null,null);
            $parseform=$param['parse_form'];
            $param['fields']=$parseform['fields'];
            $param['content']=$parseform['template'];
            $param['parse']=$parseform['parse'];
            $param['data']=$parseform['data'];
            $param['add_fields']=$parseform['add_fields'];

           // $editor =new EditorModel();
            //$editor->templeEdit($param);

           // $formdesign = new \Formdesign;


         /*   $parse_content = $formdesign->parse_form($_POST['design_content'],$one['fields']);

            //print_R($parse_content);exit;

            $design_content = $formdesign->unparse_form(array(
                'content_parse'=>$parse_content['parse'],
                'content_data'=>serialize($parse_content['data']),//保存后是 serialize，所以这里也一样
            ),array(),array('action'=>'preview'));


            $this->assign('design_content',$design_content);
            $this->display();*/



           print_r($param);

        }

    }


    public function preview()
    {

        $formdesign = new Formdesign;


       // $parse_content = $formdesign->parse_form($_POST['design_content'],$one['fields']);
        $parse_content = $formdesign->parse_form($_POST['design_content'],3);

        //print_R($parse_content);exit;

        $design_content = $formdesign->unparse_form(array(
            'content_parse'=>$parse_content['parse'],
            'content_data'=>serialize($parse_content['data']),//保存后是 serialize，所以这里也一样
        ),array(),array('action'=>'preview'));


        $this->assign('design_content',$design_content);
        $this->display();


    }


}