<?php
namespace app\admin\controller;
use app\admin\model\TjdjModel;
use think\console\command\make\Model;
use think\Db;
use think\Config;
use think\exception\PDOException;

class Yszj extends Base
{
    public function index()
    {

        $this->assign('admins', Model('UserModel')->where(['isdel&status' => 1, 'hospitalid' => session('hospitalid')])->select());
        $this->assign('jbzd', Model('JbzdModel')->where('isdel', 1)->whereIn('dictype', "TJBZ,BLJKZ")->select());
        $this->assign('tjlx',Model('DepartmentModel')->where('isdel&status', 1)->select());
        $mb=Model('ReportglModel')->field('id,mbmc,mbfile,mbcs')
            ->where(['hospitalid'=>session('hospitalid'),'name'=>config('bblx')['ZJBG'],'isdefault&isdel'=>1])
            ->find();
        $this->assign('zjbgid', false!= $mb?$mb->id:"");
        $this->assign('zjbgmbfile', false!= $mb?$mb->mbfile:"");
        $this->assign('zjbgmbcs', false!= $mb?$mb->mbcs:"");

       return $this->fetch();

    }

    //总检记录添加，更新
    public function zjEdit()
    {
        if (request()->isAjax()) {
            if (request()->isPost()) {
                $param = input('post.');
                $flag = Model('TjdjModel')->editZj($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
            }
        } else {

        }
    }

    //取消总检生成
    public function zjDelete(){
        if(request()->isAjax()){
            $tjbh=input('param.tjbh');
            $tjcs=input('param.tjcs');
            $flag=Model('TjdjModel')->deleteZj($tjbh,$tjcs);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }
    }

//获取总检医生更新，添加，结论信息
    public function getZjinfo()
    {
        if (request()->isAjax()) {
            try {

                $tjbh = input('param.tjbh');
                $tjcs = input('param.tjcs');
                $jdbz = input('param.jdbz');
                $result = Db::name('tjdjb')->where(['tjbh' => $tjbh, 'tjcs' => $tjcs, 'jdbz' => $jdbz, 'hospitalid' => session('hospitalid')])->find();

                return json(['code' => 1, 'data' => $result, 'msg' => 'OK']);
            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }
        }
    }

    //科室下诊断记录列表
    public function getZdjl()
    {
        if (request()->isAjax()) {
            try {
                $tjcs = input('param.tjcs');
                $tjbh = input('param.tjbh');

                $result = Model('TjjlbModel')->alias('lb')
                    ->join('tjjlmxb xmb', 'xmb.xh=lb.xh and xmb.zhxmid=lb.zhxmid  and xmb.hospitalid=lb.hospitalid and sfyx=1')
                    ->join('tjxm xm', 'xmb.xmid=xm.id ')
                    ->join('cjjg jg','xmb.jgid=jg.id ')->join('xjjy jy','jg.zdid=jy.id ')
                    ->field('xmid,xm.tjlxid,xmb.jg,zyzd,xmb.jcys,xm.mc')
                    ->where(['tjbh' => $tjbh, 'tjcs' => $tjcs, 'lb.hospitalid' => session('hospitalid'), 'jsover' => 20])
                    ->select();

                if ($result === false) {
                    return json(['code' => 0, 'data' => '', 'msg' =>'']);
                } else {
                    return json(['code' => 1, 'data' => $result, 'msg' => 'ok']);
                }
            } catch (PDOException $e) {
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }

        }

    }


    //获取登记人员未检组合项目
    public function getWjxm()
    {
        if (request()->isAjax()) {
            try {
                $tjbh = input('param.tjbh');
                $tjcs = input('param.tjcs');
                $result = Model('TjjlbModel')->alias('tj')
                    ->join('zhxm_hd zm', 'zm.id =tj.zhxmid')
                    ->join('department de', 'de.id =zm.tjlxid')
                    ->field('xh,zm.id ,zm.mc ,depname,jsover')
                    ->where(['tjbh' => $tjbh, 'tjcs' => $tjcs, 'jsover' =>['<>',20], 'tj.hospitalid' => session('hospitalid')])
                    ->select();
                if ($result === false) {
                    return json(['code' => 0, 'data' => '', 'msg' => '获取未检项目失败']);
                } else {
                    return json(['code' => 1, 'data' => $result, 'msg' => 'ok']);
                }
            } catch (PDOException $e) {
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }

        }
    }


//获取登记人员未检组合项目(小项)
    public function getWjxmItem()
    {

        $zhxmid = input('param.zhxmid');
        if(request()->isAjax()){
            $result=Model('ZhxmDtModel')->alias('dt')->join('tjxm xm','dt.tjxmid=xm.id ')
                ->field('xm.zcts,xm.mc ,xm.id  ,xm.jglx,xm.dw,cksx,ckxx,pgts,pdts,jrxj,softid')
                ->where(['dt.zhxmid'=>$zhxmid,'xm.isdel&xm.status'=>1])
                ->order('softid')
                ->select();
            if($result===false)
                return json(['code'=>0,'data'=>'',"msg"=>"获取组合项目失败"]);
            else
                return json(['code'=>1,'data'=> $result,"msg"=>"OK"]);


        }



    }

    //获取登记人员历年项目体检结果(小项录入)
    public function getXmLndb()
    {

        $tjbh= input('param.tjbh');
        if(request()->isAjax()) {

            try {


                $result = Db::query("exec SP_GetLndb ".$tjbh.",".session('hospitalid'));



                if ($result === false)
                    return json(['code' => 0, 'data' => '', "msg" => "获取历年对比失败"]);
                else
                    return json(['code' => 1, 'data' => $result, "msg" => "OK"]);


                //return ['code' => 1, 'data' => json_encode($result), "msg" => "OK"];

            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

            }

        }

    }

    //获取登记人员项目体检结果
    public function getTjxmJg()
    {
        $tjbh= input('param.tjbh');
        $tjxmid= input('param.tjxmid');
        if(request()->isAjax()){
            $xh=Model('TjjlbModel')->alias('lb')
                ->field('xh')
                ->where(['lb.tjbh'=>$tjbh,'lb.hospitalid'=>session('hospitalid'),'lb.jsover'=>20])
                ->group('xh')
                ->select();

            $subquery=implode(',',array_column($xh,'xh'));

            $result=Model('YsztModel')->alias('zt')
                ->field('jg,sfyx,jcrq')
                ->where(['zt.xmid'=>$tjxmid,'zt.hospitalid'=>session('hospitalid'),'zt.xh'=>['in',$subquery]])->order('jcrq')->select();




            if($result===false)
                return json(['code'=>0,'data'=>'',"msg"=>"获取项目历年对比失败"]);
            else
                return json(['code'=>1,'data'=> $result,"msg"=>"OK"]);


        }



    }

    //初始化综述
    public function getInitZs()
    {
        if (request()->isAjax()) {
            try {
                $tjcs = input('param.tjcs');
                $tjbh = input('param.tjbh');

                $result = Model('TjjlbModel')->alias('lb')
                    ->join('zhxm_hd hd', 'hd.id=lb.zhxmid')
                    ->join('department dep','dep.id =hd.tjlxid')
                    ->field('depname,lb.xj,dep.normalnodule,hd.zcxj')
                    ->where(['tjbh' => $tjbh, 'tjcs' => $tjcs, 'lb.hospitalid' => session('hospitalid'), 'jsover' => 20])
                    ->select();


                if ($result === false) {
                    return json(['code' => 0, 'data' => '', 'msg' => '无诊断记录!']);
                } else {
                    return json(['code' => 1, 'data' => $result, 'msg' => 'ok']);
                }
            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

            }

        }
    }

    //初始化建议
    public function getInitJy()
    {
        if (request()->isAjax()) {
            try {
                $tjcs = input('param.tjcs');
                $tjbh = input('param.tjbh');

                $result = Model('TjjlbModel')->alias('lb')
                    ->join('tjjlmxb xmb', 'xmb.xh=lb.xh and xmb.zhxmid=lb.zhxmid  and xmb.hospitalid=lb.hospitalid and sfyx=1')
                    ->join('tjxm xm', 'xmb.xmid=xm.id ')
                    ->join('cjjg jg','xmb.jgid=jg.id ')->join('xjjy jy','jg.zdid=jy.id ')
                    ->field('jy.jymc,jy.jynr')
                    ->where(['tjbh' => $tjbh, 'tjcs' => $tjcs, 'lb.hospitalid' => session('hospitalid'), 'jsover' => 20])
                    ->select();


                if ($result === false) {
                    return json(['code' => 0, 'data' => '', 'msg' => '无诊断记录!']);
                } else {
                    return json(['code' => 1, 'data' => $result, 'msg' => 'ok']);
                }
            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

            }

        }
    }

    //复查项目通知
    public function Fcsave(){
        if(request()->isAjax()){
            if(request()->isPost()){
                $param=input('post.');
                $flag=Model('TjdjModel')->fcTzSave($param);
                return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
            }

        }
    }

    //发送复查通知$tjbh,$tjcs,$fcgy,$fcrq,$fcrqend
    public function fcSend(){
        if(request()->isAjax()){
            $param=input('post.');
            $isfs=Model('TjdjModel')->where(['tjbh'=>$param['tjbh'],'tjcs'=>$param['tjcs'],'hospitalid'=>session('hospitalid')])->find();
            $content=$isfs->xm.":你好!</br>".$param['fcgy'].'</br>复查日期:'.$param['fcrq'].'至'.$param['fcrqend'];
            if (!empty($isfs->mobile)) {
                $isfs->mobile;
            }else if (!empty($isfs->sv_mobile)) {
                $isfs->sv_mobile;
            }
            $flag = Model('TjdjModel')->fcTzSend($param,$isfs, $content );
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

        }

    }

}