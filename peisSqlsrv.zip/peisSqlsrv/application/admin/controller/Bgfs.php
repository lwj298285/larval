<?php
namespace app\admin\controller;
use think\Db;
use think\config;
use think\exception\ErrorException;
use think\exception\PDOException;
use mail\Phpmailer;
use sms\Sms;

class Bgfs extends Base{



    /**
     * [index email 发送体检报告]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){


        $tjbgname=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'tjbg'])->value('value');
        $tjbg=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>$tjbgname,'isdel'=>1])->select();
        $this->assign('tjbg',$tjbg);

        $tjbgdefault=collection(arrWhereAnd($tjbg, ['isdefault'=>1]));

        $this->assign('zjbgmbfile',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('mbfile')[0]);
        $this->assign('zjbgmbcs',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('mbcs')[0]);
        $this->assign('zjbgid',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('id')[0]);

       // $tjbgdefault=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>$tjbgname,'isdel&isdefault'=>1])->find();

        //$this->assign('zjbgmbfile',empty($tjbgdefault)?"":$tjbgdefault->mbfile);
        //$this->assign('zjbgmbcs',empty($tjbgdefault)?"":$tjbgdefault->mbcs);
        //$this->assign('zjbgid',empty($tjbgdefault)?"":$tjbgdefault->id);

        return $this->fetch();

    }



   public function getRpeortPdf($filename)
    {


    }





    //批量发送体检报告
    public function bgSend(){
        if(request()->isAjax()){
            try{
               $param=input('param.data/a');
                $i=0;$j=0;
                //领取方式为eamil 所对应的字典ID 判断报告采用什么方式发送
                $lqfsemail=Model('XtcsModel')->where(['mc'=>'lqfsemailid','isdel'=>1])->value('value');
                $hospital=Model('HospitalModel')->find(session('hospitalid'));
                foreach($param as $k=>$v){
                   // $result=Model('TjdjModel')->where(['tjbh'=>$v['tjbh'],'tjcs'=>$v['tjcs'],'hospitalid'=>session('hospitalid')])->find();


                    $content=$v['xm'].'你好！'.'</br>';
                    $content.="</br>".$hospital->hospitalname."</br>地址:".$hospital->address."</br>电话:".$hospital->tel;
                   /* if($result->sv_callback==config('lqfs')['MOBILE']){
                        $mobile=$result->mobile;
                     $sms=new Sms($mobile,$content);
                     $flag= $sms->sendSms();
                       if($flag!=="num=0"){
                           $jdbz=Model('TjdjModel')->where(['tjbh'=>$v['tjbh'],'tjcs'=>$v['tjcs'],'hospitalid'=>session('hospitalid')])->setField(['jdbz'=>60]);

                           if($jdbz==false)
                               $i++;

                          } else{
                           $j++;
                       }

                     }else{*/
                      //email 方式
                        if($v['sv_callback']==$lqfsemail) {


                            $email = empty($v['lqemail']) ? "" : $v['lqemail'];

                            if (!empty($email)) {


                                $mailer = new Phpmailer();


                                $flag = $mailer->mail($email, $content, '体检报告');


                                if ($flag['code'] == -1) {

                                    $i++;

                                } else {

                                    $jdbz = Model('TjdjModel')->where(['tjbh' => $v['tjbh'], 'tjcs' => $v['tjcs'], 'hospitalid' => session('hospitalid')])->setField(['jdbz' => 60, 'fsr' => session('realname'), 'fsrq' => Date('Y-m-d')]);
                                    if ($jdbz == false)
                                        $j++;
                                }
                            }
                        }

                    }

              //  }

                $message="";
                if ($i==0 && $j==0)
                    $message="发送体检报告成功";

                if ($i>0)
                    $message="有".$i."条体检报告发送失败;";

                if ($j>0)
                    $message.="有".$j."条体检报告记录失败;";


                if ($i==0 && $j==0 )
                    return json(['code' => 1, 'data' => '', 'msg' => $message]);
                else
                    return json(['code' => 2, 'data' => '', 'msg' => $message]);

            }catch (\phpmailerException $e){
                return  json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
            }
        }
    }

}
