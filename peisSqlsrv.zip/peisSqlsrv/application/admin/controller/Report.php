<?php
namespace app\admin\controller;
use app\admin\model\TjdjModel;
use app\admin\model\TjdwModel;
use think\console\command\make\Model;
use think\db\Query;
use think\exception\ErrorException;
use think\exception\PDOException;
use think\Controller;
use think\Db;
use think\File;
class Report extends Base

{

    //调用报表（设计）模板信息
    /**
     * @return mixed
     */
    public function getReport()
    {

        try {
            $reportid = input('param.reportid');
            $reportinfo = Model('ReportglModel')->find(['id' => $reportid,'hospitalid'=>session('hospitalid')]);
            $reportcs = $reportinfo->mbcs; //Model('ReportglModel')->where(['id'=>$reportid])->value('mbcs');
            $reportname = urlencode($reportinfo->mbfile);// urlencode(Model('ReportglModel')->where(['id'=>$reportid])->value('mbfile'));

            // $reportcs= json($reportinfo->mbcs);
            $reportparam = input('param.reportparam');
// 参数以json 格式传递
            if (empty($reportname))
                $reportname = "test.grf";

            $this->assign('name', $reportname);
            $this->assign('cs', $reportcs);
            $this->assign('param', $reportparam);
            $tjbgname= $tjbgname=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'tjbg'])->value('value');

            //判断是否总检报告
            if ($reportinfo->name==$tjbgname && !empty($reportparam) )
                $this->assign('iszjbg', 'yes');
            else
                $this->assign('iszjbg', 'no');


            return $this->fetch();



        } catch (ErrorException $e) {
            return $e->getMessage();

        }
    }




    //获取报表图片
 public function getReportImage($djlsh)
      {


          if (request()->isAjax()) {
              try {



                  if (strlen($djlsh)>0) {

                      $djlshArr=explode(",",$djlsh);
                      $djlshPicArr=Array();
                     // $picTimeArr=array();
                      foreach ($djlshArr as $value) {

                          $path = $_SERVER['DOCUMENT_ROOT'] . DS . "upload" . DS . "interface" . DS . session('hospitalid') .DS. $value;
                          $filepath = "/upload/interface/" . session('hospitalid') .'/'. $value . "/";
                         // $jsonimage = "";
                          if (file_exists($path)) {

                              $handler = opendir($path);

                              //2、循环的读取目录下的所有文件
                              //其中$filename = readdir($handler)是每次循环的时候将读取的文件名赋值给$filename，为了不陷于死循环，所以还要让$filename !== false。一定要用!==，因为如果某个文件名如果叫’0′，或者某些被系统认为是代表false，用!=就会停止循环
                              $filestr = "";
                              while (($filename = readdir($handler)) !== false) {
                                  //3、目录下都会有两个文件，名字为'.'和‘..’，不要对他们进行操作
                                  if ($filename != "." && $filename != "..") {
                                      //4、进行处理

                                      $info = pathinfo($filename);   //getimagesize
                                      if ($info['extension'] == 'jpg' || $info['extension'] == 'jpeg' || $info['extension'] == 'png' || $info['extension'] == 'gif') {
                                          $image = \org\Image::open($path . DS . $filename);
                                          $ctime=date("Y-m-d H:i:s",filectime($path . DS . $filename)); //创建日期

                                          $imageArr = ['hospitalid'=>session('hospitalid'),'djlsh'=>$value,'picname'=>$filepath.$filename,'width'=>$image->width(),'height'=> $image->height(),'ctime'=>$ctime ];
                                          array_push($djlshPicArr,$imageArr);

                                      }

                                  }
                              }

                              closedir($handler);

                            //  array_multisort($picTimeArr,SORT_DESC,SORT_STRING,  $djlshPicArr);文件排序
                          }




                      }


                      if ( count($djlshPicArr)>0)
                          Db::execute(" If exists(select * from sysobjects where id=object_id('peis_ZJPICTEMP'))
                                      Truncate table peis_ZJPICTEMP
                                   else
                                        Create table peis_ZJPICTEMP(
                                        hospitalid INT NOT NULL,  
                                        djlsh varchar(12)  NOT NULL,
                                        picname varchar(255) NOT NULL,
                                        height varchar(20) NOT NULL,
                                        width varchar(20) NOT NULL
                                        )"
                                        );
                          Db::table('peis_ZJPICTEMP')->insertAll($djlshPicArr);



                      return json(['code' => 1, 'data' => $djlshPicArr, 'msg' => "ok"]);


                  }



              } catch (ErrorException $e) {

                  return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

              }
          }

      }



    //获取报表图片
  /*  public function getReportImage($djlsh)
    {


        if (request()->isAjax()) {
            try {

                //判断是否总检报告

                $path = $_SERVER['DOCUMENT_ROOT'] . DS . "upload" . DS . "interface" . DS . session('hospitalid') .$djlsh;
                $filepath = "/upload/interface/" . session('hospitalid').$djlsh . "/";
                $jsonimage = "";
                if (file_exists($path)) {

                    $handler = opendir($path);


                    //2、循环的读取目录下的所有文件
                    //其中$filename = readdir($handler)是每次循环的时候将读取的文件名赋值给$filename，为了不陷于死循环，所以还要让$filename !== false。一定要用!==，因为如果某个文件名如果叫’0′，或者某些被系统认为是代表false，用!=就会停止循环
                    $filestr = "";
                    while (($filename = readdir($handler)) !== false) {
                        //3、目录下都会有两个文件，名字为'.'和‘..’，不要对他们进行操作
                        if ($filename != "." && $filename != "..") {
                            //4、进行处理

                            $info = pathinfo($filename);   //getimagesize
                            if ($info['extension'] == 'jpg' || $info['extension'] == 'jpeg' || $info['extension'] == 'png' || $info['extension'] == 'gif') {
                                $image = \org\Image::open($path . DS . $filename);
                                $jsonimage .= "{'file':'" . $filepath . $filename . "','width':" . $image->width() . ",'height':" . $image->height() . "},";

                            }

                        }
                    }

                    closedir($handler);
                }


                $jsonimage = substr($jsonimage, 0, -1);


                return json(['code' => 1, 'data' => "[" . $jsonimage . "]", 'msg' => "ok"]);


            } catch (ErrorException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

            }
        }

    }*/



    //设计报表模板
    public function designReport(){
        $designname=input('param.designname');
        if(empty($designname))
            $designname="test.grf";
        $this->assign('designname',$designname);
        return $this->fetch();
    }


  //没有报表插件提示下载安装
    public function getinstall()
    {

        $filename=input('param.filename');
        $file=$filename;
        if (!file_exists($file))
        {
            echo "the file does not exist!";
            exit();
        }


     $file_size=filesize($file);
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length:". $file_size);
        header("Content-Disposition: attachment; filename=".$filename);
        $fp=fopen($file,"rb");
        if (!$fp)
            echo "can't open file!";
        $buffer_size=1024;
        $cur_pos=0;
        while (!feof($fp)&&$file_size-$cur_pos>$buffer_size)
        {
            $buffer=fread($fp,$buffer_size);
            echo $buffer;
            $cur_pos+=$buffer_size;
        }
        $buffer=fread($fp,$file_size-$cur_pos);
        echo $buffer;
        fclose($fp);

    }
//设计报表模板
    public function designNewReport(){


        $name=input('param.name');
        $this->assign('name',$name);

        return $this->fetch();
    }


//保存报表模板数据
   public function getsaveReport(){

    $bolpos=strpos($_GET['report'],";");
    $name="";
    $mbmc="";
    $mbfile="";
    $reportparam=[];
    if ($bolpos) {

        $reportparam=explode(';',$_GET['report']);
        $name=$reportparam[0];
        //$mbfile=$reportparam[1];
       // $mbmc=str_replace(".grf","",$mbfile);
        $mbmc=session('hospitalid').session('username').time();
        $mbfile=$mbmc.'.grf';
        $filename = dirname($_SERVER['SCRIPT_FILENAME']) . "/report/" . iconv('utf-8', 'gb2312',$mbfile );

    } else {
        $filename = dirname($_SERVER['SCRIPT_FILENAME']) . "/report/" . iconv('utf-8', 'gb2312', $_GET['report']);
    }

    $content = file_get_contents("php://input");

    if ( !$handle = fopen($filename, 'wb') )
    {
        print "不能打开文件 {$filename}，可能是WEB服务用户不具有目录的写入权限";
        exit;
    }

    if ($bolpos){
        $param['name']=$name;
        $param['mbfile']=$mbfile;
        $param['mbmc']=$mbmc;
        $flag=Model('ReportglModel')->editReport($param);
        if ($flag['code']==1){
            // 将$content写入到我们打开的文件中。
            if ( !fwrite($handle, $content) )
            {
                print "保存报表失败 {$filename}";
                exit;
            }

            fclose($handle);
        }else{

            print "数据库写入报表信息失败 {$filename}";
            exit;
        }

    }else{
        if ( !fwrite($handle, $content) )
        {
            print "保存报表失败 {$filename}";
            exit;
        }

        fclose($handle);

    }





}

//保存报表报表打印记录
    public function getsavePrint($name,$djlsh,$fzrq=null){

         if(request()->isAjax()) {

            try {
                $tjdj = new TjdjModel();
                $printdatetime =date("Y-m-d H:i:s");
                $printczy = session('realname');
                $param = [];
             //   $arrdjlsh=explode(",",$djlsh);
             //   $map = ['djlsh' => ['in',$arrdjlsh],  'hospitalid' => session('hospitalid')];

                    switch ($name) {

                        case 'zjbg':
                            // $param = ['jdbz' => 50, 'bgprintdate' => $printdatetime, 'bgprintczy' => $printczy,'bgprintcs' => ['EXP','(CASE WHEN bgprintcs IS NULL THEN 1 ELSE bgprintcs+1 END )']];
                            $sql="jdbz=50, bgprintdate='".$printdatetime."', bgprintczy='". $printczy."',bgprintcs=(CASE WHEN bgprintcs IS NULL THEN 1 ELSE bgprintcs+1 END )";
                             break;
                        case 'ydd':
                              $sql="yddprintdate='".$printdatetime."', yddprintczy='". $printczy."',yddprintcs=(CASE WHEN yddprintcs IS NULL THEN 1 ELSE yddprintcs+1 END )";
                             //$param = ['yddprintdate' => $printdatetime, 'yddprintczy' => $printczy,'yddprintcs'=>'(CASE WHEN yddprintcs IS NULL THEN 1 ELSE yddprintcs+1 END )'];
                             break;
                        case 'txm':
                              $sql="txmprintdate='".$printdatetime."', txmprintczy='". $printczy."',txmprintcs=(CASE WHEN txmprintcs IS NULL THEN 1 ELSE txmprintcs+1 END )";
                             //$param = ['txmprintdate' => $printdatetime, 'txmprintczy' => $printczy, 'txmprintcs' => ['EXP','(CASE WHEN txmprintcs IS NULL  THEN 1 ELSE txmprintcs+1 END)']];
                             break;
                        case 'jkz':
                               $sql="jkzprintdate='".$printdatetime."', jkzprintdate='". $printczy."',jkzprintcs=(CASE WHEN jkzprintcs IS NULL THEN 1 ELSE jkzprintcs+1 END ),fzrq='".$fzrq."'";
                             //$param = ['jkzprintdate' => $printdatetime, 'jkzprintczy' => $printczy, 'jkzprintcs' => ['EXP','(CASE WHEN jkzprintcs IS NULL THEN 1 ELSE jkzprintcs+1 END) '], 'fzrq' => $fzrq];
                             break;
                        default:
                            break;

                      }

                       // $result=$tjdj->save($param, $map);
                        $result=db::execute("update peis_tjdjb set  ".$sql." where djlsh in (".$djlsh.") and hospitalid=".session('hospitalid'));


                        if ($result!=false)
                            return json(['code'=>1,'data'=>'','msg'=>'保存打印记录成功']);
                        else
                            return json(['code'=>0,'data'=>'','msg'=>'保存打印记录失败']);

            }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg'=>'保存打印记录失败']);
            }

        }


    }


//下载模板文件
    public function downFile($id){



        try {
           // $file = DOWNLOAD_PATH . $fs;

            $mbfile= Model('ReportglModel')->where(['id' => $id,'hospitalid'=>session('hospitalid')])->value('mbfile');
            $file  = dirname($_SERVER['SCRIPT_FILENAME']) . "/report/" . iconv('utf-8', 'gb2312', $mbfile );
            ///$file  = dirname($_SERVER['SCRIPT_FILENAME']) . "/report/" .  $mbfile ;


            if (!file_exists($file)) {
                echo "文件不存在";
                exit();
                //return json(['code'=> 0,'data'=> '','msg'=>'文件不存在']);
            }
            $file_size = filesize($file);
            header("Content-type: application/octet-stream");
            header("Accept-Ranges: bytes");
            header("Accept-Length:" . $file_size);
            header("Content-Disposition: attachment; filename=" . iconv('utf-8', 'gb2312', $mbfile ));
           // header("Content-Disposition: attachment; filename=" . $mbfile );
            $fp = fopen($file, "r");
            if (!$fp){
                echo "文件无法打开";
                exit();
            }


            // return json(['code'=> 0,'data'=> '','msg'=>'文件不能打开']);

            $buffer_size = 1024;
            $cur_pos = 0;
            while (!feof($fp) && $file_size - $cur_pos > $buffer_size) {
                $buffer = fread($fp, $buffer_size);
                echo $buffer;
                $cur_pos += $buffer_size;
            }
            $buffer = fread($fp, $file_size - $cur_pos);

            fclose($fp);
            echo $buffer;
        }catch (Exception $e){

            echo "下载文件错误，请联系管理员！";

        }



    }
//打开报表模板数据
/*public function getreadReport(){

    $filename = dirname($_SERVER['SCRIPT_FILENAME']) . "/report/";

    if ( !$handle = fopen($filename, 'r') )
    {
        print "不能打开文件 $filename，可能是文件不存在或WEB服务用户不具有相关权限";
        exit;


    //$contents = fread($handle, filesize($filename));
    //fclose($handle);

    echo $handle;
}

}*/
}