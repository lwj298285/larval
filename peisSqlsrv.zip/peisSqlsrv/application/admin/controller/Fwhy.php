<?php

namespace app\admin\controller;
use app\admin\model\ FwhyModel;
use think\Db;
use think\Config;

class Fwhy extends Base
{

    /**
     * [index 服务行业]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
	 

	 
    public function index(){


        return $this->fetch();
		

    }




    /**
     * [lclxEdit 添加删除服务行业]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function fwhyEdit()
    {
        $fwhy = new FwhyModel();

        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增

                $param = input('post.');
                $flag = $fwhy->editFwhy($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }else{//get 为获取数据


                $id = input('param.id');
                return  json($fwhy->getOneFwhy($id));
               // dump(json([ $lclx->getOneLclx($id)]));
                //$this->ajaxReturn($lclx->getOneLclx($id),'JSON');
            }
        }


    }


    /**
     * [ fwhyDel 删除服务行业]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function fwhyDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
            $fwhy = new FwhyModel();
            $flag = $fwhy->delFwhy($id,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ editSoft 调整服务行业排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $fwhy = new FwhyModel();
            $flag = $fwhy->editSoft($id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    public function giveFwhy()
    {

        if (request()->isAjax()) {
            $param = input('param.');

            $result = Db::name('fwhy')->where('isdel', 1)->field('id,mc,softid')->order('softid')->select();

            $str = '[{"id":"0","name":"服务行业", "open":"true","isParent":"true","childOuter":"false","children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }



}