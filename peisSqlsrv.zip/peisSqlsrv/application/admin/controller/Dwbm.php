<?php
namespace app\admin\controller;
use think\Db;
use app\admin\model\DwbmModel;
use app\admin\model\DwzwzcModel;
use think\exception\PDOException;

class Dwbm extends Base
{



    /**
     * [index 单位部门]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index()
    {
        return $this->fetch();
    }

    //双击获取新增/更新单位部门
    /**
     * @return \think\response\Json
     */
    public function dwbmEdit()
    {
        if(request()->isAjax()){
              if(request()->isPost()){
                $param = request()->except('dwname','post');
                $dwbm = new DwbmModel();
                $flag = $dwbm->editDwbm($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
            }else{
                 try {
                     $dwid = input('param.dwid');
                     $id = input('param.id');
                     $data = Model('DwbmModel')->where(['dwid' => $dwid, 'id' => $id])->find();
                     return json(['code' =>1, 'data' => $data, 'msg' =>'ok']);
                    // return json($data);
                 }catch(PDOException $e){
                     return json(['code' =>0, 'data' => '', 'msg' =>$e->getMessage()]);

                 }
            }

        }
    }

  /*  public function  getDwbm($dwid){

        $data=Model('DwbmModel')->where('dwid',$dwid)->select();
        return json( $data);
  }*/

  //获取单位部门信息
    public function  giveDwbm($dwid){

        if(request()->isAjax()) {
            $result = Model('DwbmModel')->where('dwid', $dwid)->order('softid')->select();
            $str = '[{"id":"0","name":"部门信息","isParent":"true","open":"true","childOuter":"false", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }

    //获取单位职位职称信息
    public function  giveDwzc($dwid,$type){

     if(request()->isAjax()){
        $result = Model('DwzwzcModel')->where(['dwid'=>$dwid,'type'=>$type])->order('softid')->select();
        if ($type=='zw')
             $str = '[{"id":"0","name":"职务信息","isParent":"true", "open":"true","childOuter":"false", "children":[';
         else
             $str = '[{"id":"0","name":"职称信息","isParent":"true", "open":"true","childOuter":"false", "children":[';

        if  ($result) {
            foreach ($result as $key => $vo) {
                $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

            }

            $str=substr($str, 0, -1);

        }

        $str .=']}]';


        return json(['code'=>1,'data'=>$str,"msg"=>"OK"]);}

    }

    //删除单位部门
    /**
     * @return \think\response\Json
     */
    public function dwbmDel()
    {
        if (request()->isAjax()) {
            $id = input('param.id');
            $dwbm = new DwbmModel();
            $flag = $dwbm->delDwbm($id);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ editSoft 调整检验类型排序]
     * @return [type] [description]
     * @author [俞晴] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $dwbm = new DwbmModel();
            $flag = $dwbm->editSoft($id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    //编辑新增单位职务职称信息
    public function zwzcEdit()
    {
        if(request()->isAjax()){
            if(request()->isPost()){
                $param = request()->except('dwmc','post');
                $zwzc = new DwzwzcModel();
                $flag = $zwzc->editZwzc($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
            }else{
                try{
                    $dwid = input('param.dwid');
                    $id= input('param.id');
                    $data=Model('DwzwzcModel')->where(['dwid'=>$dwid,'id'=>$id])->find();
                    return json(['code' =>1, 'data' =>$data, 'msg' =>'ok']);
                }catch(PDOException $e){
                    return json(['code' =>0, 'data' => '', 'msg' =>$e->getMessage()]);

                }

            }

        }
    }

    //删除职务职称信息

    public function zwzcDel(){
        if(request()->isAjax()){
            $id=input('param.id');
            $flag=Model('DwzwzcModel')->delZwzc($id);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);

        }
    }

    //排序职务职称信息
    public function zwSoftEdit(){
    if(request()->isAjax()){
        $id=input('param.id');
        $type=input('param.type');
        $targetid=input('param.targetid');
        $flag=Model('DwzwzcModel')->SoftEdit($id,$type,$targetid);
        return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
    }
    }


    //获取单位职称职务

    public function getDwzwzc($dwid){
        if(request()->isAjax()){
            return json(Model('DwzwzcModel')->where('dwid',$dwid)->select());
        }
    }


    //获取单位职称职务

    public function getDwbm($dwid){
        if(request()->isAjax()){
            return json(Model('DwbmModel')->where('dwid',$dwid)->select());
        }
    }

}
