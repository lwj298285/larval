<?php

namespace app\admin\controller;
use app\admin\model\YwlxModel;

class Ywlx extends Base
{
	/**
	 * [index 体检业务类型]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	
	
	public function index(){

		return $this->fetch();
		
	}
	




	/**
	 * [ywlxEdit 添加修改业务类型]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function ywlxEdit()
	{
		$ywlx = new YwlxModel();
		
		if(request()->isAjax()) { //ajax 提交
			
			if (request()->isPost()) { // 判断提交方式 post为 更新和新增
				
				$param = input('post.');
				$flag = $ywlx->editYwlx($param);
				return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
			} else {//get 为获取数据
				
				$id = input('param.id');
				return json($ywlx->getOneYwlx($id));
			}
		}
		
		
	}


//获取体检单位异步返回
    public function getYwlx()
    {
        return json(Model('YwlxModel')->order('id asc')->select());
    }
	
	/**
	 * [ywlx 删除体检单位]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function ywlxDel()
	{
		if(request()->isAjax()) {
			$id = input('param.id');
			$tjdw = new YwlxModel();
			$flag = $tjdw->delYwlx($id);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	


	//获取业务类型树状结构数据
	public function giveYwlx()
	{
        if (request()->isAjax()) {

            $result = Model('YwlxModel')->order('softid')->select();

            $str = '{"id":"0","name":"业务类型", "open":"true","isParent":"true","childOuter":"false"},';
            if ($result) {
                foreach ($result as $key => $vo) {

                  if ($vo['pid']!=0)
                      $str .= '{ "id": "' . $vo['id'] . '", "pId":"' . $vo['pid'] . '", "name":"' . $vo['mc'] .'"},';
                   else
                       $str .= '{ "id": "' . $vo['id'] . '", "pId":"' . $vo['pid'] . '", "name":"' . $vo['mc'] .'","open":"false","isParent":"true","childOuter":"false"},';
                }
            }

            return json(['code' => 1, 'data' => "[" . substr($str, 0, -1) . "]", "msg" => "OK"]);
        }
	}
	
	/**
	 * [ editSoft 调整体检单位排序]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function softEdit()
	{
		if(request()->isAjax()) {
			$id = input('param.id');
			$type = input('param.type');
			$targetid = input('param.targetid');
			$ywlx = new YwlxModel();
			$flag = $ywlx->editSoft($id,$type,$targetid);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	



	
}