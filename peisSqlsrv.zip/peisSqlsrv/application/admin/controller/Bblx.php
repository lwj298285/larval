<?php

namespace app\admin\controller;

use app\admin\model\BblxModel;
use think\Db;
use think\Config;
use think\db\Connection;
use think\exception\PDOException;


class Bblx extends Base
{
	/**
	 * [index 标本类型]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	
	
	public function index(){





		return $this->fetch();
		
	}
	
	
	/**
	 * [bblxEdit 添加删除标本类型]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function bblxEdit()
	{
		$bblx = new BblxModel();
		
		if(request()->isAjax()) { //ajax 提交
			
			if (request()->isPost()) { // 判断提交方式 post为 更新和新增
				
				$param = input('post.');
				$flag = $bblx->editBblx($param);
				return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
			} else {//get 为获取数据
				try {
                    $id = input('param.id');
                   return json(['code' => 1, 'data' => $bblx->getOneBblx($id), 'msg' => 'ok']);
                }catch(PDOException $e){
                    return json(['code' => 0, 'data' => 0, 'msg' => $e->getMessage()]);
                }
			}
		}
		
		
	}
	
	
	/**
	 * [bblxDel 删除标本类型]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function bblxDel()
	{
		if(request()->isAjax()) {
			$id = input('param.id');
			$name = input('param.name');
			$bblx = new BblxModel();
			$flag = $bblx->delBblx($id,$name);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	
	
	public function givebblx()
	{



        if(request()->isAjax()) {
            $param = input('param.');

            //获取现有的标本类型
            //  if('get' == $param['type']){


            $result = Db::name('tjbblx')->where('isdel', 1)->field('id,bblxname,status,softid')->order('softid')->select();
            $str = '[{"id":"0","name":"标本类型", "open":"true","childOuter":"false", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    //看标本类型是否启用显示不同图标
                    $icon = '';
                    if ($vo['status'] == 0)
                        $icon = ',"iconSkin":"diy02"';
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['bblxname'] . '"' . $icon . '},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
	}
	
	/**
	 * [ editSoft 调整标本类型排序]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function softEdit()
	{
		if(request()->isAjax()) {
			$id = input('param.id');
			$type = input('param.type');
			$targetid = input('param.targetid');
			$bblx = new BblxModel();
			$flag = $bblx->editSoft($id,$type,$targetid);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	
	
}