<?php

namespace app\admin\controller;
use app\admin\model\XjjyModel;
use app\admin\model\CjjgModel;
use think\console\command\make\Model;
use think\Db;
use think\exception\PDOException;


class Xjjy extends Base

{


    /**
     * [index 小结建议]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){

        return $this->fetch();


    }




    /**
     * [xjjyEdit 添加修改体检项目结果建议]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xjjyEdit()
    {
        $xjjy = new XjjyModel();

        if(request()->isAjax()){ //ajax 提交


               // $param =Request()->except(['ROW_NUMBER','index','jgmc'],'data/a');
                $param=input('data/a');
                unset($param['ROW_NUMBER']);
                unset($param['index']);

                $flag =  $xjjy->editXjjy($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'id'=> $flag['id'],'msg' => $flag['msg']]);
                // return json(['code' => 1, 'data' => $param, 'msg' =>'']);

        }


    }


    /**
     * [ xjjyDel 删除诊断建议]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xjjyDel()
    {
        if(request()->isAjax()) {
           // $tjxmid = input('param.tjxmid');
            $id = input('param.id');
            $zyzd = input('param.zyzd');
            $jymc = input('param.jymc');
            $xjjy = new XjjyModel();
            $flag = $xjjy->delXjjy($id,$zyzd,$jymc);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }





// 根据参数条件查看诊断是否存在不存在动态添加，返回诊断ID并标明是新增还是原有。
    public function getOneXjjy()
    {


        if(request()->isAjax()) {
            $param= input('param.');

            try{

                $zyzd =Model('XjjyModel')->where(['isdel'=>1,'tjlxid'=>$param['tjlxid'],'zyzd'=>$param['zyzd']])->find();

                if (!empty($zyzd)) {
                    return json(['code' => 1, 'data' =>$zyzd, 'id' => '', 'msg' => '']);
                }else {
                    $flag = Model('XjjyModel')->editXjjy($param);
                    return json(['code' => $flag['code'],'data' => 'add', 'id' => $flag['id']]);
                }

            }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg' => $e->getMessage()]);
            }


        }


    }


//根据 体检类型和临床类型获取 小结建议
    public function getJjlxXjjy()
    {
        if(request()->isAjax()) {
            $tjlxid = input('param.tjlxid');

         /*  $lsits = Db::name('cjjg  jg')->join('xjjy jy','jg.id=jy.xmjgid','left')
                ->field('jg.*,sftj,jy.pyjm as jypyjm,jy.wbjm as jywbjm,jynr,explain')
                ->where(['jg.isdel'=>1,'jg.tjxmid'=>$tjxmid])->select();*/

            try{

                $xjjy =Model('XjjyModel')->where(['isdel'=>1,'tjlxid'=>$tjlxid])->select();
                return json(['code'=>1,'data'=>$xjjy,'msg' => '']);

            }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg' => $e->getMessage()]);
            }


        }

    }



}