<?php

namespace app\admin\controller;
use app\admin\model\TjdwModel;
use think\console\command\make\Model;
use think\db;
use app\admin\model\DwfzModel;
use think\exception\PDOException;

class Dwfz extends Base
{
	/**
	 * [index 单位分组套餐]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */

	
	
	public function index(){
		

		return $this->fetch();
		
	}





	/**
	 * [dwfzEdit 添加编辑单位分组]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function dwfzEdit()
	{

		
		if(request()->isAjax()) { //ajax 提交
			
			if (request()->isPost()) { // 判断提交方式 post为 更新和新增
				
				//$param = input('post.');
                $param = request()->except('dwname','post');
				$flag = Model('DwfzModel')->editDwfz($param);
				return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
			} else {//get 为获取数据
                try {
                    $dwid = input('param.dwid');
                    $id = input('param.id');
                    return json(['code' => 1,'data'=>Model('DwfzModel')->where(['dwid'=>$dwid,'id'=>$id,'hospitalid'=>session('hospitalid')])->find(),'msg'=>'ok']);
                }catch(PDOException $e){
                    return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
                }
                //因为dwid唯一所条件可以不传hospitalid

			}
		}
		
		
	}

    /**
     * [eidtZhxmjg 修改单位分组折扣价组合项目价格]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function editZhxmjg()
    {


        if(request()->isAjax()) { //ajax 提交

                $zhxmdata = input('param.zhxmdata/a');
                $dwid = input('param.dwid');
                $fzid = input('param.fzid');

                $fzzhkjg=Model('DwfzModel')->where(['hospitalid'=>session('hospitalid'),'dwid'=>$dwid,'id'=>$fzid,'status'=>1])->value('zkhjg');
               // collection($zhxmdata)->column('jg')

                $sumzhxm=array_sum(array_map(create_function('$val', 'return $val["jg"];'),  $zhxmdata));

                if ($fzzhkjg!= $sumzhxm)
                     return json(['code' => 0, 'data' => '', 'msg' => '套餐折扣价与项目总价不符，不能保存']);

                $flag = Model('DwfzDtModel')->zhxmjgEdit($dwid,$fzid,$zhxmdata);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

                //return json(['code' => 1, 'data' => '', 'msg' => 'ok']);
           }


    }




//获取当前医院某个单位下具体分组套餐
/* @return [type] [description]
 * $dwid 单位ID, $fzid分组ID,
* @author [李勇] [peis999]
*/
    public  function getOneDwfz($dwid,$fzid)
    {
        if (request()->isAjax()) {


            return json(DwfzModel::getOneDwfz($dwid,$fzid));



        }

    }




    //获取单位分组折扣套餐项目
    function getDwfzZkxm($dwid,$fzid){

        if (request()->isAjax()) {


            $result = Model('DwfzDtModel')->alias('dt')
                 ->join('zhxm_hd hd', 'dt.zhxmid=hd.id', 'left')
                ->field('dt.zhxmid,dt.jg ,mc,sfdz,zdzk,hd.jg as sj')
                ->where(['hd.isdel&hd.status' => 1, 'dt.fzid' => $fzid, 'dt.dwid'=>$dwid, 'dt.hospitalid' => session('hospitalid')])
                ->order('sfdz,zdzk desc')
                ->select();

            return json($result);
        }

    }


//获取当前医院某个单位分组信息
    public  function getDwfz($dwid="",$isall='yes')
    {
        if (request()->isAjax()) {


             return json(DwfzModel::getDwfz($dwid,$isall));



        }

    }


    //获取当前医院对应单位分组组合项目
    public function getSelZhxm($dwid,$fzid)
    {

        if (request()->isAjax()) {


            $pid=Db::query('select dbo.GetDWPID('.$dwid.','.session('hospitalid').') as topdwid ');

            $result = Model('DwfzDtModel')->alias('dt')
                                ->join('zhxm_hd hd', 'dt.zhxmid=hd.id')
                                ->join('dwfz_hd fz','dt.fzid=fz.id and dt.hospitalid=fz.hospitalid and dt.dwid=fz.dwid','left')
                                ->field('hd.id ,hd.mc,(case when fz.sfsh=0 then hd.jg  else dt.jg end) as jg,hd.softid')
                                ->where(['hd.isdel&hd.status' => 1, 'dt.fzid' => $fzid, 'dt.dwid'=>$pid[0]['topdwid'], 'dt.hospitalid' => session('hospitalid')])
                                ->order('softid')
                                ->select();

            return json($result);
        }
    }

    //获取当前医院所有的体检单位分组信息
    public function giveDwfz($dwid="",$searchstr,$status="false")
    {
        $map=['isdel' => 1, 'pid' => 0, 'hospitalid' => session('hospitalid')];
        if ($status=="true") {
            $where['status'] = ['=', 1];
            $map['status']=['=',1];
        }
        if (!empty($dwid))
            $map['id']=['=',$dwid];


        if (!empty($searchstr))
            $map['dwname|pyjm|wbjm'] = ['like', '%' . $searchstr . '%'];


        $tjdw = Model('TjdwModel')->where($map)
            ->field('id,pid,dwname,status,softid')
            ->order('softid')
            ->select();

        $where['hospitalid'] = session('hospitalid');


        $allfz = Model('DwfzModel')
            ->where($where)
            ->field('id,dwid,mc,status,(case when zk is not null and zkhjg is not null then zkhjg else (case when jg is null then 0 else jg end) end) as jg,softid')
            ->order('softid')
            ->select();

        $str = '[{"id":"0","name":"单位分组信息", "open":"true","isParent":"true","childOuter":"false","children":[';

        if ($tjdw) {
            foreach ($tjdw as $key => $vo) {

                if (!empty($searchstr))
                    $str .= '{ "id": "' . $vo['id'] . '", "pId":"0","open":"true","isParent":"true", "name":"' . $vo['dwname'] . '","childOuter":"false","children":[';
                 else
                     $str .= '{ "id": "' . $vo['id'] . '", "pId":"0","isParent":"true", "name":"' . $vo['dwname'] . '","childOuter":"false","children":[';

                $dwfz= arrWhereAnd($allfz, ['dwid' => $vo['id']]);
                if ($dwfz) {
                    foreach ($dwfz as $k => $v) {

                        //看单位分组是否启用显示不同图标
                        $icon = '';
                        if ($v['status'] == 0)
                            $icon = ',"iconSkin":"diy02"';

                        $str .= '{ "id": "' . $v['id'] . '","title": "' . $v['jg'] . '", "pId":"' . $vo['id'] . '", "name":"' . $v['mc'] . '"' . $icon . '},';


                    }
                    $str = substr($str, 0, -1);
                }
                $str .= ']},';

            }
            $str = substr($str, 0, -1);

        }
        $str .=']}]';
        $escapers = array("\\");
        $replacements = array("\\\\");
        $str = str_replace($escapers, $replacements,$str);
        return json(['code'=>1,'data'=>$str,"msg"=>"OK"]);

    }



    /**
     * [tjdwDel 删除体检单位]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function dwfzDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
            $dwid = input('param.dwid');
           //$dwfz = new DwfzModel();
            $flag =Model('DwfzModel')->delDwfz($id,$name,$dwid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

	/**
	 * [ editSoft 调整体检单位排序]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function softEdit()
	{
		if(request()->isAjax()) {
			$id = input('param.id');
            $dwid = input('param.dwid');
			$type = input('param.type');
			$targetid = input('param.targetid');
			//$dwfz = new DwfzModel();
			$flag = Model('DwfzModel')->editSoft($dwid,$id,$type,$targetid);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}



    //获取单位分组未选择组合项目

    public function giveNotSelZhxm($dwid,$id,$tjlxid,$xb,$key)
    {
        if (request()->isAjax()) {
            $where = [];


            $where['zd.isdel&zd.status']=['=',1];
            $where['dp.isdel&dp.status']=['=',1];

            if (!empty($key))
                $where['zd.mc|zd.pyjm|zd.wbjm'] = ['like', '%' . $key . '%'];

         /*   if (!empty($lclxid))
                $where = ['lclxid' => $lclxid]; // $where['lclxid']=['=',$lclxid]*/
            if (!empty($tjlxid))
                $where['tjlxid'] = ['=', $tjlxid];


            if ($xb=='%'|| empty($xb)) {
                $data = Model('ZhxmModel')->alias('zd')
                    ->join('dwfz_tc tc', 'zd.id=tc.zhxmid and tc.dwid=' . $dwid . ' and tc.fzid=' . $id . ' and tc.hospitalid=' . session('hospitalid'), 'left')
                    ->join('department dp','dp.id=zd.tjlxid')
                    ->field('zd.id,zhxmid ,mc,softid,depname')//zhxmid is null
                    ->where($where)
                    ->order('softid')
                    ->select();
            }else{
                $data = Model('ZhxmModel')->alias('zd')
                    ->join('dwfz_tc tc', 'zd.id=tc.zhxmid and tc.dwid=' . $dwid . ' and tc.fzid=' . $id . ' and tc.hospitalid=' . session('hospitalid'), 'left')
                    ->join('department dp','dp.id=zd.tjlxid')
                    ->field('zd.id,zhxmid ,mc,softid,depname')//zhxmid is null
                    ->where($where)
                    ->whereIn('xb',$xb.',%')
                    ->order('softid')
                    ->select();

            }

            $result = arrWhereAnd($data, ['zhxmid' => null]);

            $str = '[{"id":"0","name":"可选择组合项目", "open":"true","isParent":"true","childOuter":"false", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '","title": "' . $vo['depname'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';
            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);
            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }


    }

//获取单位分组已添加的组合项目

    public function giveSelZhxm($dwid,$id,$key)
    {

        if (request()->isAjax()) {
            $where = [];
            if (!empty($key))
                $where['hd.mc|hd.pyjm|hd.wbjm'] = ['like', '%' . $key . '%'];

            $result = Model('DwfzDtModel')->alias('dt')->join('zhxm_hd hd', 'dt.zhxmid=hd.id', 'left')
                ->field('hd.id ,hd.mc,hd.softid')
                ->where(['hd.isdel&hd.status' => 1, 'dt.fzid' => $id,'dwid'=>$dwid,'hospitalid'=>session('hospitalid')])
                ->where($where)
                ->order('softid')
                ->select();

            $str = '[{"id":"0","name":"已选组合项目", "open":"true","childOuter":"false","isParent":"true", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';
            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);

            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }


    /**
     * [ dwfzEditItem增加组合项目小项]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function dwfzEditItem()
    {
        if (request()->isAjax()) {

            $param['zhxmid'] = input('zhxmid');
            $param['fzid'] = input('fzid');
            $param['dwid'] = input('dwid');
            $param['hospitalid'] = session('hospitalid');

            Db::startTrans();

            try{



                $flag = Model('DwfzDtModel')->save($param);

                if($flag==false) {

                    Db::rollback();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加分组套餐组合项目失败(ID='. session('hospitalid').'-'. $param['dwid'] . '-'.  $param['fzid'].' )', 2);

                    return json(['code' => 0, 'data' => '', 'msg' => '添加组合项目失败']);
                } else {

                    $jg=Model('DwfzDtModel')->getDwfzjg( $param['dwid'], $param['fzid'] );
                    //更新分组套餐价格，如果是打折套餐并且审核过设置未未审核
                    Model('DwfzModel')->where(['dwid'=> $param['dwid'] ,'id'=>$param['fzid'],'hospitalid'=>session('hospitalid')])
                                        ->update(['jg'=>$jg,'sfsh'=>['exp','case sfsh when 1 then 0 else 0 end']]);

                    Db::execute('exec  SP_Dwfzzk '.session('hospitalid').','. $param['dwid'].','. $param['fzid']);

                    Db::commit();

                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加分组套餐组合项目失败(ID='. session('hospitalid').'-'. $param['dwid'] . '-'.$param['fzid']. ')', 1);

                    return json(['code' => 1, 'jg' =>$jg , 'msg' => '添加组合项目成功']);
                }
            }catch(PDOException $e){
                Db::rollback();
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }


        }

    }

    /**
     * [ tjtcEditItems套餐增加多选组合项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function dwfzEditItems()
    {
        if (request()->isAjax()) {


            $data = input('get.zhxmdt/a');
            $dwid= input('param.dwid');
            $fzid= input('param.fzid');
            $param[]=[];



            foreach($data as $key=>$each){

                $each['hospitalid']=session('hospitalid');
                $param[$key]=$each;


            }


           Db::startTrans();

           try{


                $flag = Model('DwfzDtModel')->saveAll($param,false);
                if($flag==false) {

                    Db::rollback();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加分组套餐组合项目失败(ID='. session('hospitalid').'-'. $dwid . '-'. $fzid.' )', 2);
                    return json(['code' => 0, 'data' => '', 'msg' => '添加组合项目失败']);
                } else {

                    $jg=Model('DwfzDtModel')->getDwfzjg(  $dwid, $fzid );
                    //更新分组套餐价格，如果是打折套餐并且审核过设置未未审核
                    Model('DwfzModel')->where(['dwid'=>$dwid,'id'=>$fzid,'hospitalid'=>session('hospitalid')])
                                        ->update(['jg'=>$jg,'sfsh'=>['exp','case sfsh when 1 then 0 else 0 end']]);

                    Db::execute('exec  SP_Dwfzzk '.session('hospitalid').','. $dwid.','. $fzid);
                    Db::commit();

                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加分组套餐组合项目失败(ID='. session('hospitalid').'-'. $dwid . '-'. $fzid . ')', 1);
                    return json(['code' => 1, 'jg' => $jg, 'msg' => '添加组合项目成功']);
                }
            }catch(PDOException $e){
                Db::rollback();
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }

        }

    }

    /**
     * @return \think\response\Json
     * 移除已选择的组合项目(单个)
     */
    public function zhxmSelDel()
    {
        if(request()->isAjax()) {
            $dwid = input('param.dwid');
            $zhxmid = input('param.zhxmid');
            $fzid = input('param.fzid');
            /* $dwids=Model('TjdwModel')->getTjdwChilren($param['dwid']);
            if(!empty(Model('TjdjModel')->where(['hospitalid'=>session('hospitalid'),'dwid'=>['in',$dwids],'tcid'=>$param['fzid']])->select())) {
                          Db::rollback();
                          return ['code' => 0, 'data' => '', 'msg' =>'单位分组已被体检引用不可删除组合项目'];
            }*/
            $flag = Model('DwfzDtModel')->delSelZhxm($dwid,$fzid,$zhxmid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }
    /**
     * @return \think\response\Json
     * 移除已选择的组合项目(多项)
     */
    public function zhxmMulDel()
    {
        if(request()->isAjax()) {
            $zhxmids= input('zhxmids');
            $dwid = input('dwid');
            $fzid = input('fzid');
            /* $dwids=Model('TjdwModel')->getTjdwChilren($param['dwid']);
           if(!empty(Model('TjdjModel')->where(['hospitalid'=>session('hospitalid'),'dwid'=>['in',$dwids],'tcid'=>$param['fzid']])->select())) {
                         Db::rollback();
                         return ['code' => 0, 'data' => '', 'msg' =>'单位分组已被体检引用不可删除组合项目'];
           }*/
            $flag = Model('DwfzDtModel')->delMulZhxm($dwid,$fzid,$zhxmids);
            return json(['code' =>  $flag['code'], 'data' =>$flag['data'], 'msg' =>  $flag['msg']]);

        }
    }




}