<?php

namespace app\admin\controller;
use think\Controller;
use think\Cache;


class Setting extends Base
{


    /**
     * [index 设置项]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function clear_cache()
    {
        if (request()->isAjax()) {
            $res = Cache::clear();
            // $res =Cache::stroe('file','tag')->clear();
            // Cache::store('file')->clear();
            // Cache::store('temp')->clear();
            if ($res == false)
                return json(['code' => 0, 'data' => '', 'msg' => '清除缓存失败']);
            else
                return json(['code' => 1, 'data' => '', 'msg' => '缓存已清除']);
        }

    } 
	
	
}