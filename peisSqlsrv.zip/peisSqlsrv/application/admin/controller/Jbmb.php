<?php

namespace app\admin\controller;
use app\admin\model\ JbmbModel;
use app\admin\model\JbmbCjjgModel;
use think\console\command\make\Model;
use think\Db;


class Jbmb extends Base
{

    /**
     * [index 疾病统计模板]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
	 

	 
    public function index(){


        return $this->fetch();
		

    }


    public function getOneJbmb(){


        $jbmb = new JbmbModel();
        $id = input('param.id');
        return json($jbmb->getOneJbmb($id));


    }



    /**
     * [jbmbEdit 根据提交方式添加编辑疾病模板]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jbmbEdit()
    {
        $jbmb = new JbmbModel();

        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增

                $param = input('post.');
                $flag =  $jbmb ->editJbmb($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }else {//get 为获取数据


                $id = input('param.id');
                return json($jbmb->getOneJbmb($id));
            }
        }


    }


    /**
     * [ jbmbDel 删除疾病模板]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jbmbDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.mc');
            $jbmb = new JbmbModel();
            $flag = $jbmb->delJbmb($id,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }



    /**
     * [ jbmbDel 删除疾病模板疾病信息]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jbmbCjjgDel()
    {
        if(request()->isAjax()) {
            $jbmbid = input('param.jbmbid');
            $cjjgid = input('param.cjjgid');
            $name = input('param.name');
            $jbmbcjjg = new JbmbCjjgModel();
            $flag = $jbmbcjjg->delJbmbCjjg($jbmbid,$cjjgid,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * @return \think\response\Json
     * 移除已选择的常见结果(多项)
     */
    public function cjjgMulDel()
    {
        if(request()->isAjax()) {
            $cjjgids= input('cjjgids');
            $jbmbid = input('jbmbid');
            $flag = Model('JbmbCjjgModel')->delMulcjjg($jbmbid ,$cjjgids);
            return json(['code' => $flag['code'], 'data' =>$flag['data'], 'msg' => $flag['msg']]);

        }
    }
    /**
     * [ editSoft 调整疾病模板排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $jbmb= new JbmbModel();
            $flag = $jbmb->editSoft($id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }



    /**
     * [ softCjjgEdit 调整疾病模板疾病信息排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softCjjgEdit()
    {
        if(request()->isAjax()) {
            $jbmbid = input('param.jbmbid');
            $cjjgid = input('param.cjjgid');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $jbmbcjjg= new JbmbCjjgModel();
            $flag = $jbmbcjjg->editCjjgSoft($jbmbid,$cjjgid,$type,$targetid);
             return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

        }
    }


    //疾病模板疾病信息编辑（常见结果）
    public function jbmbCjjgAdd()
    {
        if(request()->isAjax()) {

               // $jbmbid = input('param.jbmbid');
               // $tjlxid = input('param.tjlxid');
               // $cjjgid = input('param.cjjgid');
                $param = input('post.');
                $jbmbcjjg = new JbmbCjjgModel();
                $flag = $jbmbcjjg->jbmbAddCjjg($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

        }
    }
    //添加多组未体检项目
    public function jbmbCjjgAdds()
    {
        if (request()->isAjax()) {


            $param = input('get.jbmbCjjg/a');



             $flag = Model('JbmbCjjgModel')->jbmbAddsCjjg($param);

             return json(['code' => $flag['code'], 'data' =>$flag['data'], 'msg' => $flag['msg']]);


        }
    }



    //获取疾病模板树
    public function giveJbmb()
    {
        //$param = input('param.');

        //获取现有的临床类型
      //  if('get' == $param['type']){

        if (request()->isAjax()) {
            $result = Db::name('jbmb_hd')->where(['isdel'=> 1,'hospitalid'=>session('hospitalid')])->order('softid')->select();

            $str = '[{"id":"0","name":"疾病模板", "open":"true","childOuter":"false","children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }



    //获取已选疾病信息树
    public function giveSelCjjg($jbmbid,$key)
    {
        if (request()->isAjax()) {
            $map = [];
            if (!empty($key))
                $map['ms|pyjm|wbjm'] = ['like', '%' . $key . '%'];

            $result = Db::name('jbmb_cjjg bmjg')->join('cjjg jg', 'bmjg.cjjgid=jg.id', 'left')
                ->field('id,ms,bmjg.softid')
                ->where('jbmbid', $jbmbid)
                ->where($map)
                ->order('softid')
                ->select();

            $str = '[{"id":"0","name":"已选疾病信息", "open":"true","childOuter":"false","children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['ms'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }





}