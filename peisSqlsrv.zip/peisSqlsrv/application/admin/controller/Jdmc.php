<?php

namespace app\admin\controller;
use app\admin\model\ JdmcModel;
use think\Db;
use think\exception\PDOException;


class Jdmc extends Base
{

    /**
     * [index 街道名称]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
	 

	 
    public function index(){


        return $this->fetch();
		

    }




    /**
     * [jdmcEdit 根据医院添加街道]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jdmcEdit()
    {
        $jdmc = new JdmcModel();



            if (request()->isAjax()) { //ajax 提交

                if (request()->isPost()) { // 判断提交方式 post为 更新和新增

                    $param = input('post.');
                    $flag = $jdmc->editJdmc($param);
                    return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

                } else {//get 为获取数据

                    try {
                        $id = input('param.id');
                        return json(['code' => 1, 'data' => $jdmc->getOneJdmc($id), 'msg' =>'OK']);
                        // dump(json([ $lclx->getOneLclx($id)]));
                        //$this->ajaxReturn($lclx->getOneLclx($id),'JSON');
                    } catch (PDOException $e) {

                        return json(['code' => 0, 'data' => '', 'msg' =>'获取数据失败']);
                    }
                }
            }

    }


    /**
     * [ jdmcDel 删除街道]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jdmcDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.mc');
            $jdmc = new JdmcModel();
            $flag = $jdmc->delJdmc($id,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ editSoft 调整街道排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $jdmc= new JdmcModel();
            $flag = $jdmc->editSoft($id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    //获取街道名称树
    public function giveJdmc()
    {
        //$param = input('param.');

        //获取现有的临床类型
        //  if('get' == $param['type']){
        if (request()->isAjax()) {

            $result = Model('jdmcModel')->where(['isdel' => 1, 'hospitalid' => session('hospitalid')])->field('id,mc,softid')->order('softid')->select();

            $str = '[{"id":"0","name":"街道名称", "open":"true","childOuter":"false","children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }

    }


}