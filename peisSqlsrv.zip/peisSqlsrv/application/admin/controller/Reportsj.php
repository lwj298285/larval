<?php
namespace app\admin\controller;
use think\console\command\make\Model;
use think\Controller;
use think\Db;
class ReportSj extends Base{



    /**
     * [index 报表模板设计]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
public function index(){


    //$mbfile=Model('ReportglModel')->where(['isdel'=>1,'hospitalid'=>session('hospitalid')])->select();
   // $this->assign('mbfile',$mbfile);
    return $this->fetch();
}

//获取报表模板
    public function getReportMb(){
        if(request()->isAjax()){
            $id=input('param.id');
            $mb=Model('ReportglModel')->where(['id'=>$id,'isdel'=>1])->value('mbfile');
            if($mb==false){
                return json(['code'=>0,'data'=>'','msg'=>'获取报表下报表模板失败']);
            }else{
                return json(['code'=>1,'data'=>$mb,'msg'=>'获取报表下报表模板成功']);
            }
        }
    }


//调用同一类型报表下的报表模板
/*public function getReport(){
    if(request()->isAjax()){

       $result=Model('ReportglModel')->where(['name'=>'','isdel'=>1,'hosipalid'=>session('hosipalid')])->select();

    }
}*/

}