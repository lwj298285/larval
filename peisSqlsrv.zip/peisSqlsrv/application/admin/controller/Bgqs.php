<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/26
 * Time: 10:47
 */

namespace app\admin\controller;
use think\Db;
use think\Config;
use think\exception\PDOException;

class Bgqs extends Base
{


    /**
     * [index 体检报告]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index()
    {



      /*  $xtcs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>['in','tjbg,sfxhdy']])->select();

        $bgname=array_column(arrWhereAnd($xtcs, ['mc' => 'tjbg']),'value');
        $sfxhdy=array_column(arrWhereAnd($xtcs, ['mc' => 'sfxhdy']),'value');

        $tjbgname=empty($bgname)?"":$bgname[0];
        $this->assign('sfxhdy',empty($sfxhdy)?"": $sfxhdy[0]);


        $tjbg=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>$tjbgname,'isdel'=>1])->select();
        $this->assign('tjbg',$tjbg);

        $tjbgdefault=collection(arrWhereAnd($tjbg, ['isdefault'=>1]));

        $this->assign('zjbgmbfile',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('mbfile')[0]);
        $this->assign('zjbgmbcs',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('mbcs')[0]);
        $this->assign('zjbgid',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('id')[0]);*/


        return $this->fetch();

    }


    //签收报告

    public function bgQs(){

        if (request()->isAjax()) {
            try {


                $djlsh = input('param.djlsh');
                 model('TjdjModel')->where(['djlsh' => ['in',$djlsh], 'hospitalid' => session('hospitalid')])->setField('jdbz',70);


                writelog(session('uid'), session('username'),'操作签收报告成功',1);

                return json(['code' => 1, 'data' => '', 'msg' => '签收报告成功']);

            } catch (\Exception $e) {
                writelog(session('uid'), session('username'),'操作签收报告失败',2);

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }
        }

    }


    public function cancelQs(){

        if (request()->isAjax()) {
            Db::startTrans();
            try {


                $djlsh = input('param.djlsh');
                model('TjdjModel')->where(['djlsh' => ['in',$djlsh], 'hospitalid' => session('hospitalid'),'fsr'=>['exp',' is not null']])->setField('jdbz',60);
                model('TjdjModel')->where(['djlsh' => ['in',$djlsh], 'hospitalid' => session('hospitalid'),'fsr'=>['exp',' is null']])->setField('jdbz',50);
                Db::commit();

                writelog(session('uid'), session('username'),'操作取消报告签收成功',1);
                return json(['code' => 1, 'data' => '', 'msg' => '取消报告签收成功']);

            } catch (\Exception $e) {
                Db::rollback();
                writelog(session('uid'), session('username'),'操作取消报告签收失败',2);
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }
        }

    }


}
