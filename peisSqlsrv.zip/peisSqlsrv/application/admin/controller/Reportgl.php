<?php
namespace app\admin\controller;
use app\admin\model\ReportglModel;
use think\Db;
use think\exception\ErrorException;
use think\File;
use think\Config;
use think\exception\PDOException;
use org\Upload;

class Reportgl  extends Base
{


    /**
     * [index 报表模板管理]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index()
    {

        return $this->fetch();
    }




    //删除报表模板数据
    /**
     * @return \think\response\Json
     */
    public function getOneReport($id){
        if(request()->isAjax()){
           try {
               $result = Model('ReportglModel')->where(['hospitalid' => session('hospitalid'), 'id' => $id])->find();
               return json(['code' => 1, 'data' => $result, 'msg' => 'ok']);

           }catch (ErrorException $e) {
               return json(['code' => 0, 'data' =>'', 'msg' => $e->getMessage()]);
           }
        }
    }


    //添加及更新报表模板信息
    /**
     * @return \think\response\Json
     */
    public function reportEdit()

    {
        try {

            if (request()->isAjax()) {
                if (request()->isPost()) {
                    //提交添加 修改  上传文件
                    $param = request()->except('filename', 'post');
                    $file =request()->file('filename');
                    //$file = $_FILES['filename'];

                    if ($file) {
                        //存在上传文件
                        //$file->setSaveName('快快快');
                     //   $param['mbfile'] =$_FILES['filename']['name'];
                        $filename=session('hospitalid').session('username').time();
                        $param['mbfile'] =$filename.".grf";
                        $new_file = UPLOAD_PATH . "report/";
                        $flag = Model('ReportglModel')->editReport($param);

                        if ($flag['code'] == 1 || $flag['code'] == 2) {
                            //模板信息写人数据成功处理文件上传
                            if (!file_exists($new_file))
                                mkdir($new_file, 0700);


                            //move_uploaded_file($_FILES["filename"]["tmp_name"], iconv("UTF-8", "gb2312", $_FILES['filename']['tmp_name']));
                            $file->move(ROOT_PATH . 'public' . DS . 'report',iconv('utf-8','gb2312',$filename),true);
                            // $file->setSaveName('快快快');
                            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

                        } else {
                            //模板信息写人数据失败
                            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
                        }


                    } else {
                        //不存在上传文件
                        if (empty($param['mbfile'])) {
                            //模板名称不存在，没选择文件返回提示
                            return json(['code' => 0, 'data' => '', 'msg' => '请选择上传报表模板文件！']);
                        } else {
                            //模板名称存在编辑数据库模板信息不处理文件
                            $flag = Model('ReportglModel')->editReport($param);
                            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

                        }
                    }

                } else {
                    //获取报表模板信息
                    $id = input('param.id');
                    $data=Model('ReportglModel')->where(['id' => $id, 'isdel' => 1])->find();
                    return json(['code'=>1,'data'=>$data,'msg'=>'ok']);
                }

            }
        }catch(\ErrorException $e){
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' =>$e->getMessage()]);
        }

    }


    //添加及更新报表参数
    public function mbcsEdit(){
        if(request()->isAjax()){
            $param=[];
            $param['id']=input('param.id');

            $mbcs=input('param.mbcs/a');
            $csstr="";

            foreach($mbcs as $k=>$v){
                $csstr.="'".$v['mbcs']."':'".$v['cslx']."',";

            }

            if (strlen($csstr)>0)
                $param['mbcs']="{".substr($csstr, 0, -1)."}";
            else
                $param['mbcs']="";

            $flag=Model('ReportglModel')-> editMbcs($param);

            return json(['code' =>$flag['code'],'data' => $flag['data'], 'msg' => $flag['msg']]);

        }


}

//获取报表名称信息及报表模板
    /**
     * @return \think\response\Json
     */
    public function giveReport()
    {
        if (request()->isAjax()) {

             $report = Model('ReportglModel')->where(['isdel' => 1,'hospitalid'=>session('hospitalid')])->field('id,name,mbmc,mbfile,sortid')->order('sortid')->select();
           // $report = Model('ReportglModel')->where('isdel' , 1)->field('id,name,mbmc,mbfile,sortid')->order('sortid')->select();
            //$jbzd=arrWhereAnd($map);
            $str = '[{"id":"0","name":"报表管理", "open":"true","childOuter":"true", "isParent":"true","children":[';

            $zdlx = Model('JbzdModel')->where(['isdel' => 1,'dictype'=>'BBFL'])->field('id,name,softid')->order('softid')->select();//['QYXZ'=>1,'HYZK'=>2,'ZZGX'=>3,'BXLB'=>4];


            foreach ($zdlx as $k => $v) {

                $str .= '{"id":"' . $v['name']. '","name":"' . $v['name'] . '","pid":"0", "open":"false","childOuter":"true", "isParent":"true","children":[';

                $currzd = arrWhereAnd($report, ['name' => $v['name']]);
                if ($currzd) {
                    foreach ($currzd as $key => $vo) {
                        $str .= '{ "id": "' . $vo['id'] . '", "pid":"' . $v['name'] . '", "name":"' . $vo['mbmc'] . '"},';

                    }

                    $str = substr($str, 0, -1);

                }

                $str .= ']},';

            }


            $str = substr($str, 0, -1);
            $str .= ']}]';

            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }

    }



    //删除报表模板数据
    /**
     * @return \think\response\Json
     */
    public function reportDel(){
        if(request()->isAjax()){
            $id=input('param.id');
            $flag=Model('ReportglModel')->delReport($id);

            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }
    }


    //排序报表模板
    /**
     * @return \think\response\Json
     */
    public function softEdit(){
        if(request()->isAjax()){
            $id=input('param.id');
            $type=input('param.type');
            $targetid=input('param.targetid');
            $flag=Model('ReportglModel')->editSoft($id,$targetid,$type);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }

    }
}