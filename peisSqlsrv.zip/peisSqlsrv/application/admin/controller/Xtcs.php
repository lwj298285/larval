<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 13:52
 */

namespace app\admin\controller;


use think\console\command\make\Model;

class Xtcs extends Base
{


    /**
     * [index 系统参数]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){


        return $this->fetch();
    }

    //添加及更新系统参数
    public function editXtcs(){
        if(request()->isAjax()){
            if(request()->isPost()){
                $param=input('post.');
                $flag=Model('XtcsModel')->xtcsEdit($param);
                return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
            }else{
                $id=input('param.id');
                $flag=Model('XtcsModel')->where('id',$id)->find();
                if($flag==false)
                    return json(['code'=>0,'data'=>'','msg'=>'获取数据失败' ]);
                else
                    return json(['code'=>1,'data'=>$flag,'msg'=>'ok']);
            }
        }
    }
//获取系统参数信息
    public function giveXtcs(){
        if(request()->isAjax()){
            $result=Model('XtcsModel')->where('isdel',1)->field('mc,zwmc,value,comment,id,softid')->order('softid')->select();
            $str='[{"id":0,"name":"系统参数","open":"true","childOuter":"true","isParent":"true","children":[';
            if($result){
                foreach($result as $k=>$v){
                    $str.='{"id":"'.$v['id'].'","name":"'.$v['zwmc'].'","pId":"0"},';
                }
                $str=substr($str,0,-1);
            }
            $str.=']}]';
            return json(['code'=>1,'data'=>$str,'msg'=>'OK']);
        }

    }

//删除系统参数
    public function  xtcsDel(){
        if(request()->isAjax()){
            $id=input('param.id');
            $flag=Model('XtcsModel')->delXtcs($id);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }
    }
//排序
    public function softEdit(){
        $id=input('post.id');
        $targetid=input('post.targetid');
        $type=input('post.type');
        $flag=Model('XtcsModel')->editSoft($id,$targetid,$type);
        return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
    }
}