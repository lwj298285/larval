<?php
namespace app\admin\controller;
use app\admin\model\UserModel;
use think\console\command\make\Model;
use think\Db;
use think\Config;
use think\exception\PDOException;

class Ysqx extends Base {


    /**
     * [index 科室权限]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){

        return $this->fetch();
    }


 //批量授权
public function editMulDepAuth(){
    if(request()->isAjax()){ //ajax 提交

        $param=input('data/a');
        $jobnum=input('jobnum/a');
        $flag =Model('YsqxModel')->depMulAuthEdit($param,$jobnum);
        return json(['code' => $flag['code'], 'data' => $flag['data'],'msg' => $flag['msg']]);
    }
}

//单个授权
    public function editDepAuth(){
        if(request()->isAjax()){ //ajax 提交

            $param=input('data/a');
            $jobnum=input('param.jobnum');

            $flag =Model('YsqxModel')->depAuthEdit($param,$jobnum);
            return json(['code' => $flag['code'], 'data' => $flag['data'],'msg' => $flag['msg']]);
        }
    }

//获取所有科室
    public function giveTjlx()
    {

        if(request()->isAjax()) {
            //获取所有体检类型

            try {
                $result = Model('DepartmentModel')->getDepartments();

                $str = '[{"id":"0","name":"科室权限信息", "open":"true","childOuter":"false","isParent":"true","children":[';

                if ($result) {

                    foreach ($result as $key => $vo) {
                        //添加体检类型
                        $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","iconSkin":"dep","children":[';
                        //添加权限
                        $str .= '{ "id": "0","name":"查看 ","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '"},';
                        $str .= '{ "id": "1","name":"添加","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"add"},';
                        $str .= '{ "id": "2","name":"修改","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"edit"},';
                        $str .= '{ "id": "3","name":"删除","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"remove"},';
                        $str .= '{ "id": "4","name":"弃检","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"diy02"},';
                        $str .= '{ "id": "5","name":"小结","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"note"}';



                        $str .= ']},';

                    }
                    $str = substr($str, 0, -1);
                }

                //根节点结束
                $str .= ']}]';


                return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
            }catch(PDOException $e){
                return json(['code' => 0, 'data' => '', "msg" => $e->getMessage()]);
            }
        }


    }

    //获取医院所有人员
    public function giveJobnum($key)
    {

        if(request()->isAjax()) {
            try {
                //获取所有体检类型
                $map = ['isdel&status' => 1, 'hospitalid' => session('hospitalid')];

                if (!empty($key))
                    $map['jobnum|username|real_name'] = ['like', '%' . $key . '%'];


                $result = Model('UserModel')->field('jobnum,username,real_name,sex')->where($map)->select();

                $str = '[{"id":"0","name":"人员信息", "open":"true","childOuter":"false","isParent":"true","children":[';

                if ($result) {

                    foreach ($result as $key => $vo) {
                        //添加体检类型
                        if ($vo['sex'] == 1)
                            $str .= '{ "id": "' . $vo['jobnum'] . '","name":"' . $vo['real_name'] . '('. $vo['username'] .')","childOuter":"false","open":"false","isParent":"false","pid":"0","iconSkin":"man"},';
                        else
                            $str .= '{ "id": "' . $vo['jobnum'] . '","name":"' . $vo['real_name'] . '","childOuter":"false","open":"false","isParent":"false","pid":"0","iconSkin":"woman"},';

                    }
                    $str = substr($str, 0, -1);
                }

                //根节点结束
                $str .= ']}]';


                return json(['code' => 1, 'data' => $str, "msg" => "OK"]);

            }catch(PDOException $e){
                return json(['code' => 0, 'data' =>'', "msg" => $e->getMessage()]);
            }
        }


    }


    //获取人员科室权限信息
    public function   giveJobnumAuth($jobnum){

        if(request()->isAjax()){
            try {


                $result = Model('DepartmentModel')->getDepartments();
                $depauth = Model('YsqxModel')->where('jobnum',$jobnum)->select();


                $str = '[{"id":"0","name":"人员科室权限信息", "open":"true","childOuter":"false","isParent":"true","children":[';

                if ($result) {

                    foreach ($result as $key => $vo) {
                        //添加体检类型
                       // $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","iconSkin":"dep","children":[';

                        $tjlxauth=arrWhereAnd($depauth, ['tjlxid' =>$vo['depid']]);

                        if (empty($tjlxauth))
                            $auth="";
                        else
                            $auth=  array_column($tjlxauth,'depauth')[0];
                      //  return  json(['code' => 1, 'data' => $auth, "msg" =>'']);

                        //添加体检类型
                        if (!empty( $auth))
                            $str .= '{ "id": "' . $vo['depid'] . '","checked":"true","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","iconSkin":"dep","children":[';
                        else
                            $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","iconSkin":"dep","children":[';

                        if (strstr( $auth,"0")!==false)
                            $str .= '{ "id": "0","checked":"true","name":"查看 ","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '"},';
                        else
                            $str .= '{ "id": "0","name":"查看 ","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '"},';

                        if (strstr( $auth,"1")!==false)
                            $str .= '{ "id": "1","checked":"true","name":"添加","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"add"},';
                        else
                            $str .= '{ "id": "1","name":"添加","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"add"},';

                        if (strstr( $auth,"2")!==false)
                            $str .= '{ "id": "2","checked":"true","name":"修改","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"edit"},';
                        else
                            $str .= '{ "id": "2","name":"修改","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"edit"},';

                        if (strstr( $auth,"3")!==false)
                            $str .= '{ "id": "3","checked":"true","name":"删除","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"remove"},';
                        else
                                  $str .= '{ "id": "3","name":"删除","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"remove"},';

                        if (strstr( $auth,"4")!==false)
                            $str .= '{ "id": "4","checked":"true","name":"弃检","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"diy02"},';
                        else
                            $str .= '{ "id": "4","name":"弃检","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"diy02"},';

                        if (strstr( $auth,"5")!==false)
                            $str .= '{ "id": "5","checked":"true","name":"小结","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"note"}';
                        else
                            $str .= '{ "id": "5","name":"小结","childOuter":"false","open":"false","isParent":"false","pid":"' . $vo['depid'] . '","iconSkin":"note"}';



                        $str .= ']},';

                    }
                    $str = substr($str, 0, -1);
                }

                //根节点结束
                $str .= ']}]';


                return json(['code' => 1, 'data' => $str, "msg" => "OK"]);

            } catch(PDOException $e){

                 return json(['code' => 0, 'data' => '', "msg" => $e->getMessage()]);

            }

        }}



}