<?php

namespace app\admin\controller;

use app\admin\model\TjdwModel;
use app\admin\model\SelectdicModel;
use think\Db;
use think\Config;

class Tjdw extends Base
{
	/**
	 * [index 体检单位]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	
	
	public function index(){
		
		//$nature = input('nature');
		//$selectdic = new SelectdicModel();
        $jmdj = get_json_emlement('dictionary.json', 0, 'jmdj');
        $this->assign('jmdj', $jmdj);
		$this->assign('qyxz',Model('JbzdModel')->field('id,name')->where(['dictype'=>'QYXZ','isdel'=>1])->select());
		//$this->assign('selectdic_id', $nature);
		
		//$nav = new \org\Leftnav;
		//$tjdwp = new TjdwModel();
		//$tjdwpid = $tjdwp->getAllTjdw();
		//$arr = $nav::rule($tjdwpid);
		//$this->assign('tjdwpid',$arr);
		
		return $this->fetch();
		
	}
	




	/**
	 * [tjdwdit 添加删除体检单位]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function tjdwEdit()
	{
		$tjdw = new TjdwModel();
		
		if(request()->isAjax()) { //ajax 提交
			
			if (request()->isPost()) { // 判断提交方式 post为 更新和新增
				
				$param = input('post.');
				$flag = $tjdw->editTjdw($param);
				return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
			} else {//get 为获取数据
				
				$id = input('param.id');
				return json($tjdw->getOneTjdw($id));
			}
		}
		
		
	}


//获取体检单位异步返回
    public function getTjdw()
    {
        return json(Model('TjdwModel')->where(['isdel&status'=>1,'hospitalid'=>session('hospitalid')])->order('id asc')->select());
    }
	
	/**
	 * [tjdwDel 删除体检单位]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function tjdwDel()
	{
		if(request()->isAjax()) {
			$ids = input('param.ids');
			$name = input('param.name');
			$tjdw = new TjdwModel();
			$flag = $tjdw->delTjdw($ids,$name);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	


	//获取体检单位树状结构数据
	public function giveTjdw($text,$status="falses")
	{
        if (request()->isAjax()) {
            $where['isdel'] = 1;
            if ($status == "true")
                $where['status'] = 1;
            $where['hospitalid'] = session('hospitalid');

            if (!empty($text))
                $where['dwname|pyjm|wbjm'] = ['like', '%' . $text . '%'];

            $result = Model('TjdwModel')->where($where)->field('id,pid,dwname,status,softid')->order('softid')->select();

            $str = '{"id":"0","name":"体检单位", "open":"true","isParent":"true","childOuter":"false"},';
            if ($result) {
                foreach ($result as $key => $vo) {
                    //看组合项目是否启用显示不同图标
                    $icon = '';
                    if ($vo['status'] == 0)
                        $icon = ',"iconSkin":"diy02"';
                    $str .= '{ "id": "' . $vo['id'] . '", "pId":"' . $vo['pid'] . '", "name":"' . $vo['dwname'] . '"' . $icon . '},';
                }
            }

            return json(['code' => 1, 'data' => "[" . substr($str, 0, -1) . "]", "msg" => "OK"]);
        }
	}
	
	/**
	 * [ editSoft 调整体检单位排序]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	public function softEdit()
	{
		if(request()->isAjax()) {
			$id = input('param.id');
			$type = input('param.type');
			$targetid = input('param.targetid');
			$tjdw = new TjdwModel();
			$flag = $tjdw>editSoft($id,$type,$targetid);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	



	
}