<?php

namespace app\admin\controller;
use app\admin\model\TjdjModel;
use app\admin\model\TjjlbModel;
use think\Db;
use think\exception\PDOException;

class Qrydj extends Base
{

    /**
     * [index 确认预登记]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {
       //获取当前日期时间戳

       return $this->fetch();
    }









}