<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/26
 * Time: 10:47
 */

namespace app\admin\controller;
use think\Db;
use think\Config;
use think\exception\PDOException;

class Tjbg extends Base
{


    /**
     * [index 体检报告]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index()
    {



        $xtcs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>['in','tjbg,sfxhdy']])->select();

        $bgname=array_column(arrWhereAnd($xtcs, ['mc' => 'tjbg']),'value');
        $sfxhdy=array_column(arrWhereAnd($xtcs, ['mc' => 'sfxhdy']),'value');

        $tjbgname=empty($bgname)?"":$bgname[0];
        $this->assign('sfxhdy',empty($sfxhdy)?"": $sfxhdy[0]);


        $tjbg=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>$tjbgname,'isdel'=>1])->select();
        $this->assign('tjbg',$tjbg);

        $tjbgdefault=collection(arrWhereAnd($tjbg, ['isdefault'=>1]));

       /* $this->assign('zjbgmbfile',empty($tjbgdegault)?"":$tjbgdegault[0]['mbfile']);
        $this->assign('zjbgmbcs',empty($tjbgdegault)?"":$tjbgdegault[0]['mbcs']);
        $this->assign('zjbgid',empty($tjbgdegault)?"":$tjbgdegault[0]['id']);*/
        $this->assign('zjbgmbfile',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('mbfile')[0]);
        $this->assign('zjbgmbcs',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('mbcs')[0]);
        $this->assign('zjbgid',$tjbgdefault->isEmpty()?"":$tjbgdefault->column('id')[0]);


        return $this->fetch();

    }


   public function getBblxReport($reportname){
          if(request()->isAjax()) {
              return json(Model('ReportglModel')->where(['name'=>$reportname,'isdel'=>1,'hospitalid'=>session('hospitalid')])->select());
          }
 }

  /* public function tjbgEdit(){
        if(request()->isAjax()){
            if(request()->isPost()){
                Db::startTrans();
                try{
                    $param['mbfile']=input('post.tjbg');
                    $param['id']=input('post.tjid');
                    $result=Model('ReportglModel')
                        ->where(['id'=>$param['id'],'mbfile'=>$param['mbfile'],'hospitalid'=>session('hospitalid')])
                         ->setField(['isdefault'=>1]);
                    if($result==false){
                        Db::rollback();
                        return json(['code'=>0,'data'=>'','msg'=>'选择体检报告失败!']);
                    }else{
                        Db::commit();
                        return json(['code'=>1,'data'=>$result,'msg'=>'选择体检报告成功!']);
                    }
                }catch (PDOException $e){
                    Db::rollback();
                    return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
                }
            }else{

            }


        }
    }*/


}
