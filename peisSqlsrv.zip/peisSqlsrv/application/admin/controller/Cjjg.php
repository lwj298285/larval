<?php

namespace app\admin\controller;
use app\admin\model\CjjgModel;
use think\Db;
use think\Collection;
use think\exception\PDOException;

class Cjjg extends Base

{



    /**
     * [index 常见结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){




        return $this->fetch();




    }




    /**
     * [ cjjgEdit 添加修改体检项目结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function cjjgEdit()
    {
        $cjjg = new CjjgModel();

       if(request()->isAjax()){ //ajax 提交

           $param=input('data/a',null,null);
           unset($param['ROW_NUMBER']);
           unset($param['index']);

           $flag =   $cjjg->editCjjg($param);
           return json(['code' => $flag['code'], 'data' => $flag['data'], 'id'=> $flag['id'],'msg' => $flag['msg']]);
       }


    }


    /**
     * [ cjjgDel 删除体检项目结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function cjjgDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $ms= input('param.ms');
            $cjjg = new CjjgModel();
            $flag = $cjjg->delCjjg($id,$ms);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }




    //获取体检项目结果列表
    public function getCjjgList()
    {
        if(request()->isAjax()) {
            try{

                $tjxmid = input('param.tjxmid');
                $lsits = Model('CjjgModel')->alias('jg')->join('xjjy jy','jg.zdid=jy.id and jy.isdel=1','left')
                        ->field('jg.*,jy.zyzd,jy.jynr')
                        ->where(['tjxmid'=>$tjxmid,'jg.isdel'=>1])->select();

                //--------获取体检项目结果类型区别前端结果列表编辑显示方式---0文字  数值-----//
               // $tjxm= Model('TjxmModel')->where('id',$tjxmid)->find();


                return json(['code'=>1,'data'=>$lsits,'msg' => '']);

          }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg' => $e->getMessage()]);
           }
        }
    }


    //获取体检项目结果列表
    public function getCjjg()
    {
        if(request()->isAjax()) {
            try{

                $tjxmid = input('param.tjxmid');
                $lsits = Model('CjjgModel')->alias('jg')->join('xjjy jy','jg.zdid=jy.id and jy.isdel=1','left')
                    ->field('jg.*,jy.zyzd,jy.jynr')
                    ->where(['tjxmid'=>$tjxmid,'jg.isdel'=>1])->select();

                //--------获取体检项目结果类型区别前端结果列表编辑显示方式---0文字  数值-----//
                // $tjxm= Model('TjxmModel')->where('id',$tjxmid)->find();


                return  $lsits;

            }catch (PDOException $e){

                return [];
            }
        }
    }

    //获取体检项目结果（疾病信息）树
    public function giveCjjg($jbmbid,$tjlxid,$lclxid,$key)

    {

        if (request()->isAjax()) {
            try {
                $where = [];
                $where = ['jg.tjlxid' => $tjlxid, 'isdel' => 1];
                if (!empty($key))
                    $where['jg.ms|jg.pyjm|jg.wbjm'] = ['like', '%' . $key . '%'];
                if (!empty($lclxid))
                    $where['lclxid'] = ['=', $lclxid];

                $data = model('CjjgModel')->alias('jg')->join('jbmb_cjjg mbjg', 'jg.id=mbjg.cjjgid and mbjg.jbmbid=' . $jbmbid, 'left')
                    ->field('jg.tjlxid,id,ms,jbmbid,jg.softid')
                    ->where($where)
                    ->order('softid')
                    ->select();

                $result = arrWhereAnd($data, ['jbmbid' => null]);
                $str = '[{"id":"0","name":"疾病信息", "open":"true","childOuter":"false","children":[';

                if ($result) {
                    foreach ($result as $key => $vo) {
                        $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['ms'] . '"},';

                    }

                    $str = substr($str, 0, -1);

                }

                $str .= ']}]';


                return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', "msg" => $e->getMessage()]);
            }

        }
    }


}


