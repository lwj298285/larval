<?php

namespace app\admin\controller;
use app\admin\model\LisxmModel;
use app\admin\model\XmdzModel;
use think\Db;
use think\Model;


class Xmdz extends Base

{



    /**
     * [index 项目对照]
     * @return [type] [description]
     * @author [李勇] [peis999]
     *
     */
    public function index(){

        return $this->fetch();


    }



    /**
     * [xmdzImport 导入LIS项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xmdzImport()
    {
        $lisxm = new LisxmModel();

        if(request()->isAjax()){ //ajax 提交


              $param = input('lisdata/a');


                $flag =  $lisxm->editLisxm($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);


        }


    }




    //获取Lis项目树 giveTjxm
    public function getXmdz($id){
        if (request()->isAjax()) {

            $map['hospitalid'] = session('hospitalid');
            $map['isdel'] = ['=',1];
            $map['xmid'] = ['=',$id];
            $xmdz = new XmdzModel();
            $xmdzdata = $xmdz->where($map)->select();

            return json(['code' => 1, 'data' => $xmdzdata, "msg" => "OK"]);

        }


     }


    //添加LIS项目对照
    function xmdzAdd()
    {

        if (request()->isAjax()){
            $param=input('param.');
            $xmdz = new XmdzModel();
            $flag = $xmdz->addXmdz($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], "msg" => $flag['msg']]);
         }

    }


    //删除LIS项目对照
    function xmdzDel(){
        if (request()->isAjax()) {
            $param=input('param.');
            $xmdz = new XmdzModel();
            $flag = $xmdz->delXmdz($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], "msg" => $flag['msg']]);
        }

    }


//清除项目对照
   function clearLisXmdz(){

       if (request()->isAjax()) {

           Db::startTrans();

          try{

            Model('XmdzModel')->where('hospitalid',session('hospitalid'))->delete();
            Model('LisxmModel')->where('hospitalid',session('hospitalid'))->delete();


          }catch (\Exception $e){

              Db::rollback();
              return json(['code' => 0, 'data' =>'', "msg" => $e->getMessage()]);

          }
           Db::commit();
           writelog(session('uid'), session('username'), '用户【' . session('username') . '】清除LIS项目对照成功', 1);
           return json(['code' => 1, 'data' => '', "msg" => '清除lis项目对照成功']);
       }

   }

         //获取Lis项目树 giveTjxm
    public function giveLisxm($search)
    {

        if (request()->isAjax()) {
            //获取所有体检类型
            $map = [];
            // $search=input('param.search');
            //  $stauts=input('param.status');
            $map['hospitalid'] = session('hospitalid');

            if (!empty($search))
                $map['xmmc'] = ['like', '%' . $search . '%'];


            $lisxm = new LisxmModel();

            $lisdata = $lisxm->where($map)->select();

            $mechadata = array_unique(array_column($lisdata, 'mechaid'));

            // $mechadata = array_unique($lisdata['mechaid']);

            $str = '[{"id":"0","name":"Lis仪器及项目", "open":"true","childOuter":"false","children":[';

            if ($mechadata) {

                foreach ($mechadata as $key => $vo) {

                    if (!empty($search))
                        $str .= '{ "id": "' . $vo . '","name":"' . $vo. '","childOuter":"false","open":"true","isParent":"true","pid":"0","iconSkin":"close","children":[';
                    else
                        $str .= '{ "id": "' . $vo . '","name":"' . $vo . '","childOuter":"false","open":"false","isParent":"true","pid":"0","iconSkin":"close","children":[';

                    //仪器设备对应的项目

                    $yqxm = arrWhereAnd($lisdata, ['mechaid' => $vo]);
                    if ($yqxm) {

                        //添加体检类型下体检项目
                        foreach ($yqxm as $k => $v) {


                            $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['xmmc'] . '","childOuter":"false","open":"false","pid":"' . $vo . '"},';

                        }
                        $str = substr($str, 0, -1);

                    }

                    $str .= ']},';
                }


                $str = substr($str, 0, -1);

            }



            //根节点结束
            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);

        }

    }


}