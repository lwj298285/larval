<?php
namespace app\admin\controller;
use app\admin\model\JbzdModel;
use think\Db;
use think\Config;
class Jbzd  extends Base
{


    /**
     * [index 基本字典]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {

      //  $this->assign('zdlx',config('zdlx'));
        return $this->fetch();
    }

    /**
     * @return \think\response\Json
     */

    public function jbzdEdit()
    {
        $jbzd = new JbzdModel();
        if (request()->isAjax()){//ajax 提交
            if (request()->isPost()) {// 判断提交方式 post为 更新和新增
                $param = request()->except('dictypename','post');
                $flag = $jbzd->editJbzd($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
            } else {//get 为获取数据
                $id = input('param.id');
                $dictype = input('param.dictype');
                return json($jbzd->getOneJbzd($id,$dictype));
            }
        }
    }

    /**
     * @return \think\response\Json
     */

    public function jbzdDel()
    {
        if (request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
            $dictype = input('param.dictype');
            $jbzd = new JbzdModel();
            $flag = $jbzd->delJbzd($id, $name,$dictype);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * @return \think\response\Json
     */

    public function giveJbzd()
    {
        if (request()->isAjax()) {

            $jbzd = Model('JbzdModel')->where(['isdel' => 1,])->field('id,name,softid,dictype')->order('softid')->select();
            //$jbzd=arrWhereAnd($map);
            $str = '[{"id":"0","name":"基本字典", "open":"true","childOuter":"true", "isParent":"true","children":[';

            $zdlx = config('zdlx');//['QYXZ'=>1,'HYZK'=>2,'ZZGX'=>3,'BXLB'=>4];


            foreach ($zdlx as $k => $v) {

                $str .= '{"id":"' . $k . '","name":"' . $v . '","pid":"0", "open":"false","childOuter":"true", "isParent":"true","children":[';

                $currzd = arrWhereAnd($jbzd, ['dictype' => $k]);
                if ($currzd) {
                    foreach ($currzd as $key => $vo) {
                        $str .= '{ "id": "' . $vo['id'] . '", "pid":"' . $k . '", "name":"' . $vo['name'] . '"},';

                    }

                    $str = substr($str, 0, -1);

                }

                $str .= ']},';

            }


            $str = substr($str, 0, -1);
            $str .= ']}]';

            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }



    /**
     * @return \think\response\Json
     */
    public function softEdit(){
        if(request()->isAjax()){
            $id=input('param.id');
            $type=input('param.type');
            $targetid=input('param.targetid');
            $dictype=input('param.dictype');
            $jbzd=new JbzdModel();
            $flag=$jbzd->editSoft($id,$dictype,$type,$targetid);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }


    }


    public function getTypeZD(){
        if(request()->isAjax()){

            $type=input('param.type');
            $jbzd=new JbzdModel();
            return json($jbzd->getAllJbzd($type));
        }


    }


}