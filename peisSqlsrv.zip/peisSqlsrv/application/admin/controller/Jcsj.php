<?php
namespace app\admin\controller;
// use app\admin\model\TjdjModel;
// use app\admin\model\TjjlbModel;
use think\Db;
use think\exception\PDOException;

class Jcsj extends Base
{
	// $name = 'TJDJB';
    public function Index()
    {
       //获取当前日期时间戳 TjdjviewModel TjdjModel

       return $this->fetch();
    }



    function editJcsj(){
    	$time = Date('Y-m-d H:i:s');
        $djlsh = input('post.djlsh');
        $hospitalid = session('hospitalid');
        
        $result = Model('TjdjModel')->alias('dj')
            ->join('tjjlb jl','dj.hospitalid=jl.hospitalid and dj.tjbh=jl.tjbh and dj.tjcs=jl.tjcs','left')
            ->join('zhxm_hd zhxm','jl.zhxmid=zhxm.id and zhxm.cqch=0')
            ->field('zhxm.mc')
            ->where(['dj.hospitalid'=>$hospitalid,'djlsh'=>$djlsh])
            ->select();

        try {
            if($result === false){

                return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];

            }else{
                if(empty($result)){
                    Model('TjdjModel')->where(['djlsh'=>$djlsh,'hospitalid'=>$hospitalid]) ->setfield('jcsj',$time);
                    return json(['code'=>1,'time'=>$time,'msg'=>'就餐成功']);
                }else{
                    $data = implode('-',array_column($result,'mc')).'，餐前项目未检';
                    return json(['code'=>2,'data'=>$data,'msg'=>'存在未检餐前项目']);
                }
            }
        } catch (PDOException $e) {
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
}