<?php

namespace app\admin\controller;
use app\admin\model\ XmlxModel;
use think\Db;
use think\Config;
use think\exception\ErrorException;

class Xmlx extends Base
{

    /**
     * [index 项目类型]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
	 

	 
    public function index(){


        return $this->fetch();
		

    }





    /**
     * xmlxEdit  添加编辑项目类型]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xmlxEdit()
    {
        $lclx = new XmlxModel();

        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增

                $param = input('post.');
                $flag = $lclx->editXmlx($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }else{//get 为获取数据


                $id = input('param.id');
                return  json($lclx->getOneXmlx($id));
               // dump(json([ $lclx->getOneLclx($id)]));
                //$this->ajaxReturn($lclx->getOneLclx($id),'JSON');
            }
        }


    }


    /**
     * [ lclxDel 项目类型]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xmlxDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
            $xmlx = new XmlxModel();
            $flag = $xmlx->delXmlx($id,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ editSoft 调整项目类型排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $xmlx = new XmlxModel();
            $flag = $xmlx->editSoft($id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    public function giveXmlx()
    {
        if (request()->isAjax()) {
           // $param = input('param.');

            //获取所有科室类型为 1 检验 2功能的科室
            $dep = Model('DepartmentModel')->where(['isdel'=>1,'deptype'=>['<>',0]])->field('id,depname,sortid')->order('sortid')->select();

            $xmlx = Model('XmlxModel')->where('isdel', 1)->field('id,xmlxname,tjlxid,sortid')->order('sortid')->select();


            $str = '[{"id":"0","name":"科室及项目类型", "open":"true","isParent":"true","childOuter":"false","children":[';

            if ($dep) {
                foreach ($dep as $key => $vo) {

                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['depname'] . '","isParent":"true","childOuter":"false","children":[';

                    $deptjxm = arrWhereAnd($xmlx, ['tjlxid' => $vo['id']]);


                    if ($deptjxm) {

                        //添加体检类型下项目类型
                        foreach ($deptjxm as $k => $v) {


                            $str .= '{ "id": "' . $v['id'] . '","name":"' . $v['xmlxname'] . '","childOuter":"false","open":"false","pid":"' . $vo['id'] . '"},';

                        }
                        $str = substr($str, 0, -1);
                    }
                    $str .= ']},';


                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }




}