<?php

namespace app\admin\controller;
use app\admin\model\LogModel;
use think\Db;
use com\IpLocation;
use think\Config;

class Log extends Base
{

    /**
     * [operate_log 操作日志]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function operate_log()
    {

            $hospitalid = input('hospitalid');
            $admin_name = input('admin_name');
            $startdate = input('startdate');
            $enddate = input('enddate');
            // 判断查询条件
            $map['l.isdel'] = ['=', 1];
            if (!empty($hospitalid)) {
                $map['hospitalid'] = ['=', $hospitalid];
            }
            if (!empty(trim($admin_name))) {
                $map['admin_name'] = ['like', '%' . $admin_name . '%'];
            }
            //判断查询时间范围
            if (!empty(trim($startdate))) {

                if (!empty(trim($enddate))) {

                    $map['add_time'] = ['between', [strtotime($startdate), strtotime($enddate . "23:59:59")]];
                } else {

                    $map['add_time'] = ['>', strtotime($startdate)];
                }


            } else {

                if (!empty(trim($enddate))) {

                    $map['add_time'] = ['<', strtotime($enddate . "23:59:59")];
                }
            }

            $hospital = Db::name("hospital ")->field("id,hospitalname")->select();; //获取医院列表
            $Nowpage = input('get.page') ? input('get.page') : 1;
            $limits = 10;// 获取总条数
            $count = Db::name('log l')->where($map)->count();//计算总页面
            $allpage = intval(ceil($count / $limits));
            $lists = Db::name('log l')->join('hospital h', 'l.hospitalid=h.id', 'left')->field('l.*,hospitalname')->where($map)->page($Nowpage, $limits)->order('add_time desc')->select();
            $Ip = new IpLocation('UTFWry.dat'); // 实例化类 参数表示IP地址库文件
            foreach ($lists as $k => $v) {
                $lists[$k]['add_time'] = date('Y-m-d H:i:s', $v['add_time']);
                $lists[$k]['ipaddr'] = $Ip->getlocation($lists[$k]['ip']);
            }


            $this->assign('Nowpage', $Nowpage); //当前页
            $this->assign('allpage', $allpage); //总页数
            $this->assign('count', $count);
            $this->assign("hospital", $hospital);
            $this->assign('hospitalid', $hospitalid);
            $this->assign('startdate', $startdate);
            $this->assign('enddate', $enddate);
            $this->assign('admin_name', $admin_name);
            if (input('get.page')) {
                return json($lists);
            }
            return $this->fetch();

    }


    /**
     * [del_log 删除日志]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function del_log()
    {
        if (request()->isAjax()) {
            $log_id = input('param.log_id');
            $log = new LogModel();
            $flag = $log->delLog($log_id);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    public function del_curr_log()
    {
        if (request()->isAjax()) {
            $hospitalid = input('hospitalid');
            $admin_name = input('adminname');
            $startdate = input('startdate');
            $enddate = input('enddate');

            $map = [];
            if (!empty($hospitalid)) {
                $map['hospitalid'] = ['=', $hospitalid];
            }
            if (!empty(trim($admin_name))) {
                $map['admin_name'] = ['like', '%' . $admin_name . '%'];
            }
            //判断查询时间范围
            if (!empty(trim($startdate))) {

                if (!empty(trim($enddate))) {

                    $map['add_time'] = ['between', [strtotime($startdate), strtotime($enddate . "23:59:59")]];
                } else {

                    $map['add_time'] = ['>', strtotime($startdate)];
                }


            } else {

                if (!empty(trim($enddate))) {

                    $map['add_time'] = ['<', strtotime($enddate . "23:59:59")];
                }
            }

            if (empty($map)) {

                return json(['code' => 0, 'data' => '', 'msg' => '请选择要清除的条件']);

            }
            $map['isdel'] = ['=', 1];
            $log = new LogModel();
            $flag = $log->delCurrLog($map);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    public function del_all_log()
    {
       /* try{
            Db::execute("TRUNCATE  TABLE ".Config::get('database.prefix')."log");
            return json(['code' => 1, 'data' => '', 'msg' => '清除所有日志成功']);
        }catch( PDOException $e){
            return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
        }*/
       //$log = new LogModel();
        if (request()->isAjax()) {
            $log = new LogModel();
            $flag = $log->delAllLog();
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }

    }
 
}