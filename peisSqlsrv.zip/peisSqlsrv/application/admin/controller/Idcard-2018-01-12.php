<?php

namespace app\admin\controller;
use app\admin\model\IdcardModel;
use think\Db;
use think\Config;
use think\exception\ErrorException;
use think\exception\PDOException;

class Idcard extends Base
{

    /**
     * [index 会员卡]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */


    public function index()
    {

        return $this->fetch();

    }




    //获取所有会员卡信息
    public function getAllIdcard(){

            try {

                $param=input('post.');
                $map=[];

                if (!empty($param['search']))
                    $map['name|idnum|company|mobile|cardnum']=['like','%'.trim($param['search']).'%'];


                    $map['hospitalid']=['=',session('hospitalid')];

                $idcard = new IdcardModel();

                $usercount=$idcard->where($map)->count();

                if (isset($param['sort']))
                    $userdata = $idcard->where($map)->order($param['sort'], $param['order'])->limit($param['offset'],$param['limit'])->select();
                else
                    $userdata = $idcard->where($map)->order('cardnum', 'desc')->limit($param['offset'],$param['limit'])->select();


                if ($userdata===false || $usercount===false )
                    throw  new \Exception();


            }catch ( \Exception $e){
                return json( ['code'=>0,'total'=>'','rows'=>'','msg'=>$e->getMessage()]);

            }


             return json( ['code'=>1,'total'=> $usercount,'rows'=>$userdata ,'msg'=>'ok'] );

    }





    /**
     * [cardEdit 编辑会员卡]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function cardEdit()
    {

        if(request()->isAjax()){

            $user = new UserModel();


            if (empty($param['idcardnum'])) {//新增
                $flag = $user->insertCard($param);

                return json(['code' => $flag['code'], 'jobnum' => $flag['jobnum'],'id' => $flag['id'], 'msg' => $flag['msg']]);

            }else{   //编辑

                $flag = $user->editCard($param);

                return json(['code' => $flag['code'], 'jobnum' => $flag['jobnum'],'id' => $flag['id'], 'msg' => $flag['msg']]);
            }


        }


    }

    /**
     * [cardDel 删除会员卡]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function cardDel()
    {
        if (request()->isAjax()) {

            $cardnum = input('param.cardnum');
            $idcard = new IdcardModel();
            $flag =  $idcard->delUser($cardnum);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }





    /**
     * [card_state 会员卡状态]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function card_state()

    {

        if (request()->isAjax()) {
            try {

                $cardnum = input('param.cardnum');
                $status = input('param.status');

                $flag = Model('IdcardModel')->where(['cardnum'=>$cardnum,'hospitalid'=>session('hospitalid')])->setField('status',$status);

                if ($flag==false)
                    throw  new \Exception();

                if ($status == 1) {
                    writelog(session('uid'), session('username'), '【会员卡号=' . $cardnum . '被启用', 1);
                    return json(['code' => 1, 'data' => '', 'msg' => '已启用']);
                } else {
                    writelog(session('uid'), session('username'), '【会员卡号=' . $cardnum . '被禁用', 1);
                    return json(['code' => 0, 'data' => '', 'msg' => '已禁用']);
                }

            } catch (\Exception $e) {
                writelog(session('uid'), session('username'), '【会员卡号=' . $cardnum. '状态设置失败', 2);
                return ['code' => -1, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
    }


}