<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/26
 * Time: 10:47
 */

namespace app\admin\controller;
use app\admin\model\TjdjviewModel;
use app\admin\model\TjdwModel;
use think\Db;
use think\Config;
use think\exception\PDOException;

class Zhcx extends Base
{

    /**
     * [index 综合查询]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){

        $this->assign('tjdw',Model('TjdwModel')->where(['isdel'=>1,'hospitalid'=>session('hospitalid')])->order('id asc')->select());
        return $this->fetch();

    }




}
