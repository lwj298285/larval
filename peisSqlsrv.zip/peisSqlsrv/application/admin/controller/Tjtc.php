<?php

namespace app\admin\controller;
use app\admin\model\TjtcModel;
use app\admin\model\TjtcDtModel;
use think\Db;
use think\exception\PDOException;
use think\Request;

class Tjtc extends Base

{

    /**
     * [index 体检套餐]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {

        // $lclx=LclxModel::field('id,lclxname')->where('isdel',1)->select();
        // $bblx=BblxModel::field('id,bblxname')->where(['isdel'=>1,'status'=>1])->select();
        //  $jylx=JylxModel::field('id,lxtype,lxname')->where('isdel',1)->select();
        // $sggg=SgggModel::field('id,lxname')->where(['isdel'=>1,'lxtype'=>'SGGG'])->select();
        //$sglb=SglbModel::field('id,lxname')->where(['isdel'=>1,'lxtype'=>'SGLB'])->select();
        // $this->assign('lclx', $lclx);
        // $this->assign('bblx', $bblx);
        // $this->assign('jylx', $jylx);
        /*$zhxmids= Db('tjtc_dt')->field('zhxmid')->where('tcid',1)->buildsql();
        $result = Model('ZhxmModel')->where('id','not in',$zhxmids)
            ->field('id,mc,softid')
            ->where(['isdel&status'=>1,'tjlxid'=>1])
            ->order('softid')
            ->buildSql();
        dump( $zhxmids);
        dump($result);*/
        return $this->fetch();


    }


//获取个人所有可用体检套餐
    public function getAllTjtc()
    {
        // $tjtc = new TjtcModel();
        if (request()->isAjax()) {
            return json(Model('TjtcModel')->where(['status' => 1, 'hospitalid' =>session('hospitalid')])->select());
        }
    }

    //获取体检套餐下的组合项目
    public function getSelZhxm($tcid)
    {

        if (request()->isAjax()) {
            $data = Model('TjtcDtModel')->alias('dt')
                ->join('zhxm_hd hd', 'dt.zhxmid=hd.id')
                ->join('tjtc_hd tc','dt.tcid=tc.id and dt.hospitalid=tc.hospitalid ','left')
                ->field('hd.id ,hd.mc,(case when tc.sfsh=0 then hd.jg  else dt.jg end) as jg,sfsh,hd.softid')
                ->where(['hd.isdel&hd.status' => 1, 'dt.tcid' => $tcid,'dt.hospitalid'=>session('hospitalid')])
                ->order('softid')
                ->select();

            return json($data);
        }
    }



    //获取个人折扣套餐项目
    function getTjtcZkxm($tcid){

        if (request()->isAjax()) {


            $result = Model('TjtcDtModel')->alias('dt')->join('zhxm_hd hd', 'dt.zhxmid=hd.id', 'left')
                ->field('dt.zhxmid,dt.jg ,mc,sfdz,zdzk,hd.jg as sj')
                ->where(['hd.isdel&hd.status' => 1, 'dt.tcid' => $tcid,  'dt.hospitalid' => session('hospitalid')])
                ->order('sfdz,zdzk desc')
                ->select();

            return json($result);
        }

    }



    //获取单个套餐信息
    public function getOneTjtc()
    {
       // $tjtc = new TjtcModel();
        if (request()->isAjax()) {
            $id = input('param.id');
            return json(Model('TjtcModel')->getOneTjtc($id));
        }
    }




    /**
     * [eidtZhxmjg 修改跟人套餐折扣价组合项目价格]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function editZhxmjg()
    {


        if(request()->isAjax()) { //ajax 提交

            $zhxmdata = input('param.zhxmdata/a');
            $tcid = input('param.tcid');

            $tczhkjg=Model('TjtcModel')->where(['hospitalid'=>session('hospitalid'),'id'=>$tcid,'status'=>1])->value('zkhjg');
            // collection($zhxmdata)->column('jg')

            $sumzhxm=array_sum(array_map(create_function('$val', 'return $val["jg"];'),  $zhxmdata));

            if ($tczhkjg!= $sumzhxm)
                return json(['code' => 0, 'data' => '', 'msg' => '套餐折扣价与项目总价不符，不能保存']);

            $flag = Model('TjtcDtModel')->zhxmjgEdit($tcid,$zhxmdata);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            //return json(['code' => 1, 'data' => '', 'msg' => 'ok']);
        }


    }

    /**
     * [tjtcEdit 添加编辑套餐项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function tjtcEdit()
    {
        $tjtc = new TjtcModel();

        if (request()->isAjax()) { //ajax 提交

            if (request()->isPost()) { // 判断提交方式 post为 更新和新增

                // $param =  Request()->post();
                //排除数据表不存在字段tjlxname,name
                $param = input('post.');

                $flag = $tjtc->editTjtc($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            } else {//get 为获取数据


                $id = input('param.id');
                return json($tjtc->getOneTjtc($id));

            }
        }


    }


    /**
     * [  tjtcDel 删除套餐项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function tjtcDel()
    {
        if (request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
           // $tjtc = new TjtcModel();
            $flag =  Model('TjtcModel')->delTjtc($id, $name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * @return \think\response\Json
     * 移除已选择的组合项目(单个)
     */
    public function zhxmSelDel()
    {
        if (request()->isAjax()) {
            $tcid = input('param.tcid');
            $zhxmid = input('param.zhxmid');
            $name = input('param.name');

            /*if(!empty(Model('TjdjModel')->where(['tjlb'=>0,'tcid'=>$tcid])->select()))
                return json(['code' => 0, 'data' => '', 'msg' =>'套餐已被体检引用不可删除组合项目']);*/

            $flag =  Model('TjtcDtModel')->delSelZhxm($tcid, $zhxmid, $name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * @return \think\response\Json
     * 移除已选择的组合项目(多项)
     */
    public function zhxmMulDel()
    {
        if (request()->isAjax()) {
            $zhxmids = input('param.zhxmids');
            $tcid = input('param.tcid');

        /*    if(!empty(Model('TjdjModel')->where(['tjlb'=>0,'tcid'=>$tcid])->select()))
                return json(['code' => 0, 'data' => '', 'msg' =>'套餐已被体检引用不可删除组合项目']);*/

            $flag = Model('TjtcDtModel')->delMulZhxm($tcid, $zhxmids);
            return json(['code' => $flag['code'], 'data' =>  $flag['data'], 'msg' =>  $flag['msg']]);

        }
    }

    /**
     * [ softEdit 调整套餐项目排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if (request()->isAjax()) {

            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $tjtc = new TjtcModel();
            $flag = $tjtc->editSoft($id, $type, $targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    //获取体检套餐 giveTjtc
    public function giveTjtc($key,$status="false")
    {
        if (request()->isAjax()) {

           // $where['isdel'] =['=', 1];
            $where['hospitalid'] =['=', session('hospitalid')];
            if (!empty($key))
                $where['mc|pyjm|wbjm'] = ['like', '%' . $key . '%'];

            if ($status=="true")
                $where['status'] = ['=', 1];



            $result = Model('tjtcModel')->where($where)
                  ->field('id,mc,(case when zk is not null and zkhjg is not null then zkhjg else (case when jg is null then 0 else jg end) end) as jg,softid,status')
                  ->order('softid')
                 ->select();

            $str = '[{"id":"0","name":"体检套餐", "open":"true","childOuter":"false","isParent":"true", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {

                    $icon = '';
                    if ($vo['status'] == 0)
                        $icon = ',"iconSkin":"diy02"';

                    $str .= '{ "id": "' . $vo['id'] . '","title": "' . $vo['jg'] . '", "pid":"0", "name":"' . $vo['mc'] . '"' . $icon . '},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';

            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);
            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }


//获取已添加的组合项目

    public function giveSelZhxm($tcid, $key)
    {
        if (request()->isAjax()) {
            $where = [];
            if (!empty($key))
                $where['hd.mc|hd.pyjm|hd.wbjm'] = ['like', '%' . $key . '%'];

            $result = Model('TjtcDtModel')->alias('dt')->join('zhxm_hd hd', 'dt.zhxmid=hd.id ', 'left')
                ->field('hd.id ,hd.mc,hd.softid')
                ->where(['hd.isdel&hd.status' => 1, 'dt.tcid' => $tcid,'hospitalid'=>session('hospitalid')])
                ->where($where)
                ->order('softid')
                ->select();

            $str = '[{"id":"0","name":"套餐已选组合项目", "open":"true","childOuter":"false","isParent":"true", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';

            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);
            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }

    //获取未选择组合项目

    public function giveNotSelZhxm($tcid, $tjlxid, $xb, $key)
    {

        if (request()->isAjax()) {
            $where = [];

            $where['zd.isdel&zd.status']=['=',1];
            $where['dp.isdel&dp.status']=['=',1];

            if (!empty($key))
                $where['zd.mc|zd.pyjm|zd.wbjm'] = ['like', '%' . $key . '%'];


            if (!empty($tjlxid))
                $where['tjlxid'] = ['=', $tjlxid];


            //选择所有未选择组合项目
          if ($xb=='%'|| empty($xb)){
            $data = Model('ZhxmModel')->alias('zd')
                ->join('tjtc_dt dt', 'zd.id=dt.zhxmid and hospitalid='.session('hospitalid').' and dt.tcid=' . $tcid, 'left')
                ->join('department dp','dp.id=zd.tjlxid ')
                ->field('zd.id,zhxmid ,mc,softid,depname')//zhxmid is null
                ->where($where)
                ->order('softid')
                ->select();
          }else{
              //选择所有符号性别的组合项目
              $data = Model('ZhxmModel')->alias('zd')
                  ->join('tjtc_dt dt', 'zd.id=dt.zhxmid and hospitalid='.session('hospitalid').' and dt.tcid=' . $tcid, 'left')
                  ->join('department dp','dp.id=zd.tjlxid')
                  ->field('zd.id,zhxmid ,xb,mc,softid,depname')//zhxmid is null
                  ->where($where)
                  ->whereIn('xb',$xb.',%')
                  ->order('softid')
                  ->select();
          }

            $result = arrWhereAnd($data, ['zhxmid' => null]);


            // not in   left join  方式
            //  $result = Db::table($subquery.' a')->select();
            //$zhxmids= Model('ZhxmDtModel')->field('zhxmid')->where('tcid',$tcid)->select(false);
            /* $zhxmids= Db('tjtc_dt')->field('zhxmid')->where('tcid',$tcid)->fetchsql()->select();
             $result = Model('ZhxmModel')->whereNotIn('id', $zhxmids)
                 ->field('id,mc,softid')
                 ->where(['isdel&status'=>1,'tjlxid'=>$tjlxid])
                 ->where($where)
                 ->order('softid')
                 ->select();*/


            $str = '[{"id":"0","name":"套餐可选择组合项目", "open":"true","isParent":"true","childOuter":"false", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '","title": "' . $vo['depname'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);
            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }


    /**
     * [ tjtcEditItem增加组合项目小项]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function tjtcEditItem()
    {
        if (request()->isAjax()) {
            $param['hospitalid'] = session('hospitalid');
            $param['zhxmid'] = input('zhxmid');
            $param['tcid'] = input('tcid');
            //$zhxmdt = new ZhxmDtModel();
            Db::startTrans();
            try {

             /*   if(!empty(Model('TjdjModel')->where(['tjlb'=>0,'tcid'=>$param['tcid']])->select())) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' =>'套餐已被体检引用不可删除组合项目'];
                }*/
                $flag = Model('TjtcDtModel')->save($param);

                if ($flag == true) {
                    $jg= Model('TjtcDtModel')->getTcjg($param['tcid']);

                    //更新个人套餐价格，如果是打折套餐并且审核过设置未未审核
                    Model('TjtcModel')->where(['id'=>$param['tcid'],'hospitalid'=>session('hospitalid')])
                        ->update(['jg'=>$jg,'sfsh'=>['exp','case sfsh when 1 then 0 else 0 end']]);

                    Db::execute('exec  SP_Tjtczk '.session('hospitalid').','. $param['tcid']);

                    Db::commit();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加个人套餐组合项目成功(ID='. session('hospitalid'). '-'.$param['tcid']. ')', 1);
                    return json(['code' => 1, 'data' => $jg, 'msg' => '选择组合项目成功']);
                }
                else {
                    Db::rollback();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加个人套餐组合项目失败(ID='. session('hospitalid').'-'.  $param['tcid'].' )', 2);
                    return json(['code' => 0, 'data' => '', 'msg' => '选择组合项目失败']);
                }
            } catch (PDOException $e) {
                Db::rollback();
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
            }


        }

    }

    /**
     * [ tjtcEditItems套餐增加多选组合项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function tjtcEditItems()
    {
        if (request()->isAjax()) {


            $param = input('get.zhxmdt/a');
            $tcid = input('param.tcid');
            //$param['hospitalid'] = session('hospitalid');
            Db::startTrans();
             try{

                /* if(!empty(Model('TjdjModel')->where(['tjlb'=>0,'tcid'=> $tcid])->select())) {
                     Db::rollback();
                     return ['code' => 0, 'data' => '', 'msg' =>'套餐已被体检引用不可删除组合项目'];
                 }*/
                 $flag = Model('TjtcDtModel')->saveAll($param,false);

                 if ($flag==true) {
                     $jg= Model('TjtcDtModel')->getTcjg($tcid);
                     Model('TjtcModel')->where(['id'=>$tcid,'hospitalid'=>session('hospitalid')])
                         ->update(['jg'=>$jg,'sfsh'=>['exp','case sfsh when 1 then 0 else 0 end']]);

                     Db::execute('exec  SP_Tjtczk '.session('hospitalid').','. $tcid);
                     db::commit();
                     writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加个人套餐组合项目成功(ID='. session('hospitalid'). '-'.$tcid. ')', 1);
                     return json(['code' => 1, 'data' => $jg, 'msg' => '选择组合项目成功']);
                 } else {
                     Db::rollback();
                     writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加个人套餐组合项目失败(ID='. session('hospitalid').'-'.  $tcid.' )', 2);
                     return json(['code' => 0, 'data' => '', 'msg' => '选择组合项目失败']);
                 }

             }catch(PDOException $e){
                 Db::rollback();
                 return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
             }


        }

    }
}