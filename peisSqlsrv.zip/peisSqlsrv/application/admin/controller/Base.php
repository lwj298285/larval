<?php

namespace app\admin\controller;
use app\admin\model\Node;
use think\Controller;
use think\Db;
class Base extends Controller
{
    public function _initialize()
    {
        if(!session('uid')){
            $this->redirect(url('login/index'));
        }
        
        $auth = new \com\Auth();
    
        $module     = strtolower(request()->module());
        $controller = strtolower(request()->controller());
        $action     = strtolower(request()->action());
        $url        = $module."/".$controller."/".$action;


       //获取方法名是否开头是否为get 或者 give 加载数据方法不验证
        $actionget=strtolower(substr($action,0,3));
        $actiongive=strtolower(substr($action,0,4));

        if (!empty(session('oldhospitalid')))
             $hospitalid=session('oldhospitalid');
        else
             $hospitalid=session('hospitalid');

        //跳过检测以及主页权限
        if(session('groupid')!='1'){

            if ($actionget!=="get" && $actiongive!=="give") {
                if (!in_array($url, ['admin/index/index', 'admin/index/indexpage', 'admin/user/change_password'])) {
                    if (!$auth->check($url, session('uid'), $hospitalid)) {
                        $this->error('抱歉，您没有操作权限','admin/index/indexpage');
                        //$this->error('抱歉，您没有操作权限');

                      // echo "<script type=\"text/javascript\"> alert('抱歉，您没有操作权限'); window.close();</script>";

                     // exit();

                    }
                }
            }
        }
    
        $node = new Node();
        $this->assign([
            'username' => session('username'),
            'menu' => $node->getMenu(session('rule')),
            'rolename' => session('rolename'),
            'hospitalname' => session('hospitalname'),
            'realname' => session('realname'),
            'jobnum' => session('jobnum')
        ]);

    } 
	
	
}