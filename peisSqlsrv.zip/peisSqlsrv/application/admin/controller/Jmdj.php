<?php
namespace app\admin\controller;
use think\Db;
use think\Config;
class Jmdj  extends Base
{


    /**
     * [index 加密等级]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {

         return $this->fetch();
    }

    /**
     * @return \think\response\Json
     */
//基本字段更新/编辑
    public function editJmzd()
    {
        if (request()->isAjax()){//ajax 提交
            if (request()->isPost()) {// 判断提交方式 post为 更新和新增

                $param = request()->except('jmdj','post');
                $jmdj= input('post.jmdj');
                $strvalue ="";
                $strtext ="";


                $dj=json_decode(file_get_contents(APP_PATH.'dictionary.json'), true);

                foreach(  $param  as $k=>$v){
                    $strtext.=$v.",";
                    $strvalue.=$k.",";
                };

               if(strlen($strtext)>0) {
                   $strtext= substr($strtext, 0, -1);
                   $strvalue=substr($strvalue, 0, -1);
               }


                foreach(  $dj[0]['jmdj']  as $k=>$v){

                    if ($v['id']==$jmdj) {
                        $dj[0]['jmdj'][$k]['value'] =$strvalue;
                        $dj[0]['jmdj'][$k]['text'] = $strtext;
                    }

                };

              //  $djjmdj[$jmdj]=$str;

                // 把PHP数组转成JSON字符串
                $json_string = json_encode( $dj);

              // 写入文件

                file_put_contents(APP_PATH.'dictionary.json', $json_string);

                return json(['code' =>1, 'data' =>'', 'msg' =>'加密等级设置成功']);
            }
        }
    }

    /**
     * @return \think\response\Json
     */
//获取加密等级
    public function giveJmdj()
    {
        if (request()->isAjax()) {


            $str = '[{"id":"0","name":"加密等级", "open":"true","childOuter":"true", "isParent":"true","children":[';

            $jmdj=get_json_emlement('dictionary.json',0,'jmdj');

           foreach ( $jmdj as $k => $v) {

                $str .= '{"id":"' . $v["id"] . '","name":"' . $v["name"]. '","pid":"0", "open":"false","childOuter":"true", "isParent":"true"},';

            }

            if(count($v,COUNT_NORMAL)>0 ){
                $str = substr($str, 0, -1);
                $str .= ']}]';

                return json(['code' => 1, 'data' =>  $str , "msg" => "OK"]);
            }else{
                return false;
            }

        }
    }

//获取加密等级下拉列表
    public function getJmdjsel()
    {
        if (request()->isAjax()) {


            //$str = '[{"id":"0","name":"加密等级", "open":"true","childOuter":"true", "isParent":"true","children":[';

            $jmdj=get_json_emlement('dictionary.json',0,'jmdj');
            return json($jmdj);



        }
    }





////获取同一类型下所有基本字段
    public function getJmzd($jmdj){
        if(request()->isAjax()){
// 从文件中读取数据到PHP变量
            //$json_string = file_get_contents((APP_PATH.'dictionary.json'));

// 把JSON字符串转成PHP数组
            $dj=get_json_emlement('dictionary.json',0,'jmdj');

            $dj=array_column($dj,'value','id');
            $result=explode(',',$dj[$jmdj]);

            return json( $result );

        }
            // return json( $result );

    }




}