<?php

namespace app\admin\controller;
use app\admin\model\WjdcModel;
use think\Db;


class Wjdc extends Base

{


    /**
     * [index 体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){


        $djlsh=input('param.djlsh');
        $this->assign('djlsh',  $djlsh);

        $wjdc=Model('WjdcModel')->where(['djlsh'=>$djlsh,'hospitalid'=>session('hospitalid')])->select();
        $this->assign('wjdc', json_encode($wjdc));

        return $this->fetch();


    }








    /**
     * [wjdcEdit 编辑调查问卷]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function wjdcEdit()
    {


        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增


                $param=input('post.');

                $tzdata=[];

                $tzdata[]=['tzlx'=>'pihz','tzjg'=>$this::wjData('pihz',8,$param),'ysf'=>$param['pihzysf'],'zhf'=>$param['pihzzhf'],'tzjl'=>$param['pihz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'qixz','tzjg'=>$this::wjData('qixz',8,$param),'ysf'=>$param['qixzysf'],'zhf'=>$param['qixzzhf'],'tzjl'=>$param['qixz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'yaxz','tzjg'=>$this::wjData('yaxz',7,$param),'ysf'=>$param['yaxzysf'],'zhf'=>$param['yaxzzhf'],'tzjl'=>$param['yaxz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'yixz','tzjg'=>$this::wjData('yixz',8,$param),'ysf'=>$param['yixzysf'],'zhf'=>$param['yixzzhf'],'tzjl'=>$param['yixz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'tasz','tzjg'=>$this::wjData('tasz',8,$param),'ysf'=>$param['taszysf'],'zhf'=>$param['taszzhf'],'tzjl'=>$param['tasz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'shrz','tzjg'=>$this::wjData('shrz',7,$param),'ysf'=>$param['shrzysf'],'zhf'=>$param['shrzzhf'],'tzjl'=>$param['shrz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'xuyz','tzjg'=>$this::wjData('xuyz',8,$param),'ysf'=>$param['xuyzysf'],'zhf'=>$param['xuyzzhf'],'tzjl'=>$param['xuyz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'qiyz','tzjg'=>$this::wjData('qiyz',7,$param),'ysf'=>$param['qiyzysf'],'zhf'=>$param['qiyzzhf'],'tzjl'=>$param['qiyz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];
                $tzdata[]=['tzlx'=>'tebz','tzjg'=>$this::wjData('tebz',7,$param),'ysf'=>$param['tebzysf'],'zhf'=>$param['tebzzhf'],'tzjl'=>$param['tebz'],'djlsh'=>$param['djlsh'],'hospitalid'=>session('hospitalid')];


                $wjdc= new WjdcModel();
                $flag = $wjdc->editWjdc($tzdata, $param['djlsh']);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }
        }


    }



    //组织问卷调查数据
    private function wjData($tzname,$ncocunt,$param){
           $jgdata="";
           for ($i=1;$i<=$ncocunt;$i++)
               $jgdata.= $param[$tzname.$i].",";


       return substr($jgdata, 0, -1);


    }


    /**
     * [  wjdcDel 删除体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function wjdcDel($djlsh)
    {
        if(request()->isAjax()) {

            $wjdc= new WjdcModel();
            $flag = $wjdc->delWjdc($djlsh);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }




}