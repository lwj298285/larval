<?php

namespace app\admin\controller;
use app\admin\model\HospitalModel;
use app\admin\model\XzqyModel;
use think\Db;

class Hospital extends Base
{

    /**
     * [index 医院机构]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){

        $key = input('key');
        $map['isdel'] = ['=',1];
        if($key&&$key!=="")
        {
            $map['hospitalname'] = ['like',"%" . $key . "%"];          
        }       
        $Nowpage = input('get.page') ? input('get.page'):1;
        $limits = 10;// 获取总条数
        $count = Db::name('hospital')->where($map)->count();//计算总页面
        $allpage = intval(ceil($count / $limits));
        $hospital = new HospitalModel();
        $lists = $hospital->getHospitalsByWhere($map, $Nowpage, $limits);
        $this->assign('Nowpage', $Nowpage); //当前页
        $this->assign('allpage', $allpage); //总页数 
        $this->assign('val', $key);
        if(input('get.page'))
        {
            return json($lists);
        }
        return $this->fetch();
    }


    /**
     * [hospitalAdd 添加分院]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function hospitalAdd()
    {   
        if(request()->isAjax()){
            $param = input('post.');
            $hospital = new HospitalModel();
            $flag = $hospital->insertHospital($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }

        //$data=get_json_emlement('region.json',0,'region');
       // $data=json_decode(file_get_contents(APP_PATH.'region.json'), true);

        $region=new XzqyModel();
        $data=$region->GetArea(1,0);
      //  dump($region.getArea('province',''););

        $this->assign('province', $data);
        return $this->fetch();
    }


    /**
     * [hospitalEdit 编辑医院]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function hospitalEdit()
    {
        $hospital = new hospitalModel();

        if(request()->isAjax()){
            $param = input('post.');
           // $hospital = new HospitalModel();
            $flag = $hospital->editHospital($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }

        //$data=get_json_emlement('region.json',0,'region');
        // $data=json_decode(file_get_contents(APP_PATH.'region.json'), true);
        $id = input('param.id');

        $this->assign([
            'hospital' => $hospital->getOneHospital($id),
        ]);
        return $this->fetch();

    }


    /**
     * [hospitalDel 删除医院]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function hospitalDel()
    {
        if (request()->isAjax()) {
            $id = input('param.id');
            $role = new HospitalModel();
            $flag = $role->delHospital($id);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }



    /**
     * [hospital_state 医院状态]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function hospital_state()
    {
        if (request()->isAjax()) {
            $id = input('param.id');
            $status = Db::name('hospital')->where(array('id' => $id))->value('status', 'hospitalname');//判断当前状态情况

            if ($status == 1) {
                $flag = Db::name('hospital')->where(array('id' => $id))->setField(['status' => 0]);
                return json(['code' => 1, 'data' => $flag['data'], 'msg' => '已禁止']);
            } else {
                $flag = Db::name('hospital')->where(array('id' => $id))->setField(['status' => 1]);
                return json(['code' => 0, 'data' => $flag['data'], 'msg' => '已开启']);
            }
        }
    }

}