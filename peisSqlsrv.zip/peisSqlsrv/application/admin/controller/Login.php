<?php

namespace app\admin\controller;
use app\admin\model\UserType;
use app\admin\model\UserModel;
use think\Controller;
use think\Db;
use org\Verify;
use com\Geetestlib;
use mail\Phpmailer;
use think\Exception;
use think\exception\ErrorException;
use think\exception\PDOException;

class Login extends Controller
{
    //登录页面
    public function index()
    {
        $sfyz=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'dlsfyz'])->value('value');
        $this->assign('sfyz',$sfyz);



        return $this->fetch('/login');
    }

    //登录操作
    public function doLogin()

    {



    $username = input("param.username");
    $password = input("param.password");

    $sfyz=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'dlsfyz'])->value('value');
   /* if (config('verify_type') == true) {
        $code = input("param.code");
    }

    $verify = new Verify();
    if (config('verify_type') == true) {
        if (!$code) {
            return json(['code' => -4, 'data' => '', 'msg' => '请输入验证码']);
        }
        if (!$verify->check($code)) {
            return json(['code' => -4, 'data' => '', 'msg' => '验证码错误']);
        }
    }*/

//       if ($sfyz == "yes") {
//          $code = input("param.code");
//
//
//          $verify = new Verify();
//
//          if (!$code) {
//              return json(['code' => -4, 'data' => '', 'msg' => '请输入验证码']);
//          }
//          if (!$verify->check($code)) {
//              return json(['code' => -4, 'data' => '', 'msg' => '验证码错误']);
//          }
//      }

   /* if (config('verify_type') != 1) {

        $GtSdk = new Geetestlib(config('gee_id'), config('gee_key'));
        $user_id = session('user_id');
        if (session('gtserver') == 1) {
            $result = $GtSdk->success_validate(input('param.geetest_challenge'), input('param.geetest_validate'), input('param.geetest_seccode'), $user_id);
            //极验服务器状态正常的二次验证接口
            if (!$result) {
                $this->error('请先拖动验证码到相应位置');
            }
        } else {
            if (!$GtSdk->fail_validate(input('param.geetest_challenge'), input('param.geetest_validate'), input('param.geetest_seccode'))) {
                //极验服务器状态宕机的二次验证接口
                $this->error('请先拖动验证码到相应位置');
            }
        }

    }*/

    try {

        $result = $this->validate(compact('username', 'password'), 'AdminValidate');
        if (true !== $result) {
            return json(['code' => -5, 'data' => '', 'msg' => $result]);
        }


        //$hasUser = Db::name('admin')->where('username', $username)->find();
        /*$hasUser=Db::view('admin','*')
                    ->view('auth_group',['status'=>'groupstatus','rules'],'admin.groupid=auth_group.id')
                    ->where('username', $username)
                    ->find();*/



        $hasUser = Db::name('admin as ad')->join('auth_group au', 'ad.groupid=au.id', 'left')
            ->field('ad.*,au.status as groupstatus,rules,au.isdel as auisdel')
            ->where('username|email|mobile', '=', $username)
            ->where(['ad.isdel' => 1])->find();



    if (empty($hasUser)) {
        return json(['code' => -1, 'data' => '', 'msg' => '管理员不存在']);
    }




  /*  if (md5(md5(trim($password)) . config('auth_key')) != $hasUser['password']) {
        writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：密码错误', 2, $hasUser['hospitalid']);
        return json(['code' => -2, 'data' => '', 'msg' => '账号或密码错误']);
    }*/


  //加密密码
        $eStr=encrypt($hasUser['jobnum'].'@'.$password,'E');
   //解密密码
        $dStr=encrypt($hasUser['password'],'D');

        if ($eStr!= $hasUser['password']  || $hasUser['jobnum']!=substr($dStr,0,strrpos($dStr,'@'))) {
              writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：密码错误', 2, $hasUser['hospitalid']);
              return json(['code' => -2, 'data' => $eStr, 'msg' => '您所输入的工号或密码不正确']);
        }


        if (1 != $hasUser['groupid'] && empty($hasUser['rules'])) {
        writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：该账号所对应角色无任何权限', 2, $hasUser['hospitalid']);
        return json(['code' => -6, 'data' => '', 'msg' => '您所输入的工号或密码不正确']);
    }

    if (1 != $hasUser['groupstatus']) {
        writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：该账号所对应角色已被禁用', 2, $hasUser['hospitalid']);
        return json(['code' => -6, 'data' => '', 'msg' => '您所输入的工号或密码不正确']);
    }


    if (1 != $hasUser['auisdel']) {
        writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：该账号所对应角色已删除', 2, $hasUser['hospitalid']);
        return json(['code' => -6, 'data' => '', 'msg' => '您所输入的工号或密码不正确']);
    }

    if (1 != $hasUser['status']) {
        writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：该账号被禁用', 2, $hasUser['hospitalid']);
        return json(['code' => -6, 'data' => '', 'msg' => '您所输入的工号或密码不正确']);
    }

    $hasUser['hospitalname'] = "";

    if (1 != $hasUser['groupid'] || 0 != $hasUser['hospitalid']) {
        $hs = Db::name('admin as ad')->join('hospital hs', 'ad.hospitalid=hs.id', 'left')
            ->field('hospitalname,hs.status as status,hs.isdel as isdel')
            ->where('username|ad.email|mobile', '=', $username)
            ->where(['ad.isdel' => 1])->find();

        if (1 != $hs['status']) {
            writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：该账号所对应医院已被禁用', 2);
            return json(['code' => -6, 'data' => '', 'msg' => '您所输入的工号或密码不正确']);
        }

        if (1 != $hs['isdel']) {
            writelog($hasUser['id'], $username, '用户【' . $username . '】登录失败：该账号所对应医院已删除', 2);
            return json(['code' => -6, 'data' => '', 'msg' => '您所输入的工号或密码不正确']);
        }

        $hasUser['hospitalname'] = $hs['hospitalname'];
    }

    }catch (PDOException  $e){

        return json(['code' => -1, 'data' => '', 'msg' =>$e->getMessage() ]);


    }

    //获取该管理员的角色信息
    $user = new UserType();
    $info = $user->getRoleInfo($hasUser['groupid']);
    session('username', $hasUser['username']);
    session('uid', $hasUser['id']);
    session('realname', $hasUser['real_name']);
    session('jobnum', $hasUser['jobnum']);
    session('hospitalname', $hasUser['hospitalname']);
    session('groupid', $hasUser['groupid']);
    session('hospitalid', $hasUser['hospitalid']);
    session('rolename', $info['title']);  //角色名
    session('rule', $info['rules']);  //角色节点
    session('name', $info['name']);  //角色权限
    //更新管理员状态
    $param = [
        'loginnum' => $hasUser['loginnum'] + 1,
        'last_login_ip' => request()->ip(),
        'last_login_time' => time()
    ];

    Db::startTrans();
    try {
        Db::name('admin')->where(array('id' => $hasUser['id'], 'hospitalid' => $hasUser['hospitalid']))->update($param);
        writelog($hasUser['id'], session('username'), '用户【' . session('username') . '】登录成功', 1);
        Db::commit();
    } catch (PDOException $e) {
        Db::rollback();
        return json(['code' => -6, 'data' => '', 'msg' => '记录日志失败']);
    }




    return json(['code' => 1, 'data' => url('index/index'), 'msg' => '登录成功！']);

    }

    //验证码
    public function checkVerify()
    {
        $verify = new Verify();
        $verify->imageH = 32;
        $verify->imageW = 100;
		$verify->codeSet = '0123456789';
        $verify->length = 4;
        $verify->useNoise = false;
        $verify->fontSize = 14;
        return $verify->entry();
    }


    //极验验证
    public function getVerify(){
        $GtSdk = new Geetestlib(config('gee_id'), config('gee_key'));
        $user_id = "web";
        $status = $GtSdk->pre_process($user_id);
        session('gtserver',$status);
        session('user_id',$user_id);
        echo $GtSdk->get_response_str();
    }



    //退出操作
    public function loginOut()
    {
        session(null);
        $this->redirect(url('index'));
    }


    //用户忘记密码通过注册邮件或者手机重置密码
    public function resetpwd()
    {

        $user = new UserModel();

        if(request()->isAjax()){

            $param = input('post.');
            $userextis = Db::name('admin')->where(['email'=>trim($param['resetpwdemail']),'mobile'=>trim($param['resetpwdmobile']),'username'=>trim($param['resetpwdusername'])])->find();

            if (!empty($userextis))
                $param['newpassword']=generateWeirdStr(6);
            else
                return json(['code' =>-2, 'data' =>'', 'msg' => '用户不存在，请填写正确的用户信息！']);


            //return json(['code' =>1, 'data' => '', 'msg' =>dump($user)]);
            $flag = $user->resetPassword($userextis['id'],$userextis['jobnum'],$userextis['username'],$userextis['hospitalid'],$param['resetpwdemail'],$param['resetpwdmobile'],$param['newpassword']);


            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }


        return json(['code' => 1, 'data' => '', 'msg' => input('post.')]);
    }
}