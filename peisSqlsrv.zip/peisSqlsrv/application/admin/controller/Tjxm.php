<?php

namespace app\admin\controller;
use app\admin\model\TjxmModel;
use app\admin\model\DepartmentModel;
use app\admin\model\XmlxModel;
use think\Db;


class Tjxm extends Base

{


    /**
     * [index 体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){

     //   $lclx=LclxModel::field('id,lclxname')->where('isdel',1)->select();
      //  $this->assign('lclx', $lclx);

        $this->assign('jbzd', Model('JbzdModel')->where('isdel', 1)->whereIn('dictype', "PDTS,PGTS")->select());

        return $this->fetch();


    }






    public function getOneTjxm(){

        $tjxm = new TjxmModel();
        $id = input('param.id');
        return  json( $tjxm->getOneTjxm($id));


    }


    /**
     * [tjxmEdit 添加编辑体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function tjxmEdit()
    {
        $tjxm = new TjxmModel();

        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增

                 $param = input('post.','',null);
                // $param['ckxx']=input('ckxx','',null);

              //  $param =Request()->except(['tjlxname'],'post');
                $flag =  $tjxm->editTjxm($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }else{//get 为获取数据


                $id = input('param.id');
                return  json( $tjxm->getOneTjxm($id));

            }
        }


    }


    /**
     * [ lclxDel 删除体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function tjxmDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
            $tjxm = new TjxmModel();
            $flag = $tjxm->delTjxm($id,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ softEdit 调整体检项目排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $tjlxid = input('param.tjlxid');
            $xmlxid = input('param.xmlxid');
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $tjxm = new TjxmModel();
            $flag = $tjxm->editSoft($tjlxid,$xmlxid,$id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    //获取体检项目树 giveTjxm
    public function giveTjxm($search,$status)
    {

        if (request()->isAjax()) {
            //获取所有体检类型
            $map = [];
            // $search=input('param.search');
            //  $stauts=input('param.status');
            if (!empty($search))
                $map['mc|pyjm|wbjm'] = ['like', '%' . $search . '%'];

            //传参 看是否取出未启用的的项目  其他调用一般都不调用
            ($status == "true") ? $map['status'] = 1 : "";


            $result = Model('DepartmentModel')->getDepartments();
            $xmlx = Model('XmlxModel')->where('isdel', 1)->select();


            $tjxm = Model('TjxmModel')->alias('xm')->join('xmlx lx', 'lx.id=xmlxid', 'left')
                ->field('xm.tjlxid,xmlxid,xmlxname, xm.id as xmid ,mc,xm.softid as xmsoftid,xm.status')
                ->where($map)
                ->where(['xm.isdel' => 1])
                ->order('xmlxid,xmsoftid')
                ->select();




            $str = '[{"id":"0","name":"体检科室及项目", "open":"true","childOuter":"false","children":[';

            if ($result) {

                foreach ($result as $key => $vo) {
                    //添加科室
                    if (!empty($search))
                        $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","open":"true","isParent":"true","pid":"0","children":[';
                    else
                        $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","children":[';

                    if ($vo['deptype'] != 0) {
                        //判断体检类型是否为为检验项目或功能检查并添加相应项目类型
                        $tjlxxmlx = arrWhereAnd($xmlx, ['tjlxid' => $vo['depid']]);

                        if ($tjlxxmlx) {

                           foreach ($tjlxxmlx as $ks => $vs) {
                                if (!empty($search))
                                    $str .= '{ "id": "' . $vs['id'] . '","name":"' . $vs['xmlxname'] . '","childOuter":"false","open":"true","isParent":"true","pid":"' . $vo['depid'] . '","children":[';
                                else
                                    $str .= '{ "id": "' . $vs['id'] . '","name":"' . $vs['xmlxname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"' . $vo['depid'] . '","children":[';

                               $depxmlxtjxm = arrWhereAnd($tjxm, ['tjlxid' => $vo['depid'], 'xmlxid' => $vs['id']]);
                                if ($depxmlxtjxm) {

                                    //添加项目类型下体检项目
                                    foreach ($depxmlxtjxm as $k => $v) {

                                        //看体检项目是否启用显示不同图标
                                        $icon = '';
                                        if ($v['status'] == 0)
                                            $icon = ',"iconSkin":"diy02"';

                                        $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $v['xmlxid'] . '"' . $icon . '},';

                                    }
                                    $str = substr($str, 0, -1);
                                }
                                $str .= ']},';

                            }




                            //没挂入项目类型小项
                            $deptjxm= arrWhereAnd($tjxm, ['tjlxid' => $vo['depid'], 'xmlxid' => null]);
                           // $deptjxm =  arrWhereAnd($tjxm,[ 'xmlxid' => null]);
                            if ($deptjxm) {

                                //添加科室下体检项目
                                foreach ($deptjxm as $k => $v) {
                                //看体检项目是否启用显示不同图标
                                    $icon = '';
                                    if ($v['status'] == 0)
                                        $icon = ',"iconSkin":"diy02"';

                                    $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $vo['depid'] . '"' . $icon . '},';

                                }
                               // $str = substr($str, 0, -1);

                            }


                            $str = substr($str, 0, -1);


                        } else {

                            //添加科室下未设置项目类型项目

                            $deptjxm = arrWhereAnd($tjxm, ['tjlxid' => $vo['depid']]);
                             //return json(['code' => 1, 'data' =>  $deptjxm, "msg" => "OK"]);
                            if ($deptjxm) {

                                foreach ($deptjxm as $k => $v) {

                                    //看体检项目是否启用显示不同图标
                                    $icon = '';
                                    if ($v['status'] == 0)
                                        $icon = ',"iconSkin":"diy02"';

                                    $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $vo['depid'] . '"' . $icon . '},';

                                }
                                $str = substr($str, 0, -1);

                            }



                        }

                    } else {



                        //添加科室下体检项目
                        $deptjxm = arrWhereAnd($tjxm, ['tjlxid' => $vo['depid']]);
                        if ($deptjxm) {


                            foreach ($deptjxm as $k => $v) {

                                //看体检项目是否启用显示不同图标
                                $icon = '';
                                if ($v['status'] == 0)
                                    $icon = ',"iconSkin":"diy02"';

                                $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $vo['depid'] . '"' . $icon . '},';

                            }
                            $str = substr($str, 0, -1);

                        }


                    }
                    $str .= ']},';

                }
                $str = substr($str, 0, -1);
            }

            //根节点结束
            $str .= ']}]';



              $escapers = array("\\");
              $replacements = array("\\\\");
              $str = str_replace($escapers, $replacements,$str);
            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);

        }
    }




//获取所有体检项目 getAllTjxm
public function getAllTjxm()
{

    if (request()->isAjax()) {

            $tjxm = new TjxmModel();
            $tjxmdata = $tjxm->field('id ,mc')->where(['isdel' => 1])->select();

            return json(['code' => 1, 'data' =>$tjxmdata, "msg" => "OK"]);

        }
    }


}