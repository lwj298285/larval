<?php

namespace app\admin\controller;

use app\admin\model\SgggModel;
use think\Db;
use think\Config;

class Dysz extends Base
{
	/**
	 * [index 体检项目]
	 * @return [type] [description]
	 * @author [俞晴] [peis999]
	 */
	
	
	public function index(){
		
		return $this->fetch();
		
	}
	
	

	
	
}