<?php

namespace app\admin\controller;
use think\console\command\make\Model;
use think\Db;
use think\Config;
use mail\Phpmailer;
use sms\Sms;
class Fctz extends Base
{



    /**
     * [index 复查通知]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index()
    {
        //$this->assign('user', Model('UserModel')->where(['isdel&status' => 1, 'hospitalid' => session('hospitalid')])->select());

        return $this->fetch();
    }


    //批量发送复查通知信息
    public function Fctz()
    {
        if (request()->isAjax()) {

            try {

                $param = input('param.data/a');
                $i=0;$j=0;
                $hospital=Model('HospitalModel')->find(session('hospitalid'));
                foreach ($param as $k =>$v) {
                    $content=$v['djxm'].":你好!</br>". $v['fcgy'].'</br>复查日期:'.$v['fcrq'].'至'.$v['fcrqend'];

                    $content.="</br>".$hospital->hospitalname."</br>地址:".$hospital->address."</br>电话:".$hospital->tel;

                    //$mobile=empty($v['fcmobile'])?"":$v['fcmobile'];


                     if(!empty($mobile)) {
                         $sms = new Sms($v['fcmobile'], $content);
                         $flag = $sms->sendSms();
                         if ($flag !== 'num=0') {
                             $result=Model('TjdjModel')->allowField(true)->save($v,['tjbh'=>$v['tjbh'],'tjcs'=>$v['tjcs'],'hospitalid'=>session('hospitalid')]);
                             if($result===false) $i++;

                         } else {
                             $j++;

                         }

                     }
                }

                $message="";
                if ($i==0 && $j==0)
                    $message="发送复查通知成功";

                if ($i>0)
                    $message="有".$i."条复查通知记录失败;";

                if ($j>0)
                    $message.="有".$j."条复查通知发送失败;";


                if ($i==0 && $j==0 )
                    return json(['code' => 1, 'data' => '', 'msg' => $message]);
                else
                    return json(['code' => 2, 'data' => '', 'msg' => $message]);

            } catch (ErrorException $e){
               // Db::rollback();
                return json(['code' => 0, 'data' => '', 'msg' =>$e->getMessage()]);
            }

        }
    }
}
