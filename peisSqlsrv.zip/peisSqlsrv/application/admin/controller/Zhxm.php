<?php

namespace app\admin\controller;
use app\admin\model\ZhxmModel;
use app\admin\model\ZhxmDtModel;
use app\admin\model\LclxModel;
use think\console\command\make\Model;
use think\Db;
use think\exception\PDOException;
use think\Request;

class Zhxm extends Base

{
    /**
     * [index 组合项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){


        $this->assign('jylx', Model('JbzdModel')->where('isdel', 1)->whereIn('dictype', "BBLX,SGGG,SGLB,JCJYLX")->select());

        return $this->fetch();


    }



    public function getOneZhxm()
    {
       // $zhxm = new ZhxmModel();
        $id = input('param.id');
        return json(Model('ZhxmModel')->getOneZhxm($id));
    }

    /**
     * [lclxEdit 添加删除体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function zhxmEdit()
    {
        $zhxm = new ZhxmModel();

        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增

               // $param =  Request()->post();
                //排除数据表不存在字段tjlxname,name
                 $param =Request()->except(['tjlxname'],'post');

                $flag =  $zhxm->editZhxm($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }else{//get 为获取数据


                $id = input('param.id');
                return  json( $zhxm->getOneZhxm($id));

            }
        }


    }


    /**
     * [ lclxDel 删除体检项目]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function zhxmDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $name = input('param.name');
            $zhxm = new ZhxmModel();
            $flag = $zhxm->delZhxm($id,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ softEdit 调整组合项目排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $tjlxid = input('param.tjlxid');
            $id = input('param.id');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $zhxm = new ZhxmModel();
            $flag = $zhxm->editSoft($tjlxid,$id,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


 //获取组合项目未选小项



    public function giveNotSelTjxm($tjlxid,$zhxmid,$xb,$search)
    {
        if(request()->isAjax()) {
            try {
                $map = [];

                if (!empty($search))
                    $map['tjxm.mc|tjxm.pyjm|tjxm.wbjm'] = ['like', '%' . $search . '%'];

                if (isset($xb)) {
                    if ($xb != '%')
                        $xb != '1' ? $map['tjxm.xb'] = ['<>', '1'] : $map['tjxm.xb'] = ['<>', '0'];
                }




               $result= Model('ZhxmModel')->alias('hd')->join('tjxm tjxm', 'hd.tjlxid=tjxm.tjlxid', 'left')
                    ->join('zhxm_dt dt', 'hd.id=dt.zhxmid and tjxm.id=dt.tjxmid', 'left')
                    ->field('dt.*,tjxm.id id ,tjxm.xmlxid,tjxm.mc,tjxm.xb,tjxm.pyjm,tjxm.wbjm,tjxm.softid softid')
                    ->where(['tjxm.isdel&tjxm.status' => 1, 'hd.id' => $zhxmid])
                    ->where($map)
                    ->order('softid')
                    ->select();



                $xmlx = Model('XmlxModel')->where(['tjlxid'=>$tjlxid,'isdel'=> 1])->select();

                //arrWhereAnd 必须使用model 调取DB;name 不能过滤

                $result = arrWhereAnd($result, ['tjxmid' =>null]);




                //未选项目可能需要增加项目类型，项目太多不好选 也可能有重名项目

                $str = '[{"id":"0","name":"组合项目未选项目", "open":"true","childOuter":"false","isParent":"true", "children":[';


                if ( $xmlx){

                    foreach ($xmlx as $ks => $vs) {
                        //有关键字搜索项目类型打开显示小项无关闭不显示小项
                        if (!empty($search))
                            $str .= '{ "id": "' . $vs['id'] . '","name":"' . $vs['xmlxname'] . '","childOuter":"false","open":"true","isParent":"true","pid":"0","children":[';
                        else
                            $str .= '{ "id": "' . $vs['id'] . '","name":"' . $vs['xmlxname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","children":[';

                        $depxmlxtjxm = arrWhereAnd( $result, ['xmlxid' => $vs['id']]);

                        if ($depxmlxtjxm) {

                            //添加项目类型下体检项目
                            foreach ($depxmlxtjxm as $key => $vo) {

                                $str .= '{ "id": "' . $vo['id'] . '", "pid":"'.$vo['xmlxid'].'", "name":"' . $vo['mc'] . '"},';

                            }
                            $str = substr($str, 0, -1);
                        }
                        $str .= ']},';

                    }


                    //没挂入项目类型小项
                    $deptjxm= arrWhereAnd ($result, [ 'xmlxid' => null]);
                    // $deptjxm =  arrWhereAnd($tjxm,[ 'xmlxid' => null]);
                    if ($deptjxm) {

                        //添加科室下体检项目
                        foreach ($deptjxm as $key => $vo) {

                            $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                        }
                        // $str = substr($str, 0, -1);

                    }


                    $str = substr($str, 0, -1);


                }else{



                    if ($result) {
                        foreach ($result as $key => $vo) {
                            $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                        }

                        $str = substr($str, 0, -1);

                    }
                }





                $str .= ']}]';


                $escapers = array("\\");
                $replacements = array("\\\\");
                $str = str_replace($escapers, $replacements,$str);
                return json(['code' => 1, 'data' => $str, "msg" => "OK"]);


               // return json(['code'=>1,'data'=>$result,'msg'=>'ok']);

            }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
            }

        }

    }

//获取组合项目已选小项
    public function giveSelTjxm($zhxmid,$search)
    {
        if(request()->isAjax()) {
            try {


                $map = [];

                if (!empty($search))
                    $map['tjxm.mc|tjxm.pyjm|tjxm.wbjm'] = ['like', '%' . $search . '%'];


                $result = Db::name('zhxm_hd hd')->join('tjxm tjxm', 'hd.tjlxid=tjxm.tjlxid', 'left')
                    ->join('zhxm_dt dt', 'hd.id=dt.zhxmid and tjxm.id=dt.tjxmid')
                    ->field('tjxm.id id ,tjxm.mc,tjxm.xb,dt.tjxmid ,tjxm.pyjm,tjxm.wbjm,hd.tjlxid,hd.id zhxmid,tjxm.softid softid')
                    ->where(['tjxm.isdel&tjxm.status' => 1, 'hd.id' => $zhxmid])
                    ->where($map)
                    ->order('softid')
                    ->select();


                $str = '[{"id":"0","name":"组合项目已选项目", "open":"true","childOuter":"false","isParent":"true", "children":[';

                if ($result) {
                    foreach ($result as $key => $vo) {
                        $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '"},';

                    }

                    $str = substr($str, 0, -1);

                }

                $str .= ']}]';

                $escapers = array("\\");
                $replacements = array("\\\\");
                $str = str_replace($escapers, $replacements,$str);

                return json(['code' => 1, 'data' => $str, "msg" => "OK"]);

            }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
            }

        }

    }
    /**获取组合项目树 giveZhxm
     * $search 关键字查询
     * $status  禁用是否显示 true显示 false 不显示,本字典维护false，别处引用true
    **/
    public function giveZhxm($search,$status)
    {

        if(request()->isAjax()) {
            //获取所有体检类型
            $result = Model('DepartmentModel')->getDepartments();
          //  $lclx = Model('LclxModel')->where('isdel', 1)->select();

            $map = [];
            $map['isdel']=['=',1];

            if ($status=="true")
             $map['status']=['=',1];

            if (!empty($search))
                $map['mc|pyjm|wbjm'] = ['like', '%' . $search . '%'];

            $zhxm = Model('ZhxmModel')->field('tjlxid,id ,mc,softid,status')
                                        ->where($map)
                                        ->order('tjlxid,softid')
                                        ->select();

            $str = '[{"id":"0","name":"组合项目信息", "open":"true","childOuter":"false","children":[';


            if ($result) {

                foreach ($result as $key => $vo) {
                    //添加体检类型
                    if (!empty($search))
                      $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","isParent":"true","open":"true","pid":"0","children":[';
                   else
                       $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","isParent":"true","open":"false","pid":"0","children":[';

                        $deptjxm = arrWhereAnd($zhxm, ['tjlxid' => $vo['depid']]);
                        if ($deptjxm) {

                            foreach ($deptjxm as $k => $v) {

                                //看体检项目是否启用显示不同图标
                                $icon = '';
                                if ($v['status'] == 0)
                                    $icon = ',"iconSkin":"diy02"';

                                $str .= '{ "id": "' . $v['id'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $vo['depid'] . '"' . $icon . '},';

                            }
                            $str = substr($str, 0, -1);

                        }

                    //}
                    $str .= ']},';

                }
                $str = substr($str, 0, -1);
            }

            //根节点结束
            $str .= ']}]';

            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);
            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }

    }




    /**
     * [ ZhxmAddItems 增加组合项目小项]
     * @return [type] [description]
     * @author [李勇] [peis999]dd
     */
    public function ZhxmEditItems()
    {
        if (request()->isAjax()) {


            $param = input('param.zhxmdt/a');
            $zhxmid = input('param.zhxmid');

            $flag=Model('ZhxmDtModel')->addZhxmDt($zhxmid,$param);

            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);


        }

    }



    /**
     * @return \think\response\Json
     * 组合项目移除已选择的小项(多项)
     */
    public function zhxmDelItems()
    {
        if (request()->isAjax()) {
            $tjxmids = input('param.tjxmids');
            $zhxmid = input('param.zhxmid');
            $flag = Model('ZhxmDtModel')->delZhxmDt($zhxmid,  $tjxmids);
            return json(['code' => $flag['code'], 'data' =>  $flag['data'], 'msg' =>  $flag['msg']]);

        }
    }






}