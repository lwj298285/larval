<?php

namespace app\admin\controller;
use app\admin\model\TjdjModel;
use org\Image;
use think\Db;
use think\Config;
use app\admin\model\TjdjviewModel;
use think\exception\ErrorException;
use think\exception\PDOException;


class Tjdj extends Base

{


    /**
     * [index 医生诊台]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {




        //获取当前日期时间戳
        //$currdate=strtotime(Date("Y-m-d"));
        $jmdj = get_json_emlement('dictionary.json', 0, 'jmdj');

        $tsinfoarr = array_column($jmdj, 'text', 'name');
        $tsinfostr = "";

        foreach ($tsinfoarr as $k => $v) {
            $tsinfostr .= '<b>' . $k . "</b>:[" . $v . "]<br>";
        }


        $this->assign('jbzd', Model('JbzdModel')->where('isdel', 1)->whereIn('dictype', "HYZK,MZ,RYLB,NLDW,LQFS,JSFS")->select());
        $this->assign('fwhy', Model('FwhyModel')->where('isdel&status', 1)->select());
        $this->assign('ywlx', Model('YwlxModel')->select());
        $this->assign('currdate', Date("Y-m-d"));
        $this->assign('jmdj', $jmdj);
        $this->assign('jmdjinfo', $tsinfostr);

        $this->assign('tjdw',Model('TjdwModel')->where(['isdel&status'=>1,'hospitalid'=>session('hospitalid')])->order('id asc')->select());
        $this->assign('grtc',Model('TjtcModel')->where(['status'=>1,'hospitalid'=>session('hospitalid')])
                                                                 ->where('sfsh',1)
                                                                 ->whereOr('sfsh=0 and (zk is null or zkhjg is null)')
                                                                  ->order('id asc')
                                                                 ->select());




        $xtcs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>['in','txm,ydd,mrdyydd,mrdytxm,lqfsemailid,sfxhdy,mrmz,mrnldw,mrtjlqfs,mrgrlqfs']])->select();


       // $txmbbkd=array_column(arrWhereAnd($xtcs, ['mc' => 'txmbbkd']),'value');
        $mrdyydd=array_column(arrWhereAnd($xtcs, ['mc' => 'mrdyydd']),'value');
        $mrdytxm=array_column(arrWhereAnd($xtcs, ['mc' => 'mrdytxm']),'value');
        $lqfsemailid=array_column(arrWhereAnd($xtcs, ['mc' => 'lqfsemailid']),'value');
        $sfxhdy=array_column(arrWhereAnd($xtcs, ['mc' => 'sfxhdy']),'value');

        $txmtype=array_column(arrWhereAnd($xtcs, ['mc' => 'txm']),'value');
        $yddtype=array_column(arrWhereAnd($xtcs, ['mc' => 'ydd']),'value');

        $mrmz=array_column(arrWhereAnd($xtcs, ['mc' => 'mrmz']),'value');
        $mrnldw=array_column(arrWhereAnd($xtcs, ['mc' => 'mrnldw']),'value');
        $mrtjlqfs=array_column(arrWhereAnd($xtcs, ['mc' => 'mrtjlqfs']),'value');
        $mrgrlqfs=array_column(arrWhereAnd($xtcs, ['mc' => 'mrgrlqfs']),'value');

        $txmname=empty($txmtype)?"":$txmtype[0];
        $yddname=empty($yddtype)?"": $yddtype[0];


      //  $this->assign('txmbbkd',empty($txmbbkd)?"":$txmbbkd[0]);
        $this->assign('mrdyydd',empty($mrdyydd)?"":$mrdyydd[0]);
        $this->assign('mrdytxm',empty($mrdytxm)?"":$mrdytxm[0]);

        $this->assign('mrmz',empty($mrmz)?"":$mrmz[0]);
        $this->assign('mrnldw',empty($mrnldw)?"":$mrnldw[0]);
        $this->assign('mrtjlqfs',empty($mrtjlqfs)?"":$mrtjlqfs[0]);
        $this->assign('mrgrlqfs',empty($mrgrlqfs)?"":$mrgrlqfs[0]);

        $this->assign('lqfsemailid',empty($lqfsemailid)?"":$lqfsemailid[0]);
        $this->assign('sfxhdy',empty($sfxhdy)?"":$sfxhdy[0]);


        $reportmb=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>['in',$yddname.','.$txmname],'isdel'=>1])->select();
        $this->assign('yddmb',arrWhereAnd($reportmb, ['name' => $yddname]));


        $ydd=collection(arrWhereAnd($reportmb, ['name' => $yddname,'isdefault'=>1]));
        $txm=collection(arrWhereAnd($reportmb, ['name' => $txmname,'isdefault'=>1]));



        $this->assign('yddmbfile',$ydd->isEmpty()?"":$ydd->column('mbfile')[0]);
        $this->assign('yddmbcs',$ydd->isEmpty()?"":$ydd->column('mbcs')[0]);
        $this->assign('yddid',$ydd->isEmpty()?"":$ydd->column('id')[0]);


        $this->assign('txmmbfile',$txm->isEmpty()?"":$txm->column('mbfile')[0]);
        $this->assign('txmmbcs',$txm->isEmpty()?"":$txm->column('mbcs')[0]);
        $this->assign('txmid',$txm->isEmpty()?"":$txm->column('id')[0]);

        $jkzywlx=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'jkzywlx'])->value('value');
        $this->assign('jkzywlx',empty( $jkzywlx)?"": $jkzywlx);

        return $this->fetch();
    }

    /*
     getDjInfo() 判断人员是否登记
    $xm  姓名
    $sfzh 身份证号
    */

    public function getDjInfo($xm, $sfzh = '')
    {
        try {

            global $userHaveField,$jmdj;


            if (!empty($xm))
                $map['xm']=$xm;
            if (!empty($sfzh))
                $map['sfzh']=$sfzh;

            $map['hospitalid']=session('hospitalid');

            $result = Model('TjdjModel')->withTrashed()->field('max(tjcs) as tjcs,tjbh')//自动获取不需要判断 ->whereNull('delete_time')
                    ->where($map)
                    ->group('tjbh')
                    ->select();

           /* $result = Model('TjdjModel')->field('max(tjcs) as tjcs,tjbh')//自动获取不需要判断 ->whereNull('delete_time')
            //->whereNotIn('jdbz','0,1')  //弃检预登记人员不显示
               // ->where('xm=:xm or sfzh=:sfzh')
                //->bind(['xm' => $xm, 'sfzh' => $sfzh])
                ->where($map)
                ->group('tjbh')
                ->buildSql();

           $result = Model('TjdjviewModel')->alias('t')
                ->join($subquery . ' m', 'm.maxtjcs=t.tjcs and m.tjbh=t.tjbh')
                ->field('t.*')->select();*/



            $djlist=[];

            if (!collection($result)->isEmpty()) {

                $userHaveJmdj = Model('UserModel')->where('jobnum', session('jobnum'))->value('havejmdj');
                //获取加密等级所对应字段
                $jmdj = get_json_emlement('dictionary.json', 0, 'jmdj');

                //获取操作员所能看见的加密字段

                foreach ($jmdj as $k => $v) {

                    if (strpos($userHaveJmdj, $v["id"]))
                        $userHaveField.= $v["value"] . ',';


                }
            }


            foreach($result as  $lastuser){

                //设置体检人员表中不存在字段的获取器属性 用于存放对应加密字段

                 $djuser=Model('TjdjviewModel')->withTrashed()->where(['tjbh'=> $lastuser['tjbh'],'tjcs'=>$lastuser['tjcs']])->find();

                 foreach ($jmdj as $k => $v) {
                    //tjdj model 对象添加字段存储设置加密的字段
                    if ( $djuser->jmfs== $v["id"]){
                        $djuser->Append(['cusSetField','userHaveField']);
                        $djuser->cusSetField=$v['value'];
                        $djuser->userHaveField=$userHaveField;
                        break;
                    }else{
                        continue;

                    }

                    $djuser->Append(['cusSetField','userHaveField']);
                    $djuser->cusSetField='';
                    $djuser->userHaveField=$userHaveField;

                    // return $djuser->userHaveField;
                }

                $djuser->toArray(); //转数组一次性取得所有获取器

                $djlist[]=  $djuser;


            }

            return json(['code' => 1, 'data' =>  $djlist, 'msg' => '']);


        } catch (PDOException $e) {

            return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
        }
    }



//下载身份证插件
    public function getInstallCert()
    {

        $filename='cert.exe';//input('param.filename');
        $file= $filename;
        if (!file_exists($file))
        {
            echo "the file does not exist!";
            exit();
        }


        $file_size=filesize($file);
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length:". $file_size);
        header("Content-Disposition: attachment; filename=".$filename);
        $fp=fopen($file,"rb");
        if (!$fp)
            echo "can't open file!";
        $buffer_size=1024;
        $cur_pos=0;
        while (!feof($fp)&&$file_size-$cur_pos>$buffer_size)
        {
            $buffer=fread($fp,$buffer_size);
            echo $buffer;
            $cur_pos+=$buffer_size;
        }
        $buffer=fread($fp,$file_size-$cur_pos);
        echo $buffer;
        fclose($fp);

    }

//添加修改登记
    public function editTjdj()
    {


        $tjdj = new TjdjModel();
        try {
            if (request()->isAjax()) { //ajax 提交
                if (request()->isPost()) { // 判断提交方式 post为 更新和新增

                    $param = request()->except('search,tjdjzhxm,yddmb','post');
                    $zhxms = input('post.tjdjzhxm/a');

                    $flag = $tjdj->editTjdj($param, $zhxms);
                  //  return json(['code' => $flag['code'], 'data' => $flag['data'], 'data1' => $flag['data1']]);
                    return json(['code' => $flag['code'], 'tjbh' => $flag['tjbh'], 'djlsh' => $flag['djlsh'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

                } else {//get 为获取数据


                }
            }
        }catch(ErrorException $e){
            return json(['code' => 0, 'tjbh' =>'', 'djlsh' => '', 'data' =>'', 'msg' =>$e->getMessage()]);
        }

    }




        /* $param = input('post.');
           $djlsh=(int) (Model('TjdjModel')->where(['hospitalid'=>session('hospitalid'),'djrq'=>$param['djrq']])->max('djlsh'));

           if (empty($djlsh))
               $djlsh='00001';
           else
               $djlsh=addZero(5,$djlsh+1,'0');
           $param['tjbh']=str_replace('-','',$param['djrq']).$djlsh;

            return json(['code'=>1,'data'=>'','msg'=>$param['tjbh']]);*/






//确认预登记
    public function qrYdj()
    {


        $tjdj = new TjdjModel();
        if (request()->isAjax()) { //ajax 提交

                $data = input('param.data/a');
                $flag = $tjdj->ydjQr($data);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

        }

    }

    /*上传头像数据
    $imgData 图片数据流 base64
    剪裁图片按比例缩放
    */

    public function upload($imgData='', $photoname,$copyfile='')
    {


        if (request()->isPost()) {

            try {
                $new_file = UPLOAD_PATH . "photo/";
                // return json(['code'=>0,'data'=> $new_file,'msg'=>'上传图片失败']);
                if (!file_exists($new_file)) {
                    //检查是否有该文件夹，如果没有就创建，并给予最高权限
                    mkdir($new_file, 0700);
                }

                if (empty($copyfile)) {
                    header('Content-type:textml;charset=utf-8');
                    $base64_image_content = $imgData;

                    //匹配出图片的格式
                    if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64_image_content, $result)) {
                        $type = $result[2];
                        $new_file = $new_file . $photoname . ".{$type}";  //登记号为个人图片名称
                        if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $base64_image_content)))) {
                            $image = Image::open($new_file);
                            $image->thumb(102, 126)->save($new_file);
                            return json(['code' => 1, 'data' => '', 'msg' => '保存图片成功']);
                        } else {
                            return json(['code' => 0, 'data' => '', 'msg' => '保存图片失败']);
                        }
                    }
                } else {


                   if (file_exists($new_file.$copyfile) && $copyfile!=$photoname.'.jpeg') {

                       if (copy($new_file . $copyfile, $new_file . $photoname.'.jpeg'))

                           return json(['code' => 1, 'data' => '', 'msg' => '保存图片成功']);
                       else
                           return json(['code' => 0, 'data' => '', 'msg' => '保存图片失败']);
                   }
                    return json(['code' => 1, 'data' => '', 'msg' => '']);


                }
            }catch (ErrorException $e){

                return json(['code' => 0, 'data' => '', 'msg' =>$e->getMessage()]);
            }

        }
    }


    //体检登记人员弃检
    public function setQj($data)
    {

        if ($this->request->isAjax()) {
            if (is_array($data)) {

                Db::startTrans();
                try {
                    foreach ($data as $v) {

                        //软删除 只能一条删 并且找到数据后再软删除 其实是更新
                        $flag = TjdjModel::where(['tjbh' => $v['tjbh'], 'tjcs' => $v['tjcs'], 'hospitalid' => session('hospitalid')])->setField('jdbz',0);
                        //$flag = TjdjModel::where(['tjbh' => $v['tjbh'], 'tjcs' => $v['tjcs'], 'hospitalid' => session('hospitalid')])->setField('jdbz', 0);

                        if ($flag === false) {

                            Db::rollback();
                            writelog(session('uid'), session('username'), '弃检失败', 2);
                            return json(['code' => 0, 'data' => '', 'msg' => '弃检失败']);

                        }else{

                            $jlflage=Model('tjjlbModel')->where(['tjbh' => $v['tjbh'], 'tjcs' => $v['tjcs'], 'hospitalid' => session('hospitalid')])->setField('jsover',0);

                            if ($jlflage === false) {

                                Db::rollback();
                                writelog(session('uid'), session('username'), '弃检失败', 2);
                                return json(['code' => 0, 'data' => '', 'msg' => '弃检失败']);

                            }
                        }

                    }

                    Db::commit();
                    writelog(session('uid'), session('username'), '弃检成功', 1);
                    return json(['code' => 1, 'data' => '', 'msg' => '弃检成功']);

                } catch (PDOException $e) {
                    Db::rollback();
                    return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

                }


            }


        }

    }


    //删除体检登记
    public function delTjdj($data)
    {


        if ($this->request->isAjax()) {
            if (is_array($data)) {

                Db::startTrans();
                try {

                    $str="";
                    $indexs=[];
                    $i=0;

                    foreach ($data as $v) {

                        //软删除 只能一条删 并且找到数据后再软删除 其实是更新

                        $jdbz=TjdjModel::where(['tjbh' => $v['tjbh'], 'tjcs' => $v['tjcs'], 'hospitalid' => session('hospitalid')])->value('jdbz');

                        if ($jdbz == 0 || $jdbz == 1 || $jdbz == 10) {  //弃检 预登记  未检可删除

                            $flag = TjdjModel::where(['tjbh' => $v['tjbh'], 'tjcs' => $v['tjcs'], 'hospitalid' => session('hospitalid')])->find()->delete();


                            if ($flag === false) {

                                Db::rollback();
                                writelog(session('uid'), session('username'), '删除体检登记失败', 2);
                                return json(['code' => 0, 'data' => '', 'msg' => '删除体检登记失败']);

                            }

                            $str.='tjbh:'.$v['tjbh'].',tjcs:'.$v['tjcs'].',';
                            $indexs[$i]=intval($v['index']);
                            $i++;

                        }
                    }


                    $str = substr($str, 0, -1);
                    //$strindex=substr($strindex, 0, -1);

                    Db::commit();
                    if ($str!="" ) {
                        if (strlen($str)>100)
                            writelog(session('uid'), session('username'), '删除体检登记成功', 1);
                        else
                            writelog(session('uid'), session('username'), '删除体检登记('.$str.')成功', 1);

                        return json(['code' => 1, 'data' => $indexs, 'msg' => '删除体检登记成功']);

                    }else{
                        return json(['code' => 2, 'data' => '', 'msg' => '所选登记已在检不可删除']);

                    }

                } catch (PDOException $e) {
                    Db::rollback();
                    return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

                }


            }


        }

    }


    //默认获取当前日期体检登记人员
    public static function getTjdjList()
    {

        if (request()->isAjax()) {
            //如果没传参数 默认查询数据登记日期为当前日期

            global $userHaveField,$jmdj;

            try {

                $datetype = input('param.datetype');
                $startdate = input('param.startdate');
                $enddate = input('param.enddate');
                $tjbh = input('param.tjbh');
                $isgetydj = input('param.isgetydj');
                $isgetqj = input('param.isgetqj');
                $txmprint = input('param.txmprint/a');
                $yddprint = input('param.yddprint/a');
                $isgetzj = input('param.isgetzj');
                $isgetzt = input('param.isgetzt');
                $isgetbg = input('param.isgetbg');
                $isgetqs = input('param.isgetqs');
                $isfctz = input('param.isfctz');
                $fcts = input('param.fcts/a');
                $isgetjkz = input('param.isgetjkz');
                $issendbg = input('param.issendbg');
                $tjdw = input('param.tjdw');
                $tjlb = input('param.tjlb/a');
                $isydd = input('param.isydd');
                $isall = input('param.isall');
                $where= input('param.where/a',null,null);



                $map['hospitalid'] = ['=', session('hospitalid')];
                $map['djrq'] = ['=', Date("Y-m-d")];


                if ($datetype == 'tjrq') {
                    unset($map['djrq']);
                    if (!empty($startdate) && !empty($enddate)) {
                        $map['tjrq'] = ['between', [$startdate, $enddate]];
                    } else {
                        $map['tjrq'] = ['=', Date("Y-m-d")];
                    }

                } else {

                    if (!empty($startdate) && !empty($enddate))
                        $map['djrq'] = ['between', [$startdate, $enddate]];

                }


                if (!empty($tjbh))
                    $map['tjbh|xm|djlsh|xm_pym'] = ['like', '%' . $tjbh . '%'];

                if (!empty($tjdw))
                    $map['dwid'] = ['=', $tjdw];

                if (!empty($tjlb)) {

                    $map['tjlb'] = ['in', implode(",", $tjlb)];

                }


                if ($isgetzj == 1){
                    $map['jdbz'] = ['>', 15];
                    $map['dwstatus'] = [['exp','is null'],['=',1],'or'];
                }else if($isgetzt ==1 ){
                    //$map['jdbz'] = ['not in', '0,1,40,50,60'];
                    $map['dwstatus'] = [['exp','is null'],['=',1],'or'];
                    $map['jdbz'] = ['in', '10,15,20,30,35'];
                } else {

                    if ($isgetydj==1 && $isgetqj!=1 ) {
                        //unset( $map['tjrq']);
                        //unset( $map['djrq']);
                        $map['dwstatus'] = [['exp','is null'],['=',1],'or'];
                        $map['jdbz'] = ['=', 1];
                    }else if($isgetydj!=1 && $isgetqj==1 ) {
                        //unset( $map['tjrq']);
                        //unset( $map['djrq']);
                        $map['jdbz'] = ['=', 0];
                    }else if ($isgetydj!=1 && $isgetqj!=1 ) {

                        $map['jdbz'] = ['not in', '0,1'];
                        $map['dwstatus'] = [['exp','is null'],['=',1],'or'];
                        if (is_array($txmprint) && count($txmprint) == 1)
                            $map['txmprintcs'] = $txmprint[0] == 1 ? ['EXP', 'IS NULL'] : ['EXP', 'IS NOT NULL'];

                        if (is_array($yddprint) && count($yddprint) == 1)
                            $map['yddprintcs'] = $yddprint[0] == 1 ? ['EXP', 'IS NULL'] : ['EXP', 'IS NOT NULL'];

                    }

                }

                //获取引导单pdf
                 if($isydd==1)
                       $map['jdbz'] = ['<>', 0];


                //复查通知
                if($isfctz==1) {

                   // $map['jdbz'] = ['in', "20,30,35,40,50,60"];
                    $map['jdbz'] = ['>', "15"];
                    if (is_array($fcts) && count($fcts)==1)
                        $map['fcts'] = ['=', $fcts[0]];
                    else
                        $map['fcts'] = ['in', "1,2"];
                }

               //打印报告
                if ($isgetbg==1)
                    $map['jdbz'] = ['>', 35];
                    //$map['jdbz'] = ['in', "40,50,60"];



                //打印健康证
                if ($isgetjkz==1){
                    $jkzywlx=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'jkzywlx'])->value('value');
                    $map['ywlx'] = ['=', $jkzywlx];
                   // $map['jdbz'] = ['in', "40,50,60"];
                    $map['jdbz'] = ['>', 35];

                }

                //发送报告
                if ($issendbg==1){
                    $lqfsemailid=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'lqfsemailid'])->value('value');
                    $map['sv_callback'] = ['=', $lqfsemailid];
                   // $map['jdbz'] = ['in', "40,50,60"];
                    $map['jdbz'] = ['>', 35];
                    if (is_array($fcts) && count($fcts)==1)
                        $map['fsr'] =$fcts[0]==1?['EXP', 'IS NULL']:['EXP', 'IS NOT NULL'];

                }


                //报告签收  已打印 已发送
                if ($isgetqs==1)
                    $map['jdbz'] = ['>', 40];
                //$map['jdbz'] = ['in', "50,60,70"];


                //获取所有状态体检人员
                if ($isall==1)
                    unset($map['jdbz']);



                if (!empty($where) && is_array($where))
                    $map['jdbz']=$where;


                $userlist= TjdjviewModel::all($map);  //Db::name('tjdjbview')->where($map)->select();

                $djlist=[];

                //获取当前操作员所拥有加密字段信息
                if (!collection($userlist)->isEmpty()) {

                    $userHaveJmdj = Model('UserModel')->where('jobnum', session('jobnum'))->value('havejmdj');
                    //获取加密等级所对应字段
                    $jmdj = get_json_emlement('dictionary.json', 0, 'jmdj');

                    //获取操作员所能看见的加密字段

                    foreach ($jmdj as $k => $v) {

                        if (strpos($userHaveJmdj, $v["id"]))
                           $userHaveField.= $v["value"] . ',';


                    }
                }

               foreach($userlist as  $djuser){


                        //  if ($djuser->dwstatus==1 || $djuser->dwstatus==null ) {

                              //设置体检人员表中不存在字段的获取器属性 用于存放对应加密字段
                              foreach ($jmdj as $k => $v) {
                                  //tjdj model 对象添加字段存储设置加密的字段
                                  if ($djuser->jmfs == $v["id"]) {
                                      $djuser->Append(['cusSetField', 'userHaveField']);
                                      $djuser->cusSetField = $v['value'];
                                      $djuser->userHaveField = $userHaveField;
                                      break;
                                  } else {
                                      continue;

                                  }

                                  $djuser->Append(['cusSetField', 'userHaveField']);
                                  $djuser->cusSetField = '';
                                  $djuser->userHaveField = $userHaveField;
                                  // return $djuser->userHaveField;*/
                              }

                              $djuser->toArray(); //转数组一次性取得所有获取器

                              $djlist[] = $djuser;
                          }



               //  }


                 return  $djlist;

            }catch (PDOException $e){
                return [];
            }

       }

    }



    //获取指定日期内某些进度标志人员
    public static function getJdbzList($dwid,$datetype,$startdate,$enddate,$jdbz)
    {

            //如果没传参数 默认查询数据登记日期为当前日期

            global $userHaveField,$jmdj;

            try {


                if (!empty($dwid))
                    $map['dwid'] = ['=', $dwid];

                $map['hospitalid'] = ['=', session('hospitalid')];


                if ($datetype == 'tjrq') {
                    if (!empty($startdate) && !empty($enddate))
                        $map['tjrq'] = ['between', [$startdate, $enddate]];


                } else {

                    if (!empty($startdate) && !empty($enddate))
                        $map['djrq'] = ['between', [$startdate, $enddate]];

                }




                $map['jdbz'] = ['in', $jdbz];






                $userlist= TjdjviewModel::all($map);//Db::name('tjdjbview')->where($map)->select();

                $djlist=[];

                //获取当前操作员所拥有加密字段信息
                if (!collection($userlist)->isEmpty()) {

                    $userHaveJmdj = Model('UserModel')->where('jobnum', session('jobnum'))->value('havejmdj');
                    //获取加密等级所对应字段
                    $jmdj = get_json_emlement('dictionary.json', 0, 'jmdj');

                    //获取操作员所能看见的加密字段

                    foreach ($jmdj as $k => $v) {

                        if (strpos($userHaveJmdj, $v["id"]))
                            $userHaveField.= $v["value"] . ',';


                    }
                }

                foreach($userlist as  $djuser){

                    //设置体检人员表中不存在字段的获取器属性 用于存放对应加密字段
                    foreach ($jmdj as $k => $v) {
                        //tjdj model 对象添加字段存储设置加密的字段
                        if ($djuser->jmfs== $v["id"]){
                            $djuser->Append(['cusSetField','userHaveField']);
                            $djuser->cusSetField=$v['value'];
                            $djuser->userHaveField=$userHaveField;
                            break;
                        }else{
                            continue;

                        }

                        $djuser->Append(['cusSetField','userHaveField']);
                        $djuser->cusSetField='';
                        $djuser->userHaveField=$userHaveField;
                        // return $djuser->userHaveField;*/
                    }

                    $djuser->toArray(); //转数组一次性取得所有获取器

                    $djlist[]= $djuser;


                }


                return  $djlist;

            }catch (PDOException $e){
                return [];
            }


    }


    //获取个人套餐或者单位分组信息
    public function getZhxmInfo()
    {
        if (request()->isAjax()) {


            $param=input('param.');

            try {
                if (!empty($param['dwid']) && !empty($param['tcid'])  ) {  //单位分组套餐

                    $pid=Db::query('select dbo.GetDWPID('.$param['dwid'].','.session('hospitalid').') as topdwid ');

                    $data=Model('ZhxmModel')->alias('zh')
                        ->join('dwfz_tc dt','zh.id=dt.zhxmid and dt.hospitalid='.session('hospitalid').' and dwid='.$pid[0]['topdwid'].' and fzid='.$param['tcid'],'left')
                        ->field('mc,xb,case when dt.zhxmid is not null then 0 else 1 end as tcwxm,case when dt.zhxmid is not null then case when dt.jg is not null then dt.jg else zh.jg end else zh.jg end as jg')
                        ->find($param['zhxmid']);

                    return json(['code' => 1,'data' =>$data , 'msg' => 'ok']);

                } else if(!empty($param['tcid'])){                        //个人套餐

                    $data=Model('ZhxmModel')->alias('zh')
                         ->join('tjtc_dt dt','zh.id=dt.zhxmid and dt.hospitalid='.session('hospitalid').' and tcid='.$param['tcid'],'left')
                         ->field('mc,xb,case when dt.zhxmid is not null then 0 else 1 end as tcwxm,case when dt.zhxmid is not null then case when dt.jg is not null then dt.jg else zh.jg end else zh.jg end as jg')
                         ->find($param['zhxmid']);

                    return json(['code' => 1,'data' =>$data , 'msg' => 'ok']);
                }else {

                    return json(['code' => 1, 'data' => Model('ZhxmModel')->field('mc,xb,jg,1 as tcwxm')->find($param['zhxmid']), 'msg' => 'ok']);

                }
            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => '获取套餐数据失败']);
            }

        }
    }

    // 获取年龄
    //获取个人套餐或者单位分组信息
    public function getNl($brithday)
    {
        if (request()->isAjax()) {
            try {


               $NlAndDw= Db::query("select dbo.GetNLCN('".$brithday."') nl");
               $NlAndDwArr = explode(',',array_column($NlAndDw,'nl')[0]);


               return json(['code' => 1, 'data' =>['NL'=>$NlAndDwArr[0],'DW'=>$NlAndDwArr[1]] , 'msg' => 'ok']);


            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => '获取年龄失败']);
            }

        }
    }


  //获取登记记录表组合项目状态
    public function getZhxmStatus($xh,$zhxmid){

        if (request()->isAjax()) {
            $status = Model('TjjlbModel')->where(['xh' => $xh, 'zhxmid' => $zhxmid, 'hospitalid' => session('hospitalid')])->value('jsover');
            return $status;
        }


    }


    //获取登记人员组合项目
    public function getTjdjZhxm($tjbh, $tjcs)
    {
        if (request()->isAjax()) {
            // return json(Model('TjjlbModel')->where(['tjbh' => $tjbh, 'tjcs' => $tjcs, 'hospitalid' => session('hospitalid')])->select());
            try {

                $data = Model('TjjlbModel')->alias('jl')
                    ->join('zhxm_hd hd', 'jl.zhxmid=hd.id', 'left')
                    ->field('hd.id ,hd.mc,jl.xh,jl.tcwxm,jl.xmdj,hd.softid')
                    ->where(['hd.isdel&hd.status' => 1, 'jl.tjbh' => $tjbh, 'jl.tjcs' => $tjcs,'jsover'=>['<>',0], 'hospitalid' => session('hospitalid')])
                    ->order('tcwxm,softid')
                    ->select();


                return json($data);

            } catch (PDOException $e) {

                return json(['code' => 0, 'data' => '', 'msg' => '获取登记组合项目失败']);
            }

        }

    }
}