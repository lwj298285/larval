<?php

namespace app\admin\controller;
use app\admin\model\TjdjModel;
use app\admin\model\DwfzModel;
use app\admin\model\TjjlbModel;
use app\admin\model\YsztModel;
use think\console\command\make\Model;
use think\Db;
use think\exception\PDOException;

class Tjydj extends Base
{

    /**
     * [index 体检批量导入预登记]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {
        $dwlist=Model('TjdwModel')->field('CAST(id AS VARCHAR(50))+\',\'+CAST(isnull(jmfs,\'\') AS VARCHAR(50)) as id,dwname')->where(['hospitalid'=>session('hospitalid'),'isdel&status'=>1])->select();

        $yddname=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'ydd'])->value('value');
        $ydd=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>$yddname,'isdel'=>1])->select();

        $this->assign('ydd',$ydd);

        $ydddefault=collection(arrWhereAnd($ydd, ['isdefault'=>1]));

        $this->assign('yddmbfile',$ydddefault->isEmpty()?"":$ydddefault->column('mbfile')[0]);
        $this->assign('yddmbcs',$ydddefault->isEmpty()?"":$ydddefault->column('mbcs')[0]);
        $this->assign('yddid',$ydddefault->isEmpty()?"":$ydddefault->column('id')[0]);
        $this->assign('dwlist',$dwlist);
        $pclist=[];
        array_push($pclist,date('Y',time()));
        array_push($pclist,date('Y',strtotime("-1 year")));
        array_push($pclist,date('Y',strtotime("+1 year")));
        $this->assign('pclist',$pclist);

        return $this->fetch();
    }


    public function getFile($fs){



        try {


            header("Content-type: text/html;charset=utf-8");
            $filename=iconv("utf-8","gbk",$fs);
            $file = DOWNLOAD_PATH . $filename;



            if (!file_exists($file)) {
                echo $file;//"文件不存在";
                exit();
                //return json(['code'=> 0,'data'=> '','msg'=>'文件不存在']);
            }
            $file_size = filesize($file);
            header("Content-type: application/octet-stream");
            header("Accept-Ranges: bytes");
            header("Accept-Length:" . $file_size);
            header("Content-Disposition: attachment; filename=" .  $filename);
            $fp = fopen($file, "r");
            if (!$fp){
                echo "文件无法打开";
                exit();
            }


            // return json(['code'=> 0,'data'=> '','msg'=>'文件不能打开']);

            $buffer_size = 1024;
            $cur_pos = 0;
            while (!feof($fp) && $file_size - $cur_pos > $buffer_size) {
                $buffer = fread($fp, $buffer_size);
                echo $buffer;
                $cur_pos += $buffer_size;
            }
            $buffer = fread($fp, $file_size - $cur_pos);
            echo $buffer;
            fclose($fp);
        }catch (Exception $e){

            echo "下载文件错误，请联系管理员！";

        }



    }




//批量导入存在同名的人员
    public function importXz($data)
    {

        if(request()->isAjax()){ //ajax 提交

            Db::startTrans();
            try {

                $mrtjlqfs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'mrtjlqfs'])->value('value');

                foreach ($data as $rowdata) {


                        $djlsh = (int)Model('TjdjModel')->withTrashed()->where(['hospitalid' => session('hospitalid'), 'djrq' => $rowdata['djrq']])->max('djlsh');

                        $djlshstr=$str=str_replace('-','',$rowdata['djrq']);
                        /*if (empty($djlsh))
                            $djlsh = '00001';
                        else
                            $djlsh = addZero(5, $djlsh + 1, '0');*/

                        if (empty($djlsh) || strpos($djlsh,$djlshstr)===false )
                            $djlsh=str_replace('-', '', $rowdata['djrq']).'0001';
                        else
                            $djlsh =$djlsh + 1;

                        $rowdata['djlsh'] = $djlsh;
                        //$rowdata['tjpc'] = str_replace('-', '', $rowdata['tjrq']);
                        $rowdata['djry'] = session('realname');
                        $rowdata['hospitalid'] = session('hospitalid');
                        $rowdata['wzbgyzm'] =  generateWeirdStr(4).session('hospitalid');
                        $rowdata['sv_callback'] = $mrtjlqfs;


                        if (!empty($rowdata['tcid'])) {
                            $dwfz=DwfzModel::getOneDwfz($rowdata['dwid'], $rowdata['tcid']);
                            if ($dwfz->zk==null || $dwfz->zkhjg==null) {
                                $rowdata['jg'] = $dwfz->jg;
                                $rowdata['sj'] =$dwfz->jg;
                            }else{
                                $rowdata['jg'] = $dwfz->zkhjg;
                                $rowdata['sj'] =$dwfz->zkhjg;

                            }
                        }else{

                            $rowdata['tcid']=null;

                        }

                        if ( $rowdata['jdbz']!=10){

                            $rowdata['ydjry'] =  $rowdata['djry'];
                            $rowdata['ydjrq'] =  $rowdata['djrq'];
                            $rowdata['ytjrq'] =  $rowdata['tjrq'];

                        }

                        if (empty($rowdata['tjbh']))
                            $rowdata['tjbh'] =$djlsh; //str_replace('-', '', $rowdata['djrq']) . $djlsh;

                        $ydjModel=new TjdjModel();

                        $result = $ydjModel->allowField(true)->save($rowdata);


                        if (false === $result) {

                            Db::rollback();
                            writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $rowdata['dwid'] . ')失败', 2);
                            return json(['code' => 0, 'tjbh' => '', 'data' => '', 'msg' =>$ydjModel->getError()  ]);//

                        } else {

                            //根据套餐获取组合项目
                            $zhxms = [];

                            if (!empty($rowdata['tcid'])) {

                               $dwid=Model('TjdwModel')->where(['id'=>$rowdata['dwid'],'hospitalid'=>session('hospitalid')])->value('dbo.GetDWpid(id,hospitalid) dwid');
                               /* $zhxms = Model('DwfzModel')->alias('hd')->join('dwfz_tc tc', 'hd.id=tc.fzid')->field('zhxmid,hd.sj xmdj')
                                    ->where(['hd.id' => $rowdata['tcid'], 'hd.hospitalid' => session('hospitalid'), 'hd.dwid' => $dwid])
                                    ->select();*/

                                $zhxms = Model('DwfzDtModel')->alias('dt')
                                    ->join('zhxm_hd hd','dt.zhxmid=hd.id')
                                    ->join('dwfz_hd fz','dt.fzid=fz.id and dt.hospitalid=fz.hospitalid and dt.dwid=fz.dwid')
                                    ->field('zhxmid,(case when fz.sfsh=0 then hd.jg  else dt.jg end) as xmdj  ')
                                    ->where(['dt.fzid' => $rowdata['tcid'], 'dt.hospitalid' => session('hospitalid'), 'dt.dwid' =>$dwid])
                                    ->select();



                            }

                            $zhxm = [];
                            //写入登记人员套餐组合项目
                            if (is_array($zhxms)) {
                                $xh = Model('TjjlbModel')->where('hospitalid', session('hospitalid'))->max('xh');
                                $xh = empty($xh) ? 1 : $xh + 1;
                                foreach ($zhxms as $key => $v) {
                                    $zhxm[$key]['xh'] = $xh;
                                    $zhxm[$key]['hospitalid'] = session('hospitalid');
                                    $zhxm[$key]['tjbh'] = $rowdata['tjbh'];
                                    $zhxm[$key]['tjcs'] = $rowdata['tjcs'];
                                    $zhxm[$key]['zhxmid'] = $v['zhxmid'];
                                    $zhxm[$key]['xmdj'] = $v['xmdj'];

                                    //获取组合项目小项塞入数组待写入体检结果表中
                                    $zhxmxm=Model('ZhxmDtModel')->alias('dt')
                                        ->join('tjxm','dt.tjxmid=tjxm.id')
                                        ->field($xh.' as xh,'.$v['zhxmid'].' as zhxmid,tjxmid as xmid,jrxj,dw,ckxx as minckz,cksx as maxckz,memockz,'.session('hospitalid').' as hospitalid')
                                        ->where('zhxmid',$v['zhxmid'])->select();

                                    // 保存体检组合项目小项
                                    $xm=[];
                                    foreach ( $zhxmxm as $k =>$value) {


                                        $xm[$k]['xh']=$xh;
                                        $xm[$k]['zhxmid']=$v['zhxmid'];
                                        $xm[$k]['xmid']=$value->xmid;
                                        $xm[$k]['dw']=$value->dw;
                                        $xm[$k]['jrxj']=$value->jrxj;
                                        $xm[$k]['minckz']=$value->minckz;
                                        $xm[$k]['maxckz']=$value->maxckz;
                                        $xm[$k]['memockz']=$value->memockz;
                                        $xm[$k]['hospitalid']=session('hospitalid');

                                    }

                                    $tjjlmxb=new YsztModel();
                                    $result= $tjjlmxb->saveAll($xm,false);

                                    if (false ===$result ) {
                                        Db::rollback();
                                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $rowdata['dwid'] . ')失败', 2);
                                        return ['code' => 0, 'tjbh' => '', 'data' => '', 'msg' =>$tjjlmxb->getError()];
                                    }

                                }

                                if  (is_array($zhxm)) {
                                    $TjjlbModel = new TjjlbModel();
                                    $result = $TjjlbModel->saveAll($zhxm, false);//保存体检组合项目

                                    if (false === $result) {
                                        Db::rollback();
                                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $rowdata['dwid'] . ')失败', 2);
                                        return json(['code' => 0, 'tjbh' => '', 'data' => '', 'msg' => $TjjlbModel->getError()]);

                                    }
                                }

                            }

                        }


                }


                Db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】选择批量导入登记信息单位ID(' . $data[0]['dwid'] . ')成功', 1);
                return ['code' => 1,  'data' =>'', 'msg' => '选择批量导入之前无登记信息人员人成功'];


            }catch(PDOException $e){

                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】选择批量导入登记信息单位ID(' . $data[0]['dwid'] . ')失败', 2);
                return json(['code' => 0, 'tjbh' => '', 'data' => '', 'msg' => $e->getMessage()]);

            }


        }

    }






//批量导入预登记人员，按名称对比，不存在的写入，存在同名回调选择同名人员，不选择当做新人员登记
    public function importTjdj($data)
    {
        $txt="";
        if(request()->isAjax()){ //ajax 提交

            Db::startTrans();
            try {

                $wdjRs=0;  //之前无登记人员数量
                $ydjRs=0;  //之前有登记人员数量
                $ydjRsArr=[];//之前有登记人员数量封装回调
                $mrtjlqfs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>'mrtjlqfs'])->value('value');

                foreach ($data as $rowdata) {


                    /* if (!empty($rowdata['sfzh']))
                      $olddata = Model('TjdjModel')->withTrashed()->field('max(tjcs) as tjcs,dbo.GetNLCN(csnyr) as nl,tjbh')//自动获取不需要判断 ->whereNull('delete_time')
                           ->where(['hospitalid' => session('hospitalid'), 'sfzh' => $rowdata['sfzh']])
                          ->group('tjbh,csnyr')
                          ->find();
                  else
                  $olddata = Model('TjdjModel')->withTrashed()->field('max(tjcs) as tjcs,dbo.GetNLCN(csnyr) as nl,tjbh')//自动获取不需要判断 ->whereNull('delete_time')
                          ->where(['hospitalid' => session('hospitalid'), 'xm' => $rowdata['xm']])
                          ->group('tjbh,csnyr')
                          ->find();*/



                    $olddata = Model('TjdjModel')->withTrashed()->field('max(tjcs) as tjcs,dbo.GetNLCN(csnyr) as nl,tjbh')//自动获取不需要判断 ->whereNull('delete_time')
                        ->where(['hospitalid' => session('hospitalid'), 'xm' => $rowdata['xm']])
                        ->group('tjbh,csnyr')
                        ->find();

                    if (!empty($olddata)) {
                        /* $rowdata['tjbh'] = $olddata['tjbh'];
                      $rowdata['tjcs'] = $olddata['tjcs'] + 1;*/
                      $nl = explode(',', $olddata->nl)[0];
                      $dw = explode(',', $olddata->nl)[1];
                      $rowdata['nl'] = $nl;
                      $rowdata['nldw'] = Model('JbzdModel')->where(['name' => $dw, 'dictype' => 'NLDW'])->value('id');
                      $ydjRsArr[$ydjRs]=$rowdata;
                      $ydjRs++;

                    } else {

                        //$rowdata['tjcs'] = 1;
                        $NlAndDw = Db::query("select dbo.GetNLCN('" . $rowdata['csnyr'] . "') nl");
                        $NlAndDwArr = explode(',', array_column($NlAndDw, 'nl')[0]);
                        $rowdata['nl'] = $NlAndDwArr[0];
                        $rowdata['nldw'] = Model('JbzdModel')->where(['name' => $NlAndDwArr[1], 'dictype' => 'NLDW'])->value('id');


                        //  写入数据

                        $djlsh = (int)Model('TjdjModel')->withTrashed()->where(['hospitalid' => session('hospitalid'), 'djrq' => $rowdata['djrq']])->max('djlsh');

                        $djlshstr=$str=str_replace('-','',$rowdata['djrq']);




                       /* if (empty($djlsh))
                            $djlsh = '00001';
                        else
                            $djlsh = addZero(5, $djlsh + 1, '0');*/

                        if (empty($djlsh) ||  strpos($djlsh,$djlshstr)===false)
                            $djlsh=str_replace('-', '', $rowdata['djrq']).'0001';
                        else
                            $djlsh =$djlsh + 1;

                        $rowdata['djlsh'] = $djlsh;
                      // $rowdata['tjpc'] = str_replace('-', '', $rowdata['tjrq']);
                        $rowdata['djry'] = session('realname');
                        $rowdata['hospitalid'] = session('hospitalid');
                        $rowdata['tjbh'] = $djlsh;// str_replace('-', '', $rowdata['djrq']) . $djlsh;
                        $rowdata['wzbgyzm'] =  generateWeirdStr(4).session('hospitalid');
                        $rowdata['sv_callback'] = $mrtjlqfs;

                        if (!empty($rowdata['tcid'])) {

                            $dwfz=DwfzModel::getOneDwfz($rowdata['dwid'], $rowdata['tcid']);
                            if ($dwfz->zk==null || $dwfz->zkhjg==null) {
                                $rowdata['jg'] = $dwfz->jg;
                                $rowdata['sj'] =$dwfz->jg;
                            }else{
                                $rowdata['jg'] = $dwfz->zkhjg;
                                $rowdata['sj'] =$dwfz->zkhjg;

                            }
                          }else{
                            $rowdata['tcid']=null;

                        }

                        if ( $rowdata['jdbz']!=10){

                            $rowdata['ydjry'] =  $rowdata['djry'];
                            $rowdata['ydjrq'] =  $rowdata['djrq'];
                            $rowdata['ytjrq'] =  $rowdata['tjrq'];

                        }



                        $ydjModel=new TjdjModel();


                        $result = $ydjModel->allowField(true)->save($rowdata);


                        if (false === $result) {

                            Db::rollback();
                            writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $rowdata['dwid'] . ')失败', 2);
                            return json(['code' => 0, 'tjbh' => '', 'data' => '', 'msg' => $ydjModel->getError() ]);

                        } else {

                            //根据 分组套餐获取组合项目及价格
                            $zhxms = [];

                            if (!empty($rowdata['tcid'])) {

                               $dwid=Model('TjdwModel')->where(['id'=>$rowdata['dwid'],'hospitalid'=>session('hospitalid')])->value('dbo.GetDWpid(id,hospitalid) dwid');
                               /* $zhxms = Model('DwfzModel')->alias('hd')
                                       ->join('dwfz_tc dt', 'hd.id=dt.fzid and hd.hospitalid=dt.hospitalid')
                                       ->join('zhxm_hd zm','dt.zhxmid=zm.id')
                                       ->field('zhxmid,zm.jg xmdj')
                                       ->where(['hd.id' => $rowdata['tcid'], 'hd.hospitalid' => session('hospitalid'), 'hd.dwid' => $dwid])
                                       ->select();*/


                                $zhxms = Model('DwfzDtModel')->alias('dt')
                                    ->join('zhxm_hd hd','dt.zhxmid=hd.id')
                                    ->join('dwfz_hd fz','dt.fzid=fz.id and dt.hospitalid=fz.hospitalid and dt.dwid=fz.dwid')
                                    ->field('zhxmid,(case when fz.sfsh=0 then hd.jg  else dt.jg end) as xmdj  ')
                                    ->where(['dt.fzid' => $rowdata['tcid'], 'dt.hospitalid' => session('hospitalid'), 'dt.dwid' =>$dwid])
                                    ->select();


                            }

                            $zhxm = [];
                            //写入登记人员套餐组合项目
                            if (is_array($zhxms)) {
                                $xh = Model('TjjlbModel')->where('hospitalid', session('hospitalid'))->max('xh');
                                $xh = empty($xh) ? 1 : $xh + 1;
                                foreach ($zhxms as $key => $v) {
                                    $zhxm[$key]['xh'] = $xh;
                                    $zhxm[$key]['hospitalid'] = session('hospitalid');
                                    $zhxm[$key]['tjbh'] = $rowdata['tjbh'];
                                    $zhxm[$key]['tjcs'] = $rowdata['tjcs'];
                                    $zhxm[$key]['zhxmid'] = $v['zhxmid'];
                                    $zhxm[$key]['xmdj'] = $v['xmdj'];

                                    //获取组合项目小项塞入数组待写入体检结果表中
                                    $zhxmxm=Model('ZhxmDtModel')->alias('dt')
                                        ->join('tjxm','dt.tjxmid=tjxm.id')
                                        ->field('tjxmid as xmid,jrxj,dw,ckxx as minckz,cksx as maxckz,memockz')
                                        ->where('zhxmid',$v['zhxmid'])->select();

                                    // 保存体检组合项目小项
                                    $xm=[];
                                    foreach ( $zhxmxm as $k =>$value) {


                                        $xm[$k]['xh']=$xh;
                                        $xm[$k]['zhxmid']=$v['zhxmid'];
                                        $xm[$k]['xmid']=$value->xmid;
                                        $xm[$k]['dw']=$value->dw;
                                        $xm[$k]['jrxj']=$value->jrxj;
                                        $xm[$k]['minckz']=$value->minckz;
                                        $xm[$k]['maxckz']=$value->maxckz;
                                        $xm[$k]['memockz']=$value->memockz;
                                        $xm[$k]['hospitalid']=session('hospitalid');

                                    }

                                    $tjjlmxb=new YsztModel();
                                    $result= $tjjlmxb->saveAll($xm,false);

                                    if (false ===$result ) {
                                        Db::rollback();
                                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $rowdata['dwid'] . ')失败', 2);
                                        return ['code' => 0, 'tjbh' => '', 'data' => '', 'msg' =>$tjjlmxb->getError()];
                                    }




                                }

                                if  (is_array($zhxm)) {
                                    $TjjlbModel = new TjjlbModel();
                                    $result = $TjjlbModel->saveAll($zhxm, false);//保存体检组合项目

                                    if (false === $result) {
                                        Db::rollback();
                                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $rowdata['dwid'] . ')失败', 2);
                                        return json(['code' => 0, 'tjbh' => '', 'data' => '', 'msg' => $TjjlbModel->getError()]);

                                    }
                                }

                            }

                        }

                        $wdjRs++;

                    }



                }


                Db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $data[0]['dwid'] . ')成功', 1);
                return ['code' => 1,  'data' => $ydjRsArr, 'msg' => '批量导入之前无登记信息人员'.$wdjRs.'人成功'];


            }catch(PDOException $e){

                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量导入登记信息单位ID(' . $data[0]['dwid'] . ')失败', 2);
                return json(['code' => 0, 'tjbh' => '', 'data' => '', 'msg' => $e->getMessage()]);

            }


        }

    }




    //导入时如果单位部门字典没有维护自动添加
    function getAddDwBm(){

        if(request()->isAjax()){

            $param =input('param.');
            $flag =Model('DwbmModel')->editDwbm($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

        }

    }





   //导入时如果单位职务字典没有维护自动添加
    function getAddDwZW(){
        if(request()->isAjax()){

            $param =input('param.');
            $flag =Model('DwzwzcModel')->editZwzc($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

        }


    }




}