<?php
namespace app\admin\controller;
use think\Model;
use think\PDOException;


class Index extends Base
{






    // 获取一年内:
    // 1.未完成团体体检的单位 $wei
    // 2.弃检人数 $qi
    // 3.已完成团体体检的单位 $yi
    function getOneYearDw(){
       // $year = date("Y-m-d",time());
        if (request()->isAjax()) {
            $enddate = date("Y-m-d", time()); //$year."-01-01";
            $startdate = date("Y-m-d", strtotime("-1 year"));//$year."-12-31";


            //一年内登记单位信息
            $alldwinfo = Model('TjdjviewModel')->field('dwid,dwname')
                ->where(['tjlb' => 1, 'hospitalid' => session('hospitalid')])
                ->where('jdbz', 'not in', '0,1')
                ->where('djrq', 'between', [$startdate, $enddate])
                ->group('dwid,dwname')
                ->select();

            // 一年内登记单位数量
            $alldwcount = count($alldwinfo);

            // 未完成单位信息
            $wjdwinfo = Model('TjdjviewModel')->field('dwid,dwname')
                ->where(['tjlb' => 1, 'hospitalid' => session('hospitalid')])
                ->where('jdbz', 'between', [10, 35])
                ->where('djrq', 'between', [$startdate, $enddate])
                ->group('dwid,dwname')
                ->select();


            // 未完成单位数量
            $wjdwcount = count($wjdwinfo);


            // 已完成单位信息


            $yjdwinfo = array_values(array_diff($alldwinfo, $wjdwinfo));//collection($alldwinfo)->diff($wjdwinfo);//


            // 已完成单位数量
            $yjdwcount = count($yjdwinfo);


            // 弃检人信息
            /* $qjinfo = Model('TjdjviewModel')->field('djlsh,djrq,xm,xbmc,csnyr,mobile,phone')
                 ->where(['jdbz'=>0,'hospitalid'=>session('hospitalid')])
                 ->where('djrq','between',[$enddate,$firstdate])
                 ->select();*/

            $qjinfo = Tjdj::getJdbzList('','djrq', $startdate, $enddate, '0');


            // 弃检人数量
            $qjcount = count($qjinfo);

            return json(['code' => 1, 'wei' => $wjdwcount, 'qij' => $qjcount, 'yi' => $yjdwcount, 'namewei' => $wjdwinfo, 'nameyi' => $yjdwinfo, 'qjr' => $qjinfo, 'msg' => 'ok']);
        }
    }



    //获取未完成总检单位未总检人员

    function getDwWjperson($dwid){
        // $year = date("Y-m-d",time());
        if (request()->isAjax()) {
            $enddate = date("Y-m-d", time()); //$year."-01-01";
            $startdate = date("Y-m-d", strtotime("-1 year"));//$year."-12-31";

            //未完成体检单位未完成总检人员
            $wjinfo = Tjdj::getJdbzList($dwid, 'djrq', $startdate, $enddate, '10,15,20,30,35');

            return json(['code' => 1, 'wjinfo' => $wjinfo, 'msg' => 'ok']);
        }

    }


    // 获取一周内:
    // 1.来院登记人数 $zongPerson
    // 2.总检人数 $zongj
    // 3.未总检人数 $weizj
    function getPerson(){

        if (request()->isAjax()){
                $week = mb_substr("日一二三四五六", date("w"), 1, "utf-8");
                $week1 = mb_substr("日一二三四五六", date("w", strtotime('-1 days')), 1, "utf-8");
                $week2 = mb_substr("日一二三四五六", date("w", strtotime('-2 days')), 1, "utf-8");
                $week3 = mb_substr("日一二三四五六", date("w", strtotime('-3 days')), 1, "utf-8");
                $week4 = mb_substr("日一二三四五六", date("w", strtotime('-4 days')), 1, "utf-8");
                $week5 = mb_substr("日一二三四五六", date("w", strtotime('-5 days')), 1, "utf-8");
                $week6 = mb_substr("日一二三四五六", date("w", strtotime('-6 days')), 1, "utf-8");

                $weeks = ['星期' . $week6, '星期' . $week5, '星期' . $week4, '星期' . $week3, '星期' . $week2, '星期' . $week1, '星期' . $week];

                $date = Date('Y-m-d');
                $date1 = date('Y-m-d', strtotime('-1 days'));
                $date2 = date('Y-m-d', strtotime('-2 days'));
                $date3 = date('Y-m-d', strtotime('-3 days'));
                $date4 = date('Y-m-d', strtotime('-4 days'));
                $date5 = date('Y-m-d', strtotime('-5 days'));
                $date6 = date('Y-m-d', strtotime('-6 days'));


                // ============================================================================

                try {
                    $djArr = Model('TjdjviewModel')
                        ->field('count(*) as countrs,djrq,jdbz')
                        ->where('djrq', 'between', [$date6, $date])
                        ->where('hospitalid', session('hospitalid'))
                        ->group('djrq,jdbz')
                        ->select();
                    // 一周登记人数
                    $zongPerson = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), $djArr));


                    // 每天登记人数
                    $day = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date])));
                    $day1 = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date1])));
                    $day2 = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date2])));
                    $day3 = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date3])));
                    $day4 = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date4])));
                    $day5 = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date5])));
                    $day6 = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['djrq' => $date6])));
                    $days = [$day6, $day5, $day4, $day3, $day2, $day1, $day];


                    // 弃检
                    $qj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 0])));
                    // 预登记
                    $ydj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 1])));
                    // 正式登记
                    $dj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 10])));
                    // 登记已付款
                    $yfk = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 15])));
                    // 在检
                    $zj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 20])));
                    // 待总检
                    $dzj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 30])));
                    // 预存总检
                    $yczj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 35])));

                    $weijs = [$qj, $ydj, $dj, $yfk, $zj, $dzj, $yczj];

                    // 一周未检人数
                    $weizj = $qj + $ydj + $dj + $yfk + $zj + $dzj + $yczj;


                    // 已总检
                    $zj = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 40])));
                    // 报告已打印
                    $ydy = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 50])));
                    // 报告已发送
                    $yfs = array_sum(array_map(create_function('$val', 'return $val["countrs"];'), arrWhereAnd($djArr, ['jdbz' => 60])));
                    $yijs = [$zj, $ydy, $yfs];

                    // 已总检
                    $zongj = $zj + $ydy + $yfs;



                } catch (\Exception $e) {

                    return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);
                }

                return json(['code' => 1, 'zongPerson' => $zongPerson, 'weizj' => $weizj, 'zongj' => $zongj, 'weeks' => $weeks, 'days' => $days, 'weijs' => $weijs, 'yijs' => $yijs, 'msg' => 'ok']);

       }
    }


    public function getNewhospital($hospitalid,$hospitalname){




        session('hospitalname', $hospitalname);
        if (empty(session('oldhospitalid')))
           session('oldhospitalid', session('hospitalid'));
        session('hospitalid', $hospitalid);

      /* $hospalarr= explode(",", model('UserHospitalModel')->where('jobnum',session('jobnum'))->value('hospital'));
        $userhospital=Model('HospitalModel')
            ->where('id','in',  $hospalarr)
            ->select();

        $this->assign('userhospital',$userhospital);*/

        return json(['code' => 1, 'data' => url('index/index'), 'msg' => '切换医院成功！']);
      //  return $this->fetch('/index');
       // return $this->redirect('/index');*/

    }

    public function index()
    {


        $hospalarr= explode(",", model('UserHospitalModel')->where('jobnum',session('jobnum'))->value('hospital'));
        $grouparr= explode(",", model('UserGroupModel')->where('jobnum',session('jobnum'))->value('groups'));


        $userhospital=Model('HospitalModel')
                       ->where('id','in',  $hospalarr)
                       ->select();

        $usergroup=Model('UserType')
            ->where('id','in',  $grouparr)
            ->select();

        $this->assign('userhospital',$userhospital);
        $this->assign('usergrup',$usergroup);


        return $this->fetch('/index');

    }

    /**
     * [indexPage 后台首页]
     * @return [type] [description]
     * @author [peis999] [864491238@qq.com]
     */
    public function indexPage()
    {
       /* $info = array(
            'web_server' => $_SERVER['SERVER_SOFTWARE'],
            'onload'     => ini_get('upload_max_filesize'),
            'think_v'    => THINK_VERSION,
            'phpversion' => phpversion(),
        );
        $this->assign('info',$info);*/
        return $this->fetch('index');
    }
}
