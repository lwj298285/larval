<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 13:52
 */

namespace app\admin\controller;


use think\console\command\make\Model;
use think\exception\PDOException;

class Tcsh extends Base
{


    /**
     * [index 套餐审核]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){


        return $this->fetch();
    }


    /* getZkxm获取个人折扣套餐组合项目及价格
      $dwid       单位ID
      $fz_tc_id   套餐ID
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    function getZkxm($dwid,$fz_tc_id){

        if (request()->isAjax()) {

              if (empty($dwid)) {
                  //个人套餐
                  $result = Model('TjtcDtModel')->alias('dt')->join('zhxm_hd hd', 'dt.zhxmid=hd.id', 'left')
                      ->field('dt.zhxmid,dt.jg ,mc,sfdz,zdzk,hd.jg as sj')
                      ->where(['hd.isdel&hd.status' => 1, 'dt.tcid' =>$fz_tc_id, 'dt.hospitalid' => session('hospitalid')])
                      ->order('sfdz,zdzk desc')
                      ->select();

                  $zk = Model('TjtcModel')
                      ->field('zk,zkhjg')
                      ->where(['status' => 1, 'id' => $fz_tc_id, 'hospitalid' => session('hospitalid')])
                      ->find();
              }else{
                  //分组套餐
                  $result = Model('DwfzDtModel')->alias('dt')->join('zhxm_hd hd', 'dt.zhxmid=hd.id', 'left')
                      ->field('dt.zhxmid,dt.jg ,mc,sfdz,zdzk,hd.jg as sj')
                      ->where(['hd.isdel&hd.status' => 1, 'dt.fzid' => $fz_tc_id, 'dt.dwid'=>$dwid, 'dt.hospitalid' => session('hospitalid')])
                      ->order('sfdz,zdzk desc')
                      ->select();

                  $zk= Model('DwfzModel')
                      ->field('zk,zkhjg')
                      ->where(['status' => 1, 'dwid'=>$dwid,'id' => $fz_tc_id, 'hospitalid' => session('hospitalid')])
                      ->find();


              }

            return json(['data'=>$result,'zk'=> $zk->zk,'zkhjg'=>$zk->zkhjg]);
        }

    }



    /**
     * [shZhxmjg 审核折扣套餐组合项目价格]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function shZhxmjg()
    {


        if(request()->isAjax()) { //ajax 提交

            try {

                $zhxmdata = input('param.zhxmdata/a');
                $dwid = input('param.dwid');
                $fz_tc_id = input('param.fz_tc_id');

                $sumzhxm = array_sum(array_map(create_function('$val', 'return $val["jg"];'), $zhxmdata));

                if (empty($dwid)) {
                    //审核个人套餐
                    $tczhkjg = Model('TjtcModel')->where(['hospitalid' => session('hospitalid'), 'id' => $fz_tc_id, 'status' => 1])->value('zkhjg');

                    if ($tczhkjg != $sumzhxm)
                        return json(['code' => 0, 'data' => '', 'msg' => '个人套餐折扣价与项目总价不符，不能保存']);

                  //  $flag = Model('TjtcDtModel')->zhxmjgEdit($fz_tc_id, $zhxmdata);
                    Model('TjtcModel')->where(['hospitalid'=>session('hospitalid'),'id'=> $fz_tc_id])->setField('sfsh', 1);
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】审核个人折扣套餐成功(ID=' .  $fz_tc_id . ')', 1);


                } else {
                    //审核分组套餐
                    $fzzhkjg = Model('DwfzModel')->where(['hospitalid' => session('hospitalid'), 'dwid' => $dwid, 'id' => $fz_tc_id, 'status' => 1])->value('zkhjg');

                    if ($fzzhkjg != $sumzhxm)
                        return json(['code' => 0, 'data' => '', 'msg' => '分组套餐折扣价与项目总价不符，不能保存']);

                    //$flag = Model('DwfzDtModel')->zhxmjgEdit($dwid,$fz_tc_id,$zhxmdata);
                    Model('DwfzModel')->where(['hospitalid'=>session('hospitalid'),'dwid'=>$dwid,'id'=> $fz_tc_id])->setField('sfsh', 1);
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】审核分组折扣套餐成功(单位ID='.$dwid.',ID=' . $fz_tc_id  . ')', 1);

                }


                return json(['code' => 1, 'data' => '', 'msg' =>'审核折扣套餐价格成功']);

            }catch (PDOException $e){

                return json(['code' =>0, 'data' =>'', 'msg' => $e->getMessage()]);

            }



        }


    }

    //获取待审核个人折扣套餐 giveTjtc
    public function giveTjtc($key)
    {
        if (request()->isAjax()) {

            $where['status'] =['=', 1];
            $where['tc.hospitalid'] =['=', session('hospitalid')];
            $where['sfsh']=['=',0];
            $where['zk']=['exp','is not null'];
            $where['zkhjg']=['exp','is not null'];

            if (!empty($key))
                $where['mc|pyjm|wbjm'] = ['like', '%' . $key . '%'];




            $result = Model('tjtcModel')->alias('tc')
                      ->join('tjtc_dt dt','tc.id=dt.tcid and tc.hospitalid=dt.hospitalid','left')
                      ->field('id,mc,zkhjg,sum(dt.jg) as zhxmjg,softid')
                      ->where($where)
                      ->group('id,mc,zkhjg,softid')
                      ->order('softid')
                      ->select();

            $str = '[{"id":"0","name":"个人体检套餐", "open":"true","childOuter":"false","isParent":"true", "children":[';

            if ($result) {
                foreach ($result as $key => $vo) {


                    if ($vo['zkhjg']==$vo['zhxmjg'])
                        $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '","iconSkin":"okzk","title":"套餐价格:'.$vo['zkhjg'].'可审核"},';
                    else
                        $str .= '{ "id": "' . $vo['id'] . '", "pid":"0", "name":"' . $vo['mc'] . '","iconSkin":"nozk","title":"套餐价格:'.$vo['zkhjg'].'不可审核"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';

            $escapers = array("\\");
            $replacements = array("\\\\");
            $str = str_replace($escapers, $replacements,$str);
            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }




    //获取待审核折扣分组套餐
    public function giveDwfz($key)
    {
        $map=['isdel' => 1, 'pid' => 0, 'hospitalid' => session('hospitalid')];
        $map['status']=['=',1];

        $tjdw = Model('TjdwModel')->where($map)->field('id,pid,dwname,status,softid')->order('softid')->select();

        $where['tc.hospitalid'] = session('hospitalid');
        $where['status']=['=',1];
        $where['sfsh']=['=',0];
        $where['zk']=['exp','is not null'];
        $where['zkhjg']=['exp','is not null'];

        if (!empty($key))
            $where['mc|pyjm|wbjm'] = ['like', '%' . $key . '%'];


        $allfz = Model('DwfzModel')->alias('tc')
            ->join('dwfz_tc dt','tc.id=dt.fzid and tc.hospitalid=dt.hospitalid and tc.dwid=dt.dwid','left')
            ->field('id,tc.dwid,mc,zkhjg,sum(dt.jg) as zhxmjg,softid')
            ->where($where)
            ->group('id,tc.dwid,zkhjg,mc,softid')
            ->order('softid')
            ->select();

        $str = '[{"id":"0","name":"单位分组套餐", "open":"true","isParent":"true","childOuter":"false","children":[';

        if ($tjdw) {
            foreach ($tjdw as $key => $vo) {


                $str .= '{ "id": "' . $vo['id'] . '", "pId":"0","isParent":"true","open":"true", "name":"' . $vo['dwname'] . '","childOuter":"false","children":[';

                $dwfz= arrWhereAnd($allfz, ['dwid' => $vo['id']]);
                if ($dwfz) {
                    foreach ($dwfz as $k => $v) {


                        if ($v['zkhjg']==$v['zhxmjg'])
                               $str .= '{ "id": "' . $v['id'] . '", "pId":"' . $vo['id'] . '", "name":"' . $v['mc'] . '","iconSkin":"okzk","title":"套餐价格:'.$v['zkhjg'].'可审核"},';
                        else
                               $str .= '{ "id": "' . $v['id'] . '", "pId":"' . $vo['id'] . '", "name":"' . $v['mc'] . '","iconSkin":"nozk","title":"套餐价格:'.$v['zkhjg'].'不可审核"},';


                    }
                    $str = substr($str, 0, -1);
                }
                $str .= ']},';

            }
            $str = substr($str, 0, -1);

        }
        $str .=']}]';
        $escapers = array("\\");
        $replacements = array("\\\\");
        $str = str_replace($escapers, $replacements,$str);
        return json(['code'=>1,'data'=>$str,"msg"=>"OK"]);

    }




}