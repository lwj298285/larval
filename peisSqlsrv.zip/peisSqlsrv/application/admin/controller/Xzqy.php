<?php

namespace app\admin\controller;

use app\admin\model\XzqyModel;
use app\admin\model\SelectdicModel;
use think\Db;
use think\Config;
use think\exception\PDOException;

class Xzqy extends Base
{
	/**
	 * [index 行政区域]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	
	
	public function index(){

		
		return $this->fetch();
		
	}





    /**
	 * [ xzqyEdit 添加删除行政区域]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function xzqyEdit()
	{
		$xzqy = new XzqyModel();
		
		if(request()->isAjax()) { //ajax 提交
			
			if (request()->isPost()) { // 判断提交方式 post为 更新和新增
				
				$param = input('post.');
				$flag = $xzqy->editXzqy($param);
				return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
			}
		}
		
		
	}


	/**
	 * [xzqyDel 删除行政区域]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function xzqyDel()
	{
		if(request()->isAjax()) {
			$ids = input('param.ids');
			$name = input('param.name');
			$xzqy = new XzqyModel();
			$flag = $xzqy->delXzqy($ids,$name);
			return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
		}
	}
	
	
	
	public function giveXzqy($search)
    {
        if (request()->isAjax()) {
            $map['isdel'] = 1;

            if (!empty($search))
                $map['name'] = ['like', '%' . $search . '%'];

            $result = Db::name('region')->where($map)->field('id,pid,type,name')->order('id')->select();

            $str = '{"id":"0","name":"行政区域列表", "isParent":"true","open":"true","childOuter":"false"},';
            //$str = "";
            if ($result) {
                foreach ($result as $key => $vo) {
                    if ($vo['type']!=3)
                        $str .= '{ "id": "' . $vo['id'] . '", "pId":"' . $vo['pid'] . '", "name":"' . $vo['name'] . '","isParent":"true"},';
                    else
                        $str .= '{ "id": "' . $vo['id'] . '", "pId":"' . $vo['pid'] . '", "name":"' . $vo['name'] . '"},';

                }
            }

            return json(['code' => 1, 'data' => "[" . substr($str, 0, -1) . "]", "msg" => "OK"]);
        }
    }


    //联动获取区域  省-》市-》区

    public function getRegion ($type,$pid)
    {

        if (request()->isAjax()) {

            try {
                $result = Model('XzqyModel')->getArea($type, $pid);

                return json(['code' => 1, 'data' =>$result , "msg" => "OK"]);
            }catch(PDOException $e){

                return json(['code' => 0, 'data' =>'' , "msg" =>$e->getMessage()]);
            }
        }
    }


	
}