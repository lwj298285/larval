<?php

namespace app\admin\controller;
use think\Db;
use think\exception\ErrorException;
use com\Datainterface;
use \Imagick;
class Zcjm extends Base
{
	/**
	 * [index 字符串加密]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */



	public function index(){



        /* $df=new Datainterface('http://192.168.0.100:8010/iexchange/interfacemanager/publicexecutor/33783DE1-040A-4B42-8C97-A6FD5CE8A4F8/test_mul_base64');

      $result=$df->http_post_json('{"params":{"id":2}}');


      $data_xml_str=$result->result;

         if(is_file(  $data_xml_str)){ //传的是文件，还是xml的string的判断
             $xml_array=simplexml_load_file(  $data_xml_str);
         }else{
             $xml_array=simplexml_load_string( $data_xml_str);
         }



         $data_json = json_encode($xml_array);   //php5，以及以上，如果是更早版本，请查看JSON.php


      var_dump( $data_json);

         exit();
         .var_dump( json_decode($data_json)->row->medical_num);

         exit();

        foreach( json_decode($data_json)->row as $item){


           //Datainterface::base64tojpg($item->ReportImage,INTERFACE_PATH.session('hospitalid').'/0001/');


            //$img_array=explode('@',$item->medical_num);

            var_dump($item);


            exit();


            //$result=Datainterface::base64tojpg($item->medical_num,INTERFACE_PATH.session('hospitalid').'/0001/');


          //  $result=Datainterface::base64tojpg($item->ReportImage,INTERFACE_PATH.session('hospitalid').'/0001/');

            echo $result['file']."<br>";

         }

        $img_array=explode('@',json_decode($data_json)->row->medical_num);





        foreach($img_array as $key=>$value){



            $result=Datainterface::base64tojpg($value,INTERFACE_PATH.session('hospitalid').'/0001/');


        }   */









        return $this->fetch();



		
	}
	
	
  public function jmStr($str){

      if ($this->request->isAjax()){
         try {
             $jmstr = encrypt($str, 'E');
             return json(['code'=>1, 'data' => $jmstr, 'msg' => '']);
         }catch (ErrorException $e){
             return json(['code'=>0, 'data' => '', 'msg' => '加密字符串失败']);

         }


      }


  }
	
	
}