<?php

namespace app\admin\controller;
use app\admin\model\DepartmentModel;
use think\Db;
use think\Config;
use think\exception\ErrorException;
use think\exception\PDOException;

class Department extends Base
{

    /**
     * [index 科室设置]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */





    public function index()
    {

       // $key = input('key');
      //  $map['isdel'] = ['=', 1];
       /* if ($key && $key !== "") {
            $map['depname'] = ['like', "%" . $key . "%"];
        }*/
      //  $Nowpage = input('get.page') ? input('get.page') : 1;
     //   $limits = 10;// 获取总条数
      //  $count = Db::name('department')->where($map)->count();//计算总页面
       // $allpage = intval(ceil($count / $limits));

        //$this->assign('Nowpage', $Nowpage); //当前页
       // $this->assign('allpage', $allpage); //总页数
       // $this->assign('val', $key);

        /*if (input('get.page')) {
            return json($lists);
        }*/

       // $this->assign('lists', json($lists));
        return $this->fetch();


    }


    /**
     * [deparmentAdd 添加科室]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function departmentAdd()
    {
        if (request()->isAjax()) {
            $param = input('post.');
            $department = new DepartmentModel();
            $flag = $department->insertDepartment($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }

        //$data=get_json_emlement('dictionary.json',0,'department');
        //$this->assign('deptype', $data[0]['deptype']);
        //$this->assign('showranger', $data[1]['showranger']);
        //$this->assign('showtable', $data[2]['showtable']);
        //$this->assign('nodulemodel', $data[3]['nodulemodel']);
        return $this->fetch();
    }


    /**
     * [hospitalEdit 编辑科室]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function departmentEdit()
    {
        $department = new DepartmentModel();

        if (request()->isAjax()) {

            $param = input('post.');

            $flag = $department->editDepartment($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }

        $id = input('param.id');
        $this->assign([
            'department' => $department->getOneDepartment($id)

        ]);

        //$data=get_json_emlement('dictionary.json',0,'department');
        //$this->assign('deptype', $data[0]['deptype']);
        //$this->assign('showranger', $data[1]['showranger']);
        //$this->assign('showtable', $data[2]['showtable']);
        //$this->assign('nodulemodel', $data[3]['nodulemodel']);
        return $this->fetch();
    }


    /**
     * [hospitalDel 删除医院]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function departmentDel()
    {
        if(request()->isAjax()) {
            $id = input('param.id');
            $department = new DepartmentModel();
            $flag = $department->delDepartment($id);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    /**
     * [hospital_state 科室状态]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function department_state()
    {

        if(request()->isAjax()) {
            $id = input('param.id');
            $status = Db::name('department')->where(array('id' => $id))->value('status');//判断当前状态情况

            if ($status == 1) {
                $flag = Db::name('department')->where(array('id' => $id))->setField(['status' => 0]);
                return json(['code' => 1, 'data' => $flag['data'], 'msg' => '已禁止']);
            } else {
                $flag = Db::name('department')->where(array('id' => $id))->setField(['status' => 1]);
                return json(['code' => 0, 'data' => $flag['data'], 'msg' => '已开启']);
            }
        }

    }




    public function getAllTjlx(){


            try {
                $department = new DepartmentModel();
                $lists = $department->where('isdel', 1)->order('sortid asc')->select();
                return $lists;

            } catch (ErrorException $e) {
                return [];

            }

    }

    /**
     * [hospital_state 科室状态]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function giveTjlx()
    {

        if(request()->isAjax()) {
            //获取所有体检类型
            $result = Model('DepartmentModel')->getDepartments();

            $str = '[{"id":"0","name":"体检类型", "open":"true","childOuter":"false","isParent":"true","children":[';

            if ($result) {

                foreach ($result as $key => $vo) {
                    //添加体检类型
                    $str .= '{ "id": "' . $vo['depid'] . '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","isParent":"true","pid":"0","iconSkin":"close"},';

                }
                $str = substr($str, 0, -1);
            }

            //根节点结束
            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }


    }
}