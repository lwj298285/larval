<?php

namespace app\admin\controller;
use app\admin\model\YsztModel;
use org\image\driver\Imagick;
use think\console\command\make\Model;
use think\Db;
use think\exception\PDOException;
use com\Datainterface;
use org\upload;
use app\admin\model\TjjlbModel;
class Yszt extends Base

{
    /**
     * [index 医生诊台]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index(){



        //取当前科室权限变量，先赋值变量，再根据权限判断是否具有权限
        $ysqx=Model('YsqxModel')->where('jobnum',session('jobnum'))->field('tjlxid,depauth')->select();
        $xtcs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>['in','sgid,tzid,bmiid,xyid,ssyid,szyid,slzid,slyid']])->select();


        $sgid=array_column(arrWhereAnd($xtcs, ['mc' => 'sgid']),'value');
        $tzid=array_column(arrWhereAnd($xtcs, ['mc' => 'tzid']),'value');
        $xyid=array_column(arrWhereAnd($xtcs, ['mc' => 'xyid']),'value');
        $ssyid=array_column(arrWhereAnd($xtcs, ['mc' => 'ssyid']),'value');
        $szyid=array_column(arrWhereAnd($xtcs, ['mc' => 'szyid']),'value');
        $bmiid=array_column(arrWhereAnd($xtcs, ['mc' => 'bmiid']),'value');
        $slzid=array_column(arrWhereAnd($xtcs, ['mc' => 'slzid']),'value');
        $slyid=array_column(arrWhereAnd($xtcs, ['mc' => 'slyid']),'value');


        $this->assign('sgid',empty($sgid)?"":$sgid[0]);  //身高
        $this->assign('tzid', empty($tzid)?"":$tzid[0]);  //体重
        $this->assign('xyid',empty($xyid)?"":$xyid[0]);  //血压
        $this->assign('ssyid', empty($ssyid)?"":$ssyid[0]);    //收缩压
        $this->assign('szyid', empty($szyid)?"":$szyid[0]);    //舒张压
        $this->assign('bmiid', empty($bmiid)?"":$bmiid[0]);    //舒张压
        $this->assign('slzid', empty($slzid)?"":$slzid[0]);    //舒张压
        $this->assign('slyid', empty($slyid)?"":$slyid[0]);    //舒张压
        $this->assign('ysqx',$ysqx);
        $this->assign('admins',Model('UserModel')->where(['isdel&status'=>1,'hospitalid'=>session('hospitalid')])->select());
        $this->assign('xzjcys',Model('YycsModel')->where(['isdel'=> 1,'hospitalid'=>session('hospitalid'),'mc'=>'sfyxxzjcys'])->value('value'));

        return $this->fetch();


    }



    //获取组合项目诊断列表

    public function getZyzd($xh,$zhxmid){
        if(request()->isAjax()){

            $result=Model('TjzdbModel')->alias('zd')->join('Xjjy jy','zd.zdid=jy.id')
                    ->field('zd.*,jy.zyzd')
                    ->where(['xh'=>$xh,'zhxmid'=>$zhxmid,'hospitalid'=>session('hospitalid')])
                    ->select();
            if($result===false)
                return [];
            else
                return $result;
        }
    }


//获取登记人员组合项目

    public function getZhxm($tjbh,$tjcs){
        if(request()->isAjax()){


            //获取登记非弃检和退费项目
            $result=Model('TjjlbModel')->alias('jl')
                ->join('zhxm_hd hd','jl.zhxmid=hd.id')
               ->join('department_auth au','hd.tjlxid=au.tjlxid and au.jobnum=\''.session("jobnum").'\'')
                ->join('department dp','au.tjlxid=dp.id')
                ->field('jl.*,hd.mc,hd.tjlxid,dp.showydd,nodulemodel,importmodel,hd.id,hd.zcxj')
                ->where(['tjbh'=>$tjbh,'tjcs'=>$tjcs,'jsover'=>['not in','0,16']])
                ->order('tjlxid,zhxmid')
                ->select();


            if($result===false)
                return json(['code'=>0,'data'=>'',"msg"=>"获取体检组合项目失败"]);
            else
                return json(['code'=>1,'data'=> $result,"msg"=>"OK"]);
        }
    }


    //获取小项历年检查结果
    public function getLndb($tjbh,$xmid){
        if(request()->isAjax()){
            $result=Model('TjjlbModel')->alias('lb')
                 ->join('tjjlmxb lm','lm.xh=lb.xh and lb.hospitalid=lm.hospitalid and lb.zhxmid=lm.zhxmid and lm.xmid='.$xmid )
                 ->join('tjxm xm','lm.xmid=xm.id')
                 ->field('lb.tjcs,lm.jg,jcrq,jcys,xm.mc')
                 ->where(['lb.tjbh'=>$tjbh,'lb.jsover'=>20,'lb.hospitalid'=>session('hospitalid')])
                 ->order('tjcs desc')
                 ->select();


            if($result===false)
                return json(['code'=>0,'data'=>'',"msg"=>"获取项目历年对比失败"]);
            else
                return json(['code'=>1,'data'=> $result,"msg"=>"OK"]);


        }


    }



    //获取体检人员历年检查所有结果
    public function getAllLndb($tjbh){
        if(request()->isAjax()){
            $result=Model('TjjlbModel')->alias('lb')
                ->join('tjjlmxb lm','lm.xh=lb.xh and lb.hospitalid=lm.hospitalid and lb.zhxmid=lm.zhxmid ' )
                ->join('tjxm xm','lm.xmid=xm.id')
                ->join('department dep','xm.tjlxid=dep.id')
                ->field('dep.id depid,dep.depname,lb.tjcs,lm.jg,jcrq,jcys,xm.mc')
                ->where(['lb.tjbh'=>$tjbh,'lb.jsover'=>20,'lb.hospitalid'=>session('hospitalid')])
                ->order('jcrq,tjcs desc')
                ->select();


            if($result===false)
                return json(['code'=>0,'data'=>'',"msg"=>"获取项目历年对比失败"]);
            else
                return json(['code'=>1,'data'=> $result,"msg"=>"OK"]);


        }


    }






//获取登记体检科室PACS图片
    public function getImageView($djlsh, $billno='')
    {

        $imagepath=INTERFACE_PATH . session('hospitalid') . '/' .$djlsh .'/';
        $flag = Datainterface::find_dir_jpg($imagepath,$billno);

        return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);

    }




    //获取个人 体检报告pacs 影像 并更新小结 和 结果
    public function getPacs($djlsh=''){

        //读取pacs图片文件

        if(request()->isAjax()) {

            Db::startTrans();

            try {


                $where [' PS.hospitalid'] = session('hospitalid');
                $where ['flag'] = 0;
                $where ['deletedate'] = ['EXP', 'IS NULL'];
                $where ['reportimage'] = ['EXP', 'IS NOT NULL'];


                if ($djlsh != '')
                    $where ['djlsh'] = $djlsh;


                $pascimgs = Db::name('pacssenddata')->alias('PS')->distinct(true)
                    ->join('tjjlb LB', 'PS.hospitalid=LB.hospitalid and PS.pid=LB.billno')
                    ->join('tjdjb DJ', 'LB.tjbh=DJ.tjbh AND LB.tjcs=DJ.tjcs AND LB.hospitalid=DJ.hospitalid')
                    ->field('DJ.djlsh,lb.xh,LB.billno,cast(reportimage as varchar(max)) as reportimage ,reporttype,studypositionname,tishi_sum')
                    ->where($where)
                    ->order('billno', 'asc')
                    ->select();

                //  ->chunk(50, function ($pascimgs) {

                //缓存条码数据

                //  $data=array(array('billno'=>'20','djlsh'=>'02001'),array('billno'=>'20','djlsh'=>'02001'));

                cache('billno', array_unique(array_column($pascimgs, 'billno')));


                foreach ($pascimgs as $img) {


                    $result = Datainterface::base64tojpg($img['reportimage'], INTERFACE_PATH . session('hospitalid') . '/' . $img['djlsh'] . '/', $img['billno']);

                    if ($result['code'] == 1) {//转换文件成功
                        //回置pacs数据表为已读成功状态
                        $wherepacs = [];


                        if (!empty($img['studypositionname']))
                            $wherepacs['studypositionname'] = $img['studypositionname'];


                        /*$pacsResult = Db::name('pacssenddata')->where()->where(['pid' => $img['billno'], 'hospitalid' => session('hospitalid')])->setField('flag', 1);
                        $tjlbResult = Db::name('tjjlb')->where(['billno' => $img['billno'], 'hospitalid' => session('hospitalid')])->update(['xj'=>$img['tishi_sum'],'jsover'=>15]);
                        $zhxmid_array=Db::name('tjjlb')->where(['billno' => $img['billno'], 'hospitalid' => session('hospitalid')])->column('zhxmid');
                        $tjmxResult = Db::name('tjjlmxb')->where(['xh'=>$img['xh'],'zhxmid' => ['in',$zhxmid_array], 'hospitalid' => session('hospitalid')])->setField('jg', '结果以影像报告为准');*/

                        Db::name('pacssenddata')
                            ->where(['pid' => $img['billno'], 'hospitalid' => session('hospitalid')])
                            ->where($wherepacs)
                            ->setField('flag', 1);


                        if (!empty($img['studypositionname'])) {
                            $tjjlb = new TjjlbModel();
                            $zhxmid = Db::name('tjjlb')->alias('jl')
                                ->join("zhxm_hd hd", "jl.zhxmid=hd.id AND hd.mc='" . $img['studypositionname'] . "'")
                                ->where(['billno' => $img['billno'], 'hospitalid' => session('hospitalid')])
                                ->value('zhxmid');

                            $tjjlb->Save(['xj' => $img['tishi_sum'], 'jsover' => 15], ['xh' => $img['xh'], 'hospitalid' => session('hospitalid'), 'zhxmid' => $zhxmid]);


                        } else {

                            Db::name('tjjlb')->where(['billno' => $img['billno'], 'hospitalid' => session('hospitalid')])->update(['xj' => $img['tishi_sum'], 'jsover' => 15]);


                            /*$zhxmid_array= model('TjjlbModel')->where(['billno' => $img['billno'], 'hospitalid' => session('hospitalid')])->column('zhxmid');
                            self::where(['xh'=>$img['xh'],'zhxmid' => ['in',$zhxmid_array], 'hospitalid' => session('hospitalid')])
                                ->setField('jg', '结果以影像报告为准');*/

                        }


                    } else IF ($result['code'] == -1) {     //转换失败 结束操作

                        throw new \Exception($result['msg']);

                    }


                }


                //   },'billno', 'asc');
                Db::commit();

                cache('billno', NULL);

                return json(['code' => 1, 'data' => '', 'msg' => '读取PACS图像成功']);

            } catch (\Exception $e) {

                Db::rollback();

                foreach (cache('billno') as $index => $item) {
                    Datainterface::delete_file(INTERFACE_PATH . session('hospitalid') . '/' . $djlsh . '/', $item . '@');
                }

                cache('billno', NULL);
                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

            }

        }

    }






    //上传pcas 单机手传文件
    public function uploadPacsImage(){

        //读取pacs图片文件

        if(request()->isAjax()) {

            try {

                $djlsh = input('param.djlsh');
                $billno = input('param.billno');
                $file = request()->file('pacsfile');

                if ($file) {


                    $savepath = INTERFACE_PATH . session('hospitalid') . '/' . $djlsh . '/';


                    $filemime = $file->getMime();

                    Datainterface::delete_file($savepath, $billno);

                    if ($filemime == 'image/jpeg') {
                        $file->move($savepath, $billno . '@' . microtime() . '.jpg');

                    } else {

                        $filexten = "";
                        switch ($filemime) {

                            case 'image/png' :
                                $filexten = '.png';
                                // $file->move($savepath,$billno . '.png');
                                break;
                            case 'application/pdf':
                                $filexten = '.pdf';
                                // $file->move($savepath,$billno .'.pdf');
                                break;

                            case 'image/x-png' :
                                $filexten = '.png';
                                // $file->move($savepath,$billno .'.png');
                                break;

                            case 'image/gif':
                                $filexten = '.gif';
                                // $file->move($savepath,$billno  .'.gif');
                                break;

                            default:
                                $filexten = '.jpg';
                                break;

                        }


                        $file->move($savepath, $billno . $filexten);
                        Datainterface::filetojpg($savepath . $billno . $filexten, $savepath, $billno);
                        unlink($savepath . $billno . $filexten);

                    }


                } else {

                    throw new \Exception('未获取文件');

                }


                $flag = Datainterface::find_dir_jpg($savepath,$billno);


                return json(['code' => 1, 'data' => $flag['data'], 'msg' => '上传图像成功']);

            }catch (\Exception $e){

                return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);

            }


        }

    }


//获取登记人员组合项目(小项录入)
    public function getZhxmItem($zhxmid,$xh){

        if(request()->isAjax()){

            /*$result=Model('ZhxmDtModel')->alias('dt')->join('tjxm xm','dt.tjxmid=xm.id')
                ->join('tjjlmxb mxb','dt.tjxmid=mxb.xmid and mxb.xh='.$xh. 'and hospitalid='.session('hospitalid').' and mxb.zhxmid='.$zhxmid ,'left')
                ->field('mxb.jg,CASE WHEN mxb.sfyx IS NULL THEN 0 ELSE mxb.sfyx END AS sfyx,'.$xh.' xh,'.$zhxmid.' zhxmid,'.session('hospitalid').'  hospitalid,xm.zcts,xm.mc,xm.id xmid,xm.jglx,xm.dw,cksx,ckxx,pgts,pdts,memockz,
                CASE WHEN mxb.jrxj IS NULL THEN xm.jrxj else mxb.jrxj END AS jrxj,softid')
                ->where(['dt.zhxmid'=>$zhxmid,'xm.isdel&xm.status'=>1])
                ->order('softid')
                ->select();*/




            /*if (!empty($djlsh))
                Model('ysztModel')->getPacs($djlsh);*/



            $result=Model('YsztModel')->alias('zt')->join('tjxm xm','zt.xmid=xm.id')
                ->field('zt.jg,CASE WHEN zt.sfyx IS NULL THEN 0 ELSE zt.sfyx END AS sfyx,'.$xh.' xh,'.$zhxmid.' zhxmid,'.session('hospitalid').'  hospitalid,xm.zcts,xm.mc,xm.id xmid,xm.jglx,zt.dw,minckz,maxckz,pgts,pdts,ycts,zt.memockz,
                CASE WHEN zt.jrxj IS NULL THEN 0 else zt.jrxj END AS jrxj,softid')
                ->where(['zt.zhxmid'=>$zhxmid,'zt.xh'=>$xh,'hospitalid'=>session('hospitalid'),'xm.isdel&xm.status'=>1])
                ->order('softid')
                ->select();


            if($result===false)
                return json(['code'=>0,'data'=>'',"msg"=>"获取组合项目失败"]);
            else
                return json(['code'=>1,'data'=> $result,"msg"=>"OK"]);


        }


    }


    //根据jdbz标志判断医生诊台信息是否有编辑权限
    public function getJdbz($tjbh,$tjcs){
        if(request()->isAjax()){
           $jdbz=Model('TjdjModel')->where(['hospitalid'=>session('hospitalid'),'tjbh'=>$tjbh,'tjcs'=>$tjcs])->value('jdbz');

               if (intval($jdbz)>30)
                   return json(['code'=>0,'data'=>'','msg'=>'总检状态不可编辑！']);
               else
                   return json(['code'=>1,'data'=>'','msg'=>'ok']);
        }

    }

    /**
     * [xjjyEdit 添加修改体检项目结果建议]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xjjyEdit()
    {
        $xjjy = new XjjyModel();

        if(request()->isAjax()){ //ajax 提交

            $param=input('data/a');
            unset($param['ROW_NUMBER']);
            unset($param['index']);

            $flag =  $xjjy->editXjjy($param);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'id'=> $flag['id'],'msg' => $flag['msg']]);

        }

    }

    /**
     * [qjZhxm 组合项目弃检]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function qjZhxm($tjbh,$tjcs,$xh,$zhxmid)
    {
        if(request()->isAjax()) {
            try {

                $jdbz=20;
                $flagdellb = Model('TjjlbModel')->where(['hospitalid' => session('hospitalid'), 'xh' => $xh,'zhxmid'=>$zhxmid])->setfield('jsover', 0);
                $flagdelzd = Model('TjzdbModel')->where(['hospitalid' => session('hospitalid'), 'xh' => $xh,'zhxmid'=>$zhxmid])->delete();

                if ( $flagdellb===false || $flagdelzd===false ){

                    return json(['code' => 0, 'data' =>'', 'msg' => '弃检失败']);
               }else {
                    $nqjcount=Model('TjjlbModel')->where(['hospitalid' => session('hospitalid'), 'xh' => $xh,'jsover'=>10])->count();
                    //计算登记人员组合项目有没有不是弃检的 如果没有，登记表进度设置为
                    if ( $nqjcount<1) {
                        //弃检组合项目  如果不存在其他都有检查 那么将进度标志设置为待总检，并且将体检结束日期设置为当前日期
                        Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $tjbh, 'tjcs' => $tjcs])->setfield(['jdbz'=>30,'tjendrq'=>Date("Y-m-d")]);
                        $jdbz=30;
                    }

                    return json(['code' => 1, 'data' => $jdbz, 'msg' => '弃检成功']);
                }

            }catch (PDOException $e){

                return json(['code' => 0, 'data' =>'', 'msg' => $e->getMessage()]);

            }


        }
    }

    /**
     * [jgDel 删除体检结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jgDel()
    {
        if(request()->isAjax()) {
            $yszt= new YsztModel();
            $tjinfo=input('param.tjinfo/a');
            $flag =  $yszt->delJg($tjinfo);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [jgEdit() 添加 修改体检结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function jgEdit(){
        if(request()->isAjax()){
            $yszt= new YsztModel();
            $zhxmitem=input('param.zhxmitem/a','',null);
            $tjxmitem=input('param.tjxmitem/a','',null);
            $zditem=input('param.zditem/a','',null);
            $flag =$yszt->editJg($tjxmitem,$zhxmitem,$zditem);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    /**
     * [ xmXj() 添加 修改体检结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function xmXj(){
        if(request()->isAjax()){
            $yszt= new YsztModel();
            $zhxmitem=input('param.zhxmitem/a','',null);
            $tjxmitem=input('param.tjxmitem/a','',null);
            $zditem=input('param.zditem/a','',null);
            $flag =$yszt->editJg($tjxmitem,$zhxmitem,$zditem);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

//根据 体检类型和临床类型获取 小结建议
    public function getJjlxXjjy()
    {
        if(request()->isAjax()) {
            $tjlxid = input('param.tjlxid');
            $lclxid = input('param.lclxid');

            $map=[ ];
            if (!empty($lclxid))
                $map=['lclxid'=>$lclxid];

            try{

                $xjjy =Model('XjjyModel')->where(['isdel'=>1,'tjlxid'=>$tjlxid])->where($map)->select();
                return json(['code'=>1,'data'=>$xjjy,'msg' => '']);

            }catch (PDOException $e){

                return json(['code'=>0,'data'=>'','msg' => $e->getMessage()]);
            }


        }

    }

    //根据科室下的医生权限设置
    public function getQx($tjlxid,$jobnum){
        $result=Model('YsqxModel')
            ->where(['tjlxid'=>$tjlxid,'jobnum'=>$jobnum])
            ->value('depauth');

        if($result!="" && !is_null($result))
            return json(['code'=>1,'data'=>$result,"msg"=>"OK"]);
        else
            return json(['code'=>0,'data'=>'',"msg"=>"无此科室权限！"]);

    }


}