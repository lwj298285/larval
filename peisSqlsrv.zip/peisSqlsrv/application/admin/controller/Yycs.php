<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 13:52
 */
namespace app\admin\controller;
use think\console\command\make\Model;

class Yycs extends Base
{
    /**
     * [index 医院参数]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function index(){

        return $this->fetch();
    }

    //添加及更新医院参数
    public function editYycs(){
        if(request()->isAjax()){
            if(request()->isPost()){
                $param=input('post.');
                $flag=Model('YycsModel')->yycsEdit($param);
                return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
            }else{
                $id=input('param.id');
                $flag=Model('YycsModel')->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->find();
                if($flag==false)
                    return json(['code'=>0,'data'=>'','msg'=>'获取数据失败' ]);
                else
                    return json(['code'=>1,'data'=>$flag,'msg'=>'ok']);
            }
        }
    }


    //获取医院参数信息
    public function giveYycs(){
        if(request()->isAjax()){
            $result=Model('YycsModel')->where(['isdel'=>1,'hospitalid'=>session('hospitalid')])->field('mc,zwmc,value,comment,id,softid')->order('softid')->select();
            $str='[{"id":0,"name":"医院参数","open":"true","childOuter":"true","isParent":"true","children":[';
            if($result){
                foreach($result as $k=>$v){
                    $str.='{"id":"'.$v['id'].'","name":"'.$v['zwmc'].'","pId":"0"},';
                }
                $str=substr($str,0,-1);
            }
            $str.=']}]';
            return json(['code'=>1,'data'=>$str,'msg'=>'OK']);
        }
    }

    //删除医院参数
    public function  yycsDel(){
        if(request()->isAjax()){
            $id=input('param.id');
            $flag=Model('YycsModel')->delYycs($id);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }
    }
    //排序
    public function softEdit(){
        $id=input('post.id');
        $targetid=input('post.targetid');
        $type=input('post.type');
        $flag=Model('YycsModel')->editSoft($id,$targetid,$type);
        return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
    }
}