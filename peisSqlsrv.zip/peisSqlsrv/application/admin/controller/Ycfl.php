<?php

namespace app\admin\controller;
use app\admin\model\YcflModel;
use app\admin\model\YcflModelDt;
use think\console\command\make\Model;
use think\Db;
use think\exception\PDOException;


class Ycfl extends Base
{


    /**
     * [index 异常分类]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function getOneYcfl()
    {
        $ycfl = new YcflModel();
        $jbmbid = input('param.jbmbid');
        $ycflid = input('param.ycflid');
        return  json($ycfl->getOneYcfl($jbmbid,$ycflid));
    }


    /**
     * [YcflEdit 编辑异常分类信息]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function YcflEdit()
    {
        $ycfl = new YcflModel();

        if(request()->isAjax()){ //ajax 提交

            if(request()->isPost()) { // 判断提交方式 post为 更新和新增

                $param = input('post.');
                $flag = $ycfl->editYcfl($param);
                return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);

            }else{//get 为获取数据


                $jbmbid = input('param.jbmbid');
                $ycflid = input('param.ycflid');
                return  json($ycfl->getOneYcfl($jbmbid,$ycflid));
               // dump(json([ $lclx->getOneLclx($id)]));
                //$this->ajaxReturn($lclx->getOneLclx($id),'JSON');
            }
        }


    }


    /**
     * [ YcflDel 删除异常分类信息]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function ycflDel()
    {
        if(request()->isAjax()) {
            $jbmbid = input('param.jbmbid');
            $ycflid = input('param.ycflid');
            $name = input('param.name');
            $ycfl = new YcflModel();
            $flag = $ycfl->delYcfl($jbmbid,$ycflid,$name);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }

    /**
     * [ editSoft 调整街道排序]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function softEdit()
    {
        if(request()->isAjax()) {
            $jbmbid = input('param.jbmbid');
            $ycflid = input('param.ycflid');
            $type = input('param.type');
            $targetid = input('param.targetid');
            $ycfl= new YcflModel();
            $flag = $ycfl->editSoft($jbmbid,$ycflid,$type,$targetid);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    //获取异常分类json 数据
    /**
     * @param $jbmbid
     * @return \think\response\Json
     */
    public function giveYcfl($jbmbid)
    {
        if(request()->isAjax()) {
            $result = Db::name('jbmb_ycfl_hd')->where(['isdel' => 1, 'jbmbid' => $jbmbid])->field('ycflid,ycflmc,softid')->order('softid')->select();

            $str = '[{"id":"0","name":"异常分类信息", "open":"true","childOuter":"false","children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['ycflid'] . '", "pid":"0","name":"' . $vo['ycflmc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
        }


//获取异常分类项目/体检项目未选json 数据
    /**
     * @param $jbmbid
     * @param $tjlxid
     * @param $ycflid
     * @param $key
     * @return \think\response\Json
     */
    public function giveYcflNotSelTjxm($jbmbid,$tjlxid,$lclxid,$ycflid,$key)
    {

        if (request()->isAjax()) {
            $where = [];
            $where = ['tj.tjlxid' => $tjlxid, 'isdel' => 1];
            if (!empty($key))
                $where['mc|pyjm|wbjm'] = ['like', '%' . $key . '%'];
            if (!empty($lclxid))
                $where['lclxid'] = ['=', $lclxid];

            $data = model('TjxmModel')->alias('tj')->join('jbmbYcflDt ycfldt', 'tj.id=ycfldt.tjxmid and jbmbid=' . $jbmbid . ' and ycflid=' . $ycflid, 'left')
                ->field('id,tjxmid,mc,softid')
                ->where($where)
                ->order('softid')
                ->select();

            $result = arrWhereAnd($data, ['tjxmid' => null]);
            $str = '[{"id":"0","name":"可选择的体检项目", "open":"true","childOuter":"false","children":[';

            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }
//获取异常分类项目/体检项目已选json 数据
    /**
     * @param $jbmbid
     * @param $ycflid
     * @param $key
     * @return \think\response\Json
     */
    public function giveYcflSelTjxm($jbmbid,$ycflid,$key)
    {

        if(request()->isAjax()) {
            $map = [];
            if (!empty($key))
                $map['mc|pyjm|wbjm'] = ['like', '%' . $key . '%'];

            $result = Db::name('jbmb_ycfl_dt dt')->join('tjxm tj', 'dt.tjxmid=tj.id and ycflid=' . $ycflid)
                ->field('id,mc,softid')
                ->where('jbmbid', $jbmbid)
                ->where($map)
                ->order('softid')
                ->select();
            $str = '[{"id":"0","name":"已选体检项目", "open":"true","childOuter":"false","children":[';
            // $result=arrWhereAnd($data,['tjxmid'=>null]);
            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{ "id": "' . $vo['id'] . '", "pid":"0","name":"' . $vo['mc'] . '"},';

                }

                $str = substr($str, 0, -1);

            }

            $str .= ']}]';


            return json(['code' => 1, 'data' => $str, "msg" => "OK"]);
        }
    }

    //双击异常分类/体检项目（小项）
    /**
     * @return \think\response\Json
     */
    public function YcflNotTjxm()
    {
        if(request()->isAjax()) {
            $param['jbmbid'] = input('jbmbid');
            $param['ycflid'] = input('ycflid');
            $param['tjlxid'] = input('tjlxid');
            $param['tjxmid'] = input('tjxmid');
            Db::startTrans();
            try {
                $flag = Model('YcflModelDt')->save($param);

               if ($flag ==false) {

                    Db::rollback();
                    return json(['code' => 0, 'data' => '', 'msg' => '选择异常体检项目失败']);
                } else{
                    Db::commit();
                    return json(['code' => 1, 'data' => '', 'msg' => '选择异常体检项目成功']);
                }

            }catch (PDOException $e){
                Db::rollback();
                return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
            }
        }
    }


    //移除异常分类体检项目（已选）
    public function ycflTjxmDel(){
        if(request()->isAjax()){
            $jbmbid=input('param.jbmbid');
            $ycflid=input('param.ycflid');
            $tjxmid=input('param.tjxmid');
            $name=input('param.name');
            $ycfltjxm=new YcflModelDt();
            $flag=$ycfltjxm->delYcflTjxm($jbmbid,$ycflid,$tjxmid,$name);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }
    }
    //添加选择异常分类体检项目（多选）

    public function ycflMulNotTjxm(){
        if(request()->isAjax()){
           $param=input('get.ycflTjxm/a');
            Db::startTrans();
            try {
                $flag = Model('YcflModelDt')->saveAll($param, false);
                if ($flag == false) {
                Db::rollback();
                  return json(['code' => 0, 'data' => '', 'msg' => '选择异常分类体检项目失败']);
            }else{
                    Db::commit();
                return json(['code' => 1, 'data' =>'', 'msg' => '选择异常分类体检项目成功']);
            }

            }catch (PDOException $e){
                Db::rollback();
                return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
            }
        }
    }
    //移除异常分类体检项目（多选）
    /**
     * @return \think\response\Json
     */
    public function YcflMulSelTjxmDel(){
    if(request()->isAjax()){


            $jbmbid=input('jbmbid');
            $ycflid=input('ycflid');
            $tjxmids=input('tjxmids');
            $flag=Model('YcflModelDt')->delYcfMullSelTjxm($jbmbid,$ycflid,$tjxmids);

            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);

    }
    }



    //获取异常分类未选组合项目小项

    /**
     * @param $jbmbid
     * @param $tjlxid
     * @param $ycflid
     * @param $key
     * @return \think\response\Json
     */

    public function giveYcflNotZhxm($jbmbid,$tjlxid,$lclxid,$ycflid,$key){
        if(request()->isAjax()) {
            $where = [];
            $where = ['zh.tjlxid' => $tjlxid, 'isdel' => 1];
            if (!empty($key))
                $where['mc|pyjm|wbjm'] = ['like', '%' . $key . '%'];
            if (!empty($lclxid))
                $where['lclxid'] = ['=', $lclxid];

            $data = model('ZhxmModel')->alias('zh')->join('jbmb_ycfl_zhxm zhxm', 'zh.id=zhxm.zhxmid and jbmbid=' . $jbmbid . ' and ycflid=' . $ycflid, 'left')
                ->field('id,zhxmid,mc,softid')
                ->where($where)
                ->order('softid')
                ->select();
            $result = arrWhereAnd($data, ['zhxmid' => null]);
            $str = '[{"id":0,"name":"可选择的组合项目","open":"true","childOuter":"false","children":[';
            if ($result) {
                foreach ($result as $key => $vo) {
                    $str .= '{"id":"' . $vo['id'] . '","pId":"0","name":"' . $vo['mc'] . '"},';
                }
                $str = substr($str, 0, -1);
            }

            $str .= ']}]';
            return json(['code' => 1, 'data' => $str, 'msg' => 'Ok']);
        }
    }

    //双击异常分类组合项目到已选

    /**
     * @return \think\response\Json
     */

    public function YcflNotZhxm(){
        if(request()->isAjax()){
            $param['jbmbid']=input('jbmbid');
            $param['ycflid']=input('ycflid');
            $param['tjlxid']=input('tjlxid');
            $param['zhxmid']=input('zhxmid');
            Db::startTrans();
            try{
                $flag=Model('YcflZhxmModel')->save($param);
                if($flag==false){
                    Db::rollback();
                    return json(['code'=>0,'data'=>'','msg'=>'选择组合项目失败']);
                }else{
                    Db::commit();
                    return json(['code'=>1,'data'=>'','msg'=>'选择组合项目成功']);
                }

            }catch(PDOException $e){
                Db::rollback();
                return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
            }
        }

    }

    //获取异常分类组合项目（已选）

    /**
     * @param $jbmbid
     * @param $ycflid
     * @param $key
     * @return \think\response\Json
     */

    public function giveYcflSelZhxm($jbmbid,$ycflid,$key){
        if(request()->isAjax()){
            $map=[];
            if(!empty($key))
                $map['mc|pyjm|wbjm']=['like','%'.$key.'%'];

            $result=Db::name('jbmb_ycfl_zhxm zhxm')->join('zhxm_hd zh','zhxm.zhxmid=zh.id and jbmbid='.$jbmbid.'and ycflid='.$ycflid)
                ->field('id,mc,softid,zhxmid')
                ->where('jbmbid',$jbmbid)
                ->where($map)
                ->order('softid')
                ->select();
            $str='[{"id":"0","name":"已选组合项目","open":"true","childOuter":"false","children":[';
            if($result){
                foreach($result as $key=>$vo){
                    $str.='{"id":"'.$vo['id'].'","pId":"0","name":"'.$vo['mc'].'"},';
                }
                $str=substr($str,0,-1);
            }
            $str.=']}]';
            return json(['code'=>1,'data'=>$str,'msg'=>'OK']);
        }
    }

    //移除已选异常分类组合项目（已选）
    public function YcflZhxmSelDel(){
    if(request()->isAjax()){
        $jbmbid=input('param.jbmbid');
        $ycflid=input('param.ycflid');
        $zhxmid=input('param.zhxmid');
        $name=input('param.name');
        $flag=Model('YcflZhxmModel')->delYcflZhxmSel($jbmbid,$ycflid,$zhxmid,$name);
        return json(['code'=> $flag['code'],'data'=> $flag['data'],'msg'=> $flag['msg']]);
    }
    }

    //异常分类组合项目（多选）

    /**
     * @return \think\response\Json
     */

    public function YcflNotMulSelZhxms(){
        if(request()->isAjax()){
            $param=input('get.zhxmids/a');
            Db::startTrans();
              try{
                  $result=Model('YcflZhxmModel')->saveAll($param,false);
                  if($result==false){
                      Db::rollback();
                      return json(['code'=>0,'data'=>'','msg'=>'选择组合项目失败']);
                  }else{
                      Db::commit();
                      return json(['code'=>1,'data'=>'','msg'=>'选择组合项目成功']);
                  }
              } catch (PDOException $e){
                  Db::rollback();
                  return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
              }
        }
    }

    //移除异常分类组合项目（多选）
    /**
     * @return \think\response\Json
     */
    public function YcfMulSelZhxm(){
        if(request()->isAjax()){

            $jbmbid=input('jbmbid');
            $ycflid=input('ycflid');
            $zhxmids=input('zhxmids');
            $flag=Model('YcflZhxmModel')->delYcfMulSelZhxm($jbmbid,$ycflid,$zhxmids);
            return json(['code'=>$flag['code'],'data'=>$flag['data'],'msg'=>$flag['msg']]);
        }
    }

}