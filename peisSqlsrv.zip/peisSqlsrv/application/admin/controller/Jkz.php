<?php

namespace app\admin\controller;
use think\Db;
use think\exception\ErrorException;


class Jkz extends Base{


    /**
     * [index 健康证]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
 public function index(){


     $xtcs=Model('XtcsModel')->where(['isdel'=>1,'mc'=>['in','jkz,sfxhdy']])->select();

     $jkname=array_column(arrWhereAnd($xtcs, ['mc' => 'jkz']),'value');
     $sfxhdy=array_column(arrWhereAnd($xtcs, ['mc' => 'sfxhdy']),'value');

     $jkzname=empty($jkname)?"":$jkname[0];
     $this->assign('sfxhdy',empty($sfxhdy)?"": $sfxhdy[0]);


     $jkz=Model('ReportglModel')->where(['hospitalid'=>session('hospitalid'),'name'=>$jkzname,'isdel'=>1])->select();
     $fwhy=Model('FwhyModel')->where('isdel&status', 1)->select();

     $this->assign('fwhy',$fwhy);
     $this->assign('jkz',$jkz);

     $jkzdefault=collection(arrWhereAnd($jkz, ['isdefault'=>1]));

     /*   $this->assign('zjbgmbfile',empty($tjbgdegault)?"":$tjbgdegault[0]['mbfile']);
        $this->assign('zjbgmbcs',empty($tjbgdegault)?"":$tjbgdegault[0]['mbcs']);
        $this->assign('zjbgid',empty($tjbgdegault)?"":$tjbgdegault[0]['id']);*/


     $this->assign('jkzmbfile',$jkzdefault->isEmpty()?"":$jkzdefault->column('mbfile')[0]);
     $this->assign('jkzmbcs',$jkzdefault->isEmpty()?"":$jkzdefault->column('mbcs')[0]);
     $this->assign('jkzid',$jkzdefault->isEmpty()?"":$jkzdefault->column('id')[0]);

     return $this->fetch();

 }


}
