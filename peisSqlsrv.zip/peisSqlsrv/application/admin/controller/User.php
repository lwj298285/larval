<?php

namespace app\admin\controller;
use app\admin\model\UserModel;
use app\admin\model\UserHospitalModel;
use app\admin\model\UserType;
use app\admin\model\HospitalModel;
use app\admin\model\DepartmentModel;
use think\Db;
use think\Model;

class User extends Base
{

    /**
     * [index 用户列表]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function index()
    {

        $hospital = new HospitalModel();
        // $this->assign('hospitals',$hospital->field('id,hospitalname,status,isdel')->select());
        $role = new UserType();
        $this->assign('roles', $role->field('id,title,status,isdel')->select());
        $this->assign('jmdj', get_json_emlement('dictionary.json', 0, 'jmdj'));
        $dep = new DepartmentModel();
        $this->assign('department', $dep->where('isdel&status', 1)->select());


        //超级管理员读取所有医院
        $this->assign('role', $role->where(['status&isdel' => 1, 'id' => ['<>', 1]])->select());
        if (intval(session('hospitalid')) == 0) {
            $this->assign('hospitals', $hospital->field('id,hospitalname')->where('status&isdel', 1)->select());
        } else {
            //医院操作员读取本医院数据
            $this->assign('hospitals', $hospital->field('id,hospitalname')->where('id', session('hospitalid'))->select());

        }
        return $this->fetch();
    }


//获取用户 当前登录用户是属于某个医院只取出此医院人员，超级管理员取所有，也可以选择医院人员
    public function getUser()
    {

        $param = input('post.');
        $map = [];




        if (!empty($param['search']))
            $map['username|real_name|jobnum|ur.email|mobile'] = ['like', '%' . trim($param['search']) . '%'];

        //前端传参查看某个医院人员数据 或者所有人员
        if (!empty($param['hospitalid']))
            $map['hospitalid'] = ['=', $param['hospitalid']];
        else {
            //如果登录非超级管理员，只读取本医院人员
            if (intval(session('hospitalid')) > 0)
                $map['hospitalid'] = ['=', session('hospitalid')];
        }


        if (!empty($param['groupid']))
            $map['groupid'] = ['=', $param['groupid']];


        $user = new UserModel();


        try {

            //总数据条数
            $usercount =  $user->alias('ur')->field('ur.*')
                ->join('hospital hs ','hs.id=ur.hospitalid and ur.isdel=1 and hs.isdel=1 and hs.status=1')
                ->where($map)
                ->count();
            //后端排序 分页
            if (isset($param['sort']))
                $userdata = $user->alias('ur')->field('ur.*')
                             ->join('hospital hs ','hs.id=ur.hospitalid  and ur.isdel=1 and hs.isdel=1 and hs.status=1')
                             ->where($map)
                             ->order($param['sort'], $param['order'])->limit($param['offset'], $param['limit'])
                             ->select();
            else
                $userdata =  $user->alias('ur')->field('ur.*')
                            ->join('hospital hs ','hs.id=ur.hospitalid and ur.isdel=1 and hs.isdel=1 and hs.status=1')
                            ->where($map)
                            ->order('jobnum', 'desc')->limit($param['offset'], $param['limit'])
                            ->select();


            if ($userdata === false || $usercount === false)
                throw  new \Exception();

            /* foreach( $userdata as $k=>$v)
              {
                  if (intval($v['last_login_time'])!=0)
                      $userdata[$k]['last_login_time']=date('Y-m-d H:i:s',$v['last_login_time']);
                  else
                      $userdata[$k]['last_login_time']=null;
              }*/

            //  else
            //     $alldata=collection($userdata);


        } catch (\Exception $e) {
            return json(['code' => 0, 'total' => '', 'rows' => '', 'msg' => $e->getMessage()]);

        }


        return json(['code' => 1, 'total' => $usercount, 'rows' => $userdata, 'msg' => 'ok']);


    }


    /**
     * [userEdit 编辑用户]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function userEdit()
    {

        if (request()->isAjax()) {

            $user = new UserModel();

            $param = input('post.');


            if (!isset($parm['status']))
                $parm['status'] = 0;


            if (empty($param['jobnum'])) {//新增
                $flag = $user->insertUser($param);

                return json(['code' => $flag['code'], 'jobnum' => $flag['jobnum'], 'id' => $flag['id'], 'msg' => $flag['msg']]);

            } else {   //编辑

                $flag = $user->editUser($param);

                return json(['code' => $flag['code'], 'jobnum' => $flag['jobnum'], 'id' => $flag['id'], 'msg' => $flag['msg']]);
            }


        }


    }


    /**
     * [UserDel 删除用户]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function userDel()
    {
        if (request()->isAjax()) {

            $jobnum = input('param.jobnum');
            $user = new UserModel();
            $flag = $user->delUser($jobnum);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }
    }


    /**
     * [user_state 用户状态]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function user_state()

    {

        if (request()->isAjax()) {
            try {

                $jobnum = input('param.jobnum');
                $status = input('param.status');

                $flag = Model('UserModel')->where('jobnum', $jobnum)->setField('status', $status);

                if ($flag == false)
                    throw  new \Exception();

                if ($status == 1) {
                    writelog(session('uid'), session('username'), '【用户工号=' . $jobnum . '被启用', 1);
                    return json(['code' => 1, 'data' => '', 'msg' => '已启用']);
                } else {
                    writelog(session('uid'), session('username'), '【用户工号=' . $jobnum . '被禁用', 1);
                    return json(['code' => 0, 'data' => '', 'msg' => '已禁用']);
                }

            } catch (\Exception $e) {
                writelog(session('uid'), session('username'), '【用户工号=' . $jobnum . '状态设置失败', 2);
                return ['code' => -1, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
    }


//修改密码
    public function change_password()
    {
        $user = new UserModel();

        if (request()->isAjax()) {

            $param = input('post.');

            //  $param['password']=  md5(md5(trim($param['password'])). config('auth_key'));
            $param['password'] = encrypt(session('jobnum') . '@' . $param['password'], 'E');



            $userexist =Model('UserModel')->where(['jobnum' => session('jobnum'), 'password' => $param['password'], 'isdel&status' => 1])->count();

            if (intval($userexist) > 0)
                // $param['newpassword'] = md5(md5(trim($param['newpassword'])). config('auth_key'));
                $param['newpassword'] = encrypt(session('jobnum') . '@' . $param['newpassword'], 'E');

            else
                return json(['code' => -2, 'data' => '', 'msg' => '原始密码不正确']);

            $flag = $user->editPassword(session('uid'), session('hospitalid'), $param['newpassword']);
            return json(['code' => $flag['code'], 'data' => $flag['data'], 'msg' => $flag['msg']]);
        }


        return $this->fetch();
    }


    //获取用户默认医院以外所有医院
    public function getUserHospital()
    {

        if (request()->isAjax()) {

            $jobnum = input('post.jobnum');

            try {

                //取出不是用户默认医院所有可用医院
                $userAllhospital = Model('UserHospitalModel')->where('jobnum', $jobnum)->value('hospital');
                $userDefhospital = Model('UserModel')->where('jobnum', $jobnum)->value('hospitalid');
                $hospitals=[];
                $userHospitals=[];

                if (!empty($userAllhospital)) {
                    //sqlserver union 无效
                    $hospitals = Model('HospitalModel')->field('0 as chk,id,hospitalname')
                        /*  ->union('select 1 as state,id,hsopitalname from '.config('prefix').'hospital where id in ('.$userAllhospital. ') and hospitalid <>'.$userDefhospital,true)*/
                        ->where(['isdel&status' => 1, 'id' => ['<>', $userDefhospital]])
                        ->whereNotIn('id', $userAllhospital)
                        ->order('id', 'asc')
                        ->select();

                    $userHospitals = Model('HospitalModel')->field('1 as chk,id,hospitalname')
                        ->where(['isdel&status' => 1, 'id' => ['<>', $userDefhospital]])
                        ->whereIn('id', $userAllhospital)
                        ->order('id', 'asc')
                        ->select();

                    if ($hospitals === false || $userHospitals === false)
                        throw  new \Exception();

                    $allhospital = array_merge($hospitals, $userHospitals);

                } else {

                    $allhospital = Model('HospitalModel')->field('0 as chk,id,hospitalname')
                        ->where(['isdel&status' => 1, 'id' => ['<>', $userDefhospital]])
                        ->order('id', 'asc')
                        ->select();

                    if ($allhospital === false )
                        throw  new \Exception();

                }




            } catch (\Exception $e) {
                return json(['code' => 0, 'allhospital' => '', 'msg' => $e->getMessage()]);

            }


            return json(['code' => 1, 'allhospital' => $allhospital, 'msg' => 'ok']);
        }


    }





    //给人员授权多个医院权限
    public function authHospital(){


        if(request()->isAjax()){

            $jobnum=input('post.jobnum');
            $hospital=input('post.hospital/a');
            //默认所属医院
            $defhospitalid=Model('UserModel')->where('jobnum',$jobnum)->value('hospitalid');
            $UserHospita=UserHospitalModel::get($jobnum);
           try {
               if (!isset($hospital)) {
                   //无授权删除人员医院授权

                   UserHospitalModel::where('jobnum',$jobnum)->delete();
                   return json(['code'=>1,'data'=>'','msg'=>'授权成功']);
               } else {

                    $hospitalstr='';

                    foreach ($hospital as $item) {
                        if($hospitalstr=='')
                           $hospitalstr.=$item['id'];
                        else
                            $hospitalstr.=','.$item['id'];
                    }



                   $extis=strpos( $hospitalstr,$defhospitalid);



                   // print_r($extis); print_r(strval($defhospitalid));print_r($hospitalstr);exit();

                   if ( $extis!==false && strval($defhospitalid)==$hospitalstr ) {
                       //有医院授权，并且只是人员默认医院，如果之前有授权删除
                       UserHospitalModel::where('jobnum',$jobnum)->delete();

                   } else  {
                       // 有医院授权，并且包含人员默认医院，如果之前有授权覆盖，之前没有授权，新增授权
                      // $UserHospita->save(['jobnum' => $jobnum, 'hospital' => $hospitalstr],['jobnum' => $jobnum]);
                     if ( $extis===false)
                         $hospitalstr.=','.$defhospitalid;

                       if (empty($UserHospita))
                           model('UserHospitalModel')->save(['jobnum' => $jobnum, 'hospital' => $hospitalstr]);
                       else
                           model('UserHospitalModel')->save(['jobnum' => $jobnum, 'hospital' => $hospitalstr],['jobnum'=>$jobnum]);



                   }




                   return json(['code'=>1,'data'=>'','msg'=>'授权成功']);

               }
           }catch(\Exception $e){

                return json(['code'=>0,'data'=>'','msg'=>$e->getMessage()]);
           }



        }

    }

}