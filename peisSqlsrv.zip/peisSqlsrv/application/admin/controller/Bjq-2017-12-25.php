<?php

namespace app\admin\controller;


use think\console\command\make\Model;
use think\exception\PDOException;

class Bjq extends Base
{


	/**
	 * [blSjq 编辑器]
	 * @return [type] [description]
	 * @author [李勇] [peis999]
	 */
	public function index()
	{

		return $this->fetch();

		
		
	}



    /*  *[getAllBjqmb  获取所有编辑模板]
     * @return [type] [json]
    * @author [李勇] [peis999]
    */


    public function getAllBjqmb()
    {
        if (request()->isAjax()){

            try {
                $allmb = Model('BjqModel')->where('hospitalid', session('hospitalid'))->select();
                return json(['code'=>1 ,'data'=>$allmb,'msg'=>'ok']);
            }catch (PDOException $e){

                return json(['code'=>0 ,'data'=>'','msg'=>$e->getMessage()]);

            }


        }

    }

    /*  *[ getOneBjqmb  获取指定编辑模板]
     * @return [type] [json]
     *  @param [$id]  模板ID
    * @author [李勇] [peis999]
    */


    public function getOneBjqmb($id)
    {

        if (request()->isAjax()){

           try {
               $htmlmodel = Model('BjqModel')->where(['id' => $id, 'hospitalid' => session('hospitalid')])->value('htmlmodel');
               if ($htmlmodel == false)
                   throw  new \Exception();
               else
                   return json(['code' => 1, 'data' => $htmlmodel, 'msg' => 'OK']);


           }catch(\Exception $e){
                  return json(['code' => 0, 'data' => '', 'msg' => $e->getMessage()]);


           }

        }


    }

  /*  *[saveModel 保存编辑器模板]
 * @return [type] [description]
* @author [李勇] [peis999]
*/
    public function saveModel(){

        if (request()->isAjax()){

            $param=input('param.',null,null);
            $param['hospitalid']=session('hospitalid');
            $flag=Model('BjqModel')->bjqmbEdit( $param);

            if ($flag['code']==1)
                return json(['code'=>$flag['code'],'name'=>$flag['name'],'id'=>$flag['id'],'msg'=>$flag['msg']]);
            else
                return json(['code'=>$flag['code'],'data'=>'','msg'=>$flag['msg']]);



        }

    }


}