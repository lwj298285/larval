<?php
namespace app\admin\model;
use think\Db;
use think\Config;
use app\admin\model\TjjlbModel;
use think\Exception;
use think\exception\PDOException;
use think\Model;



class YsztModel extends Model{
    protected $name='tjjlmxb';




    /**
     * [delJg 录入 删除体检结果]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */
    public function delJg($tjinfo){

        try{
            Db::startTrans();

            $deljg=$this->where(['xh'=>$tjinfo['xh'],'zhxmid'=>$tjinfo['zhxmid'],'hospitalid'=>session('hospitalid')])->delete();
            $delzd=Model('TjzdbModel')->where(['xh'=>$tjinfo['xh'],'zhxmid'=>$tjinfo['zhxmid'],'hospitalid'=>session('hospitalid')])->delete();

            if ($deljg!==false &&  $delzd!==false) {

                $tjjlb = new TjjlbModel();

                $delresult = $tjjlb->save(['xj' => null, 'jcrq' => null, 'jcys' => null, 'czy' => null, 'jsover' => 10], ['hospitalid' => session('hospitalid'), 'xh' => $tjinfo['xh'], 'zhxmid' => $tjinfo['zhxmid']]);

                if ($delresult !== false) {

                    $tjcount = $tjjlb->where(['hospitalid' => session('hospitalid'), 'xh' => $tjinfo['xh'], 'jsover' => 20])->count();
                    if ($tjcount > 0)
                        Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $tjinfo['tjbh'], 'tjcs' => $tjinfo['tjcs']])->setField(['jdbz' => 20, 'tjendrq' => null]);
                    else {
                        Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $tjinfo['tjbh'], 'tjcs' => $tjinfo['tjcs']])->setField(['jdbz' => 15, 'tjendrq' => null]);

                    }

                    //获取组合项目小项塞入数组待写入体检结果表中
                    $zhxmxm = Model('ZhxmDtModel')->alias('dt')
                        ->join('tjxm', 'dt.tjxmid=tjxm.id')
                        ->field('tjxmid as xmid,jrxj,dw,ckxx as minckz,cksx as maxckz,memockz')
                        ->where('zhxmid', $tjinfo['zhxmid'])->select();


                    $xm = [];
                    foreach ($zhxmxm as $k => $value) {


                        $xm[$k]['xh'] = $tjinfo['xh'];
                        $xm[$k]['zhxmid'] = $tjinfo['zhxmid'];
                        $xm[$k]['xmid'] = $value->xmid;
                        $xm[$k]['dw'] = $value->dw;
                        $xm[$k]['jrxj'] = $value->jrxj;
                        $xm[$k]['minckz'] = $value->minckz;
                        $xm[$k]['maxckz'] = $value->maxckz;
                        $xm[$k]['memockz'] = $value->memockz;
                        $xm[$k]['hospitalid'] = session('hospitalid');

                    }


                    $result = $this->saveAll($xm, false);

                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检结果失败(xh(序号)='.$tjinfo['xh'].'--zhxmid(组合项目ID)='.$tjinfo['zhxmid'].')',2);
                        return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $this->getError()];
                    }


                }


            }

            if ( $delresult!==false) {
                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除体检结果成功(xh(序号)='.$tjinfo['xh'].'--zhxmid(组合项目ID)='.$tjinfo['zhxmid'].')',1);
                Db::commit();
                return (['code' => 1, 'data' => '', 'msg' => '删除体检结果成功']);
            }else{

                Db::rollback();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除体检结果失败(xh(序号)='.$tjinfo['xh'].'--zhxmid(组合项目ID)='.$tjinfo['zhxmid'].')',2);
                return (['code' => 0, 'data' => '', 'msg' => '删除体检结果失败']);
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }

    }


    /**
     * [editJg 录入 编辑体检小项信息]
     * @return [type] [description]
     * @author [李勇] [peis999]
     */

    public function editJg($tjxmitem,$zhxmitem,$zditem){

        try{
            Db::startTrans();

            // $tjjlxmb=new TjjlmxbModel();
            $jsover=$zhxmitem['jsover'];

           // $tjxmresult = $this->where(['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'zhxmid' => $zhxmitem['zhxmid']])->delete();
            $zdresult = Model('TjzdbModel')->where(['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'zhxmid' => $zhxmitem['zhxmid']])->delete();

            if ( $zdresult !== false ) {

                //保存录入结果
                if(is_array($tjxmitem)){

                    foreach ($tjxmitem as $key => $v) {

                        //注意不要在一个模型实例里面做多次更新，会导致部分重复数据不再更新，正确的方式应该是先查询后更新或者使用模型类的update方法更新。
                       // 如果你调用save方法进行多次数据写入的时候，需要注意，第二次save方法的时候必须使用isUpdate(false)，否则会视为更新数据。
                        //$tjxmresult = $this->allowField('jg,ycts,sfyx,jrxj,jcrq,jcys')->isUpdate(true)->save($v);
                        //$tjxmresult = $this->allowField('jg,ycts,sfyx,jrxj,jcrq,jcys')->save($v,['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'zhxmid' => $zhxmitem['zhxmid'],'xmid'=>$v['xmid']]);
                        //$updatedata=['jg'=>$v['jg'],'ycts'=>$v['ycts'],'sfyx'=>$v['sfyx'],'jrxj'=>$v['jrxj'],'jcrq'=>$zhxmitem['jcrq'],'jcys'=>$zhxmitem['jcys']];
                        $updatedata=['jg'=>$v['jg'],'ycts'=>$v['ycts'],'sfyx'=>$v['sfyx'],'jrxj'=>$v['jrxj']];
                        $tjxmresult = YsztModel::update($updatedata,['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'zhxmid' => $zhxmitem['zhxmid'],'xmid'=>$v['xmid']]);
                    }

                }

               // $tjxmresult = $this->saveAll($tjxmitem);//,['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'zhxmid' => $zhxmitem['zhxmid']

                if(is_array($zditem))
                  $zdresult = Model('TjzdbModel')->allowField(true)->saveAll($zditem);


            } else {


                Db::rollback();

                return (['code' => 0, 'data' => '', 'msg' => '删除原始诊断失败']);

            }


            if ($tjxmresult!==false && $zdresult!==false){


                $zhxmitem['hospitalid'] = session('hospitalid');
                $zhxmitem['czy'] = session('jobnum');
                //$zhxmitem['jsover'] = 15;
              //  $zhxmitem['xj'] = textAreaStr($zhxmitem['xj']);
                $tjjlb = new TjjlbModel();

                $zhxmresult = $tjjlb->save($zhxmitem, ['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'zhxmid' => $zhxmitem['zhxmid']]);

                if ($zhxmresult !== false) {

                    if ( $jsover==15) {
                        $tjcount = $tjjlb->where(['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'jsover' => 20])->count();
                        if ( $tjcount>0)
                            $edittjjlb = Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $zhxmitem['tjbh'], 'tjcs' => $zhxmitem['tjcs']])->setField('jdbz',20);
                        else
                            $edittjjlb = Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $zhxmitem['tjbh'], 'tjcs' => $zhxmitem['tjcs']])->setField('jdbz', 15);

                    } else{

                        $tjcount=$tjjlb->where(['hospitalid' => session('hospitalid'), 'xh' => $zhxmitem['xh'], 'jsover' =>['in','10,15']])->count();
                        if ( $tjcount>0)
                            $edittjjlb = Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $zhxmitem['tjbh'], 'tjcs' => $zhxmitem['tjcs']])->setField('jdbz', 20);
                        else
                            $edittjjlb = Model('TjdjModel')->where(['hospitalid' => session('hospitalid'), 'tjbh' => $zhxmitem['tjbh'], 'tjcs' => $zhxmitem['tjcs']])->setField(['jdbz'=>30,'tjendrq'=>Date("Y-m-d")]);

                    }




                    if ($edittjjlb === false) {
                        Db::rollback();
                        return (['code' => 0, 'data' => '', 'msg' => '体检进度更新失败']);
                    }


                } else {

                    Db::rollback();
                    return (['code' => 0, 'data' => '', 'msg' => '组合项目状态更新失败']);
                }



            }else{


                Db::rollback();

                if ($jsover==15) {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】体检结果录入失败(xh(序号)='.$zhxmitem['xh'].'--zhxmid(组合项目ID)='.$zhxmitem['zhxmid'].')',2);
                    return (['code' => 0, 'data' => '', 'msg' => '体检结果录入失败']);
                }else {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】体检小结失败(xh(序号)='.$zhxmitem['xh'].'--zhxmid(组合项目ID)='.$zhxmitem['zhxmid'].')',2);
                    return (['code' => 0, 'data' => '', 'msg' => '体检小结失败']);
                }


            }


            Db::commit();

            if ($jsover==15) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】体检结果录入成功(xh(序号)=' . $zhxmitem['xh'] . '--zhxmid(组合项目ID)=' . $zhxmitem['zhxmid'] . ')', 1);
                return (['code' => 1, 'data' => '', 'msg' => '体检结果录入成功'  ]);
            }else {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】小结成功(xh(序号)=' . $zhxmitem['xh'] . '--zhxmid(组合项目ID)=' . $zhxmitem['zhxmid'] . ')', 1);
                return (['code' => 1, 'data' => '', 'msg' => '小结成功'  ]);
            }


        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }




}