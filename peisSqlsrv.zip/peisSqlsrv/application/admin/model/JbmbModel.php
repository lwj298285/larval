<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class JbmbModel extends Model
{
//疾病模板
    protected $name = "jbmb_hd";


    /**
     * [getOneLclx 获取临床类型节点数据]
     * @author [李勇] [peis999]
     */
        public function getOneJbmb($id)
    {
        return $this->find($id);
    }


    /**
     * [ editJbmb参数【判断是新增还是更新 疾病模板]
     * @author [李勇] [peis999]
     */
    public function editJbmb($param)
    {

        try {

            if (!empty($param['id'])) { //更新
                $result = $this->save($param,['id'=>$param['id']]);  //update不验证
                if (false === $result) {
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    return ['code' => 1, 'data' => '', 'msg' => '编辑疾病模板' . $param['mc'] . '成功'];
                }

            } else { //新增
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];
                $param['hospitalid']=session('hospitalid');
                $result = $this->save($param);  //insert 不验证

                if (false === $result) {
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    return ['code' => 1, 'data' => '', 'msg' => '新增疾病模板' . $param['mc'] . '成功'];
                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * delJbmb  删除疾病模板
     * @param $jbmbid $ycflid $name
     */
    public function delJbmb($id,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where('id',$id)->setField('isdel',0);
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除疾病模板' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除疾病模板失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除疾病模板' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除疾病模板成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    //   调整疾病模板排序
    public function editSoft($id,$type,$targetid)
        {
            Db::startTrans();
            try{

                $softId=$this->where('id',$id)->value('softid');
                $targerSoftId=$this->where('id',$targetid)->value('softid');
               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

                if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];


                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整疾病模板排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}