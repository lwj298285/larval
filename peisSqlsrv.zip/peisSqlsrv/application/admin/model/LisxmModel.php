<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Collection;
use think\Validate;
class LisxmModel extends Model
{
//体检项目表名不带前缀
    protected $name = "lisxmb";

    public function editLisxm($param)
    {

        Db::startTrans();
        try {

            $result = $this->saveAll($param);

            if (false === $result) {
                Db::rollback();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】导入LIS项目失败'.$this->getError().')',2);
                return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
            } else {
                Db::commit();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】导入LIS项目成功)',1);
                return ['code' => 1, 'data' =>'', 'msg' => '导入LIS项目成功'];
            }



        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }








}