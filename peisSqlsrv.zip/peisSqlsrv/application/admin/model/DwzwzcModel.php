<?php
namespace app\admin\model;
use think\Validate;
use think\Db;
use think\exception\PDOException;
use think\Model;
class DwzwzcModel extends Model{
    protected $name='dwzwzc';

    //获取单位职务职称
    public function editZwzc($param){

        $param['dwid']=$param['zwdwid'];
        unset($param['zwdwid']);
        $param['id']=$param['zwid'];
        unset($param['zwid']);
        $param['mc']=$param['zwmc'];
        unset($param['zwmc']);


        $validate = new Validate([
            ["mc","unique:dwzwzc,mc={$param['mc']}&type={$param['type']}&dwid={$param['dwid']}","职务职称已存在"]
        ]);
        try {
            if (empty($param['id'])) { //新增职务职称
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];
                $result=$validate->check($param);
                if (false === $result) {
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加职称失败', 1);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError(),'editstatus'=> ''];
                } else {

                    $this->allowField(true)->save($param);
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加职称成功',1);
                    return ['code' => 1, 'data' =>$param, 'msg' => '添加部门成功','editstatus'=> 'add'];
                }
            } else {//编辑职务职称
                $result=$validate->check($param);

                if (false === $result) {
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑部门失败', 1);
                    return ['code' => 0, 'data' => '', 'msg' =>$validate->getError(),'editstatus'=> ''];
                } else {
                    $this->save($param,['dwid'=> $param['dwid'],'id'=>$param['id']]);
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑部门成功',1);
                    return ['code' => 2, 'data' => $param, 'msg' => '编辑部门成功','editstatus'=> 'edit'];
                }
            }
        } catch (PDOException $e) {
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

//删除单位职务职称信息
public function delZwzc($id){
    Db::startTrans();
    try{
       $param['zwid']= $id;
        unset($param['zwid']);

         $result=$this->where('id',$id)->delete();
           if($result==false){
               Db::rollback();
               writelog(session('uid'),session('username'),'用户【'.session('uid').'】删除职务信息(ID='.$id.')失败',2);
               return ['code'=>0,'data'=>'','msg'=>$this->getError()];
           }else{
               Db::commit();
               writelog(session('uid'),session('username'),'用户【'.session('uid').'】删除职务信息(ID='.$id.')成功',1);
               return ['code'=>1,'data'=>'','msg'=>'OK'];
           }
    }catch (PDOException $e){
        Db::rollback();
        return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
    }
}

//
public function SoftEdit($id,$type,$targetid){
Db::startTrans();
    try{
        $param['zwid']= $id;
        unset($param['zwid']);
        $softId=$this->where('id',$id)->value('softid');
        $targetSoftId=$this->where('id',$targetid)->value('softid');
        if($softId>$targetSoftId)
            $map['softid']=['between',$targetSoftId.','.$softId];
        else
            $map['softid']=['between',$softId.','.$targetSoftId];
        if($type=="prev"){
            if($softId>$targetSoftId){
                Db::rollback();
                $map['softid']=['between',$targetSoftId.','.($softId-1)];
                $this->where($map)->setInc('softid');
                $this->where('id',$id)->setField('softid',$targetSoftId);
            }else{
                Db::commit();
                $map['softid']=['between',($softId+1).','.($targetSoftId-1)];
                $this->where($map)->setDec('softid');
                $this->where('id',$id)->setField('softid',($targetSoftId-1));
            }
        }else{
            if($softId>$targetSoftId){
                Db::rollback();
                $map['softid']=['between',($targetSoftId+1).','.($softId-1)];
                $this->where($map)->setInc('softid');
                $this->where('id',$id)->setField('softid',($targetSoftId+1));
            }else{
                Db::commit();
                $map['softid']=['between',($softId+1).','.$targetSoftId];
                $this->where($map)->setDec('softid');
                $this->where('id',$id)->setField('softid',$targetSoftId);
            }
        }
        Db::rollback();
        return ['code' => 1, 'data' => '', 'msg' => '调整职务信息排序成功'];
    }catch (PDOException $e){
        Db::rollback();
        return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
    }


}
}

