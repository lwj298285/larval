<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use traits\model\SoftDelete;
use think\Validate;

class DwfzModel extends Model
{
	//体检单位
	protected $name = "dwfz_hd";
    use SoftDelete;
    protected $deletetime = 'delete_time';






    /**
     * [  getDwfz参数【递归获取顶级父单位分组套餐某项套餐]
     * @author [李勇] [peis999]
     */

    public static function getOneDwfz($dwid,$fzid){

        if (!empty($dwid))
            $map = ['status' => 1, 'id' => $dwid, 'hospitalid' => session('hospitalid')];
        else
            $map = ['status' => 1, 'hospitalid' => session('hospitalid')];


        $data= Model('TjdwModel')->where($map)->order('softid')->find();

        if ($data['pid']!=0)
            return self::getOneDwfz($data['pid'],$fzid);




        return Model('DwfzModel')->where(['hospitalid'=>session('hospitalid'),'status'=>1,'dwid'=>$dwid,'id'=>$fzid])->find();

    }



    /**
	 * [  getDwfz参数【递归获取顶级父单位分组套餐所有套餐]
	 * @author [李勇] [peis999]
	 */

  public static function getDwfz($dwid,$isall){

        if (!empty($dwid))
            $map = ['status' => 1, 'id' => $dwid, 'hospitalid' => session('hospitalid')];
        else
            $map = ['status' => 1, 'hospitalid' => session('hospitalid')];


        $data= Model('TjdwModel')->where($map)->order('softid')->find();

        if ($data['pid']!=0)
            return self::getDwfz($data['pid'],$isall);


        if( $isall=='yes')//取出单位所有分组套餐
            return Model('DwfzModel')->where(['hospitalid'=>session('hospitalid'),'status'=>1,'dwid'=>$dwid])->order('softid')->select();
        else
            return Model('DwfzModel')
                ->where(['hospitalid'=>session('hospitalid'),'status'=>1,'dwid'=>$dwid])
                //->where(['sfsh'=>1],['sfsh'=>0,['exp',' zk is null or zkhjg is null']],'or')
               /// ->where(['sfsh'=>1],['sfsh'=>0,['exp',' zk is null or zkhjg is null']],'or')
                //->where('sfsh',1)
                ->where('sfsh=1 or sfsh=0 and (zk is null or zkhjg is null)')
                ->order('softid')
                ->select();
    }


	public function editDwfz($param)
	{
		
		try {

            if(!isset($param['status']))
                $param['status']=0;

            $param['hospitalid']=session('hospitalid');
            //$param['delete_time']=['exp','is null'];

            if(empty($param['zk']))
               $param['zk']=null;

            if(empty($param['zkhjg']))
                $param['zkhjg']=null;

            if(empty($param['jg']))
                $param['jg']=null;



            Db::startTrans();

            if (!empty($param['id'])) { //更新




              /*  $validate = new Validate([
                    // ["mc","unique:dwfz_hd,mc={$param['mc']}&dwid={$param['dwid']}&hospitalid={session('hospitalid')},id,".$param['id'],"单位分组已存在"]
                    ["mc","unique:dwfz_hd,hospitalid^dwid^mc^delete_time,{$param['id']},id","单位分组已存在"]

                ]);
                $result=$validate->check($param);*/

                $result=$this->where(['mc'=>$param['mc'],'hospitalid'=>session('hospitalid'),'dwid'=>$param['dwid'],'id'=>['<>',$param['id']]])->count();

                if ($result>0) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => '单位分组已经存在'];
                } else {

                    //unset($param['delete_time']);
                    $currdwfz= $this->where (['id' => $param['id'], 'hospitalid' =>$param['hospitalid'], 'dwid' => $param['dwid']])->find();

                    //折扣没有审核


                    if ($currdwfz->zk != $param['zk'] || floatval($currdwfz->zkhjg) != floatval($param['zkhjg'])) {


                        if ($param['zk'] == null || $param['zkhjg'] == null ) {
                            Model('DwfzDtModel')->where(['hospitalid' => session('hospitalid'), 'fzid' => $param['id']])->setField('jg', null);
                            $param['sfsh'] = 0;
                            $currdwfz->update($param, ['id' => $param['id'], 'hospitalid' => $param['hospitalid'], 'dwid' => $param['dwid']]);
                        }else {
                            $currdwfz->update($param, ['id' => $param['id'], 'hospitalid' => $param['hospitalid'], 'dwid' => $param['dwid']]);
                            Db::execute('exec  SP_Dwfzzk ' . session('hospitalid') . ',' . $param['dwid'] . ',' . $param['id']);
                        }


                    }else{

                        $currdwfz->update($param, ['id' => $param['id'], 'hospitalid' => $param['hospitalid'], 'dwid' => $param['dwid']]);

                    }

                    Db::commit();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑单位分组成功', 1);
                    return ['code' => 2, 'data' => $param, 'msg' => '编辑单位分组' . $param['mc'] . '成功'];

                }

			} else { //新增

			//	$param['hospitalid'] = session('hospitalid');
              /*  $validate = new Validate([
                    ["mc","unique:dwfz_hd,hospitalid^dwid^mc^delete_time","单位分组已存在"]
                  //  ["mc","unique:dwfz_hd,mc={$param['mc']}&dwid={$param['dwid']}&hospitalid=".session('hospitalid'),"单位分组已存在"]

                ]);
                $result=$validate->check($param);*/
                $result=$this->where(['mc'=>$param['mc'],'hospitalid'=>session('hospitalid'),'dwid'=>$param['dwid']])->count();


                if ($result>0) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' =>'单位分组已经存在'];
                } else {
                    unset($param['delete_time']);
                    $id = $this->withTrashed(['hospitalid'=>$param['hospitalid'],'dwid'=>$param['dwid']])->max('id');
                    $param['id'] = empty($id) ? 1 : $id + 1;
                    $param['softid'] = $param['id'];
                    $result = $this->save($param);  //insert 不验证

                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】新增单位分组失败'.$this->getError(), 2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        Db::commit();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】新增单位分组成功', 1);
                        return ['code' => 1, 'data' => $param, 'msg' => '新增单位分组' . $param['mc'] . '成功'];
                    }
                }
				
			}
			
		}catch( PDOException $e){
            Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
	/**
	 * delTjdw  删除体检单位
	 * @param $id $name
	 */
	public function delDwfz($id,$name,$dwid)
	{
		Db::startTrans();
		try{

            if(!empty(Model('TjdjModel')->where(['hospitalid'=>session('hospitalid'),'dwid'=>$dwid,'tcid'=>$id])->select())) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'单位分组已被登记引用不可删除'];
            }

            $result = $this->where(['id'=>$id,'dwid'=>$dwid,'hospitalid'=>session('hospitalid')])->find()->delete();
            if ($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除单位分组' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除单位分组失败'];
            } else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除单位分组' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除单位分组成功'];

            }
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
	/**
	 * editSoft 排序
	 * @author [李勇] [peis999]
	 */
	public function editSoft($dwid,$id,$type,$targetid)
	{
		Db::startTrans();
		try{

            $where=['id'=>$id,'dwid'=>$dwid];
			$softId=$this->where($where)->value('softid');
			$targerSoftId=$this->where(['id'=>$targetid,'dwid'=>$dwid])->value('softid');
			
			if ($softId >$targerSoftId)
				$map['softid']=['between',$targerSoftId.','. $softId];
			else
				$map['softid']=['between',$softId.','.$targerSoftId];
			
			$map['dwid']=['=',$dwid];
			
			if ($type=="prev") {
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where($where)->setField('softid', $targerSoftId);
				} else{
					$map['softid']=['between',($softId+1).','.($targerSoftId-1)];
					$this->where($map)->setDec('softid');
					$this->where($where)->setField('softid', $targerSoftId-1);
				}
				
				
			}else{
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where($where)->setField('softid', $targerSoftId+1);
				} else{
					$map['softid']=['between',($softId+1).','.$targerSoftId];
					$this->where($map)->setDec('softid');
					$this->where($where)->setField('softid', $targerSoftId);
				}
				
			}
			
			Db::commit();
			return ['code' => 1, 'data' => '', 'msg' => '调整体检单位排序成功'];
			
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
}