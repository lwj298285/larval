<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;

class TjdwModel extends Model
{
	//体检单位
	protected $name = "tjdw";
	
	
	/**
	 * [getOneTjdw获取节点数据]
	 * @author [俞晴] [peis999]
	 */
	public function getOneTjdw($id)
	{
		return $this->alias('tjdw')->Join('tjdw ptjdw','tjdw.pid=ptjdw.id','left')->field('tjdw.*,ptjdw.dwname pidname')->find($id);
	}
	
	/**
	 * [getAllTjdw 获取全部单位]
	 * @author [俞晴] [peis999]
	 */
	public function getAllTjdw()
	{
		return $this->where(['isdel'=>1,'hospitalid'=>session('hospitalid')])->order('id asc')->select();
	}

/**
 * getTjdwAllChilren获取顶级父单位及所有子单位 调用存储过程
 */
    public function getTjdwChilren($dwid)
    {
        //return Db::query('call SP_GetDWChildren '.$dwid.','.session('hospitalid'));   MYSQL

        Db::execute('exec SP_GetDWChildren '.$dwid.','.session('hospitalid'));  //MSSQL

    }



	/**
	 * [ editTjdw参数【判断是新增还是更新 体检单位]
	 * @author [俞晴] [peis999]
	 */
	public function editTjdw($param)
	{


        Db::startTrans();
		try {

            $validate = new Validate([
                ["dwname","unique:tjdw,dwname={$param['dwname']}&hospitalid=".session('hospitalid')."&isdel=1","体检单位(".$param['dwname'].")已存在",]
            ]);

            if(!isset($param['status']))
                $param['status']=0;
            if(empty($param['nature']))
                $param['nature']=null;

            if ($param['pid']!=0)
                $param['status']= Model('TjdwModel')->where('id',$param['pid'])->value('status')==0?0: $param['status'];

            if (!empty($param['id'])) { //更新


                //获取当前单位下的所有子单位如果父单位禁用 ，子单位也全部禁用
               if  ($param['status']==0) {
                   $list = Model('TjdwModel')->where('hospitalid',session('hospitalid'))->field('id,pid,softid')->order('softid')->select();
                   $ids = $this->getChildren( $list, $param['id']);
                   $this->where('id','in',$ids)->setField('status',0);
               }

                $result=$validate->check($param);

                if (false === $result) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param, ['id' => $param['id']]);  //update不验证

                    if (false === $result) {
                        Db::rollback();
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        //如果状态为禁用 设置子单位状态禁用

                        Db::commit();
                        return ['code' => 2, 'data' => $param, 'msg' => '编辑体检单位' . $param['dwname'] . '成功'];
                    }
                }
				
			} else { //新增
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];
                $param['hospitalid'] = session('hospitalid');

                $result = $validate->check($param);

                if (false === $result) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param);  //insert 不验证

                    if (false === $result) {
                        Db::rollback();
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                    } else {
                        Db::commit();
                        return ['code' => 1, 'data' => $param, 'msg' => '新增体检单位' . $param['dwname'] . '成功'];
                    }

                }
            }
			
		}catch( PDOException $e){
            Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}


//获取当前单位下的所有子单位
    function getChildren($list,$dwid){
        static $ids="";

        if  ($list) {
            foreach($list as $key=>$vo){
                //看组合项目是否启用显示不同图标
                if ($vo['pid']==$dwid){
                    $ids .= $vo['id'].',';
                    $this->getChildren($list,$vo['id']);
                }
            }
        }


        return substr($ids, 0, -1) ;


    }


	/**
	 * delTjdw  删除体检单位
	 * @param $id $name
	 */
	public function delTjdw($ids,$name)
	{
		Db::startTrans();
		try{

            if (Model('TjdjModel')->where('dwid','in',$ids)->find()){

                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => '单位已被引用，不可删除'];
             }


			$result=$this->where('id','in',$ids)->setField('isdel',0);
            if ($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检单位' . $name . '失败(ID=' . $ids . ')', 2);
                Db::rollback();
                return ['code' =>0, 'data' => '', 'msg' => '删除体检单位失败'];
            } else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检单位' . $name . '成功(ID=' . $ids . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检单位成功'];

            }
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
	/**
	 * editSoft 排序
	 * @author [俞晴] [peis999]
	 */
	public function editSoft($id,$type,$targetid)
	{
		Db::startTrans();
		try{
			
			$softId=$this->where('id',$id)->value('softid');
			$targerSoftId=$this->where('id',$targetid)->value('softid');
			// $softId=$this->field('softid')->get($id);
			// $targerSoftId=$this->field('softid')->get($targetid);
			
			if ($softId >$targerSoftId)
				$map['softid']=['between',$targerSoftId.','. $softId];
			else
				$map['softid']=['between',$softId.','.$targerSoftId];
			
			//$map['softid']=['between','lt,gt'];
			
			if ($type=="prev") {
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId);
				} else{
					$map['softid']=['between',($softId+1).','.($targerSoftId-1)];
					$this->where($map)->setDec('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId-1);
				}
				
				
			}else{
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId+1);
				} else{
					$map['softid']=['between',($softId+1).','.$targerSoftId];
					$this->where($map)->setDec('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId);
				}
				
			}
			
			Db::commit();
			return ['code' => 1, 'data' => '', 'msg' => '调整体检单位排序成功'];
			
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
}