<?php

namespace app\admin\model;
use think\Model;
use traits\model\SoftDelete;
use think\Db;

class IdcardModel extends Model
{
    protected $name = 'card';
    use SoftDelete;
    protected $deletetime = 'delete_time';
    /**
     * insertCard 新增会员卡
     * @param $param
     */
    public function insertCard($param)
    {
        Db::startTrans();

        try {

            $param['hospitalid']=session('hospitalid');
            $result = $this->validate('UserValidate')->save($param,false);


            if(false === $result){
                Db::rollback();
                return ['code' => 0, 'data' => '','msg' => $this->getError()];
            }else{


                writelog(session('uid'),session('username'),'会添加员卡号【'.$param['cardnum'].'】成功',1);
                return ['code' => 1, 'data' =>'', 'msg' => '添加会员卡成功'];
            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * [editEdit( 编辑会员卡]
     * @author [李勇] [peis999]
     */
    public function editCard($param)
    {
        try{

            Db::startTrans();

            $result =  $this->validate('IdcardValidate')->save($param, ['cardnum' => $param['cardnum'],'hospitalid'=>session('hospitalid')]);

            if(false === $result){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
            }else{

                writelog(session('uid'),session('username'),'编辑会员卡号【'.$param['cardnum'].'】信息成功',1);
                return ['code' => 1, 'data' =>'', 'msg' => '编辑会员卡成功'];
            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }

    }



    /**
     * 删除会员卡
     * @author [李勇] [peis999]
     * @param $cardnum 会员卡号
     */
    public function delUser($cardnum)
    {
        Db::startTrans();
        try{

            $result=$this->where(['cardnum'=>$cardnum,'hospitalid'=>session('hospitalid')])->delete();

            if ($result===false)
                throw new \Exception();

            Db::commit();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】删除会员卡号（'.$cardnum.'）成功',1);
            return ['code' => 1, 'data' => '', 'msg' => '删除会员卡成功'];

        }catch( \Exception $e){
            Db::rollback();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】删除操作员工号（'.$cardnum.'）失败',2);
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
	
}