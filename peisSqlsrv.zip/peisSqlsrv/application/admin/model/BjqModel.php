<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 15:51
 */

namespace app\admin\model;
use traits\model\SoftDelete;
use think\Db;
use think\exception\PDOException;
use think\Model;
use think\Validate;

class BjqModel extends Model
{
    protected $name = "bjqmb";
    use SoftDelete;
    protected $deletetime = 'delete_time';




//添加及修改编辑器模板
    public function bjqmbEdit($param)
    {

        try {
            $validate = new Validate([
                ["name", "unique:bjqmb,name=".$param['name']."&hospitalid=" . $param['hospitalid'], "编辑器模板(" . $param['name'] . ")已存在",],

            ]);


            if (!empty($param['id'])) {
                $result = $validate->check($param);

                if ($result == false) {

                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {

                    $result = $this->save($param, ['id' => $param['id'],'hospitalid'=>$param['hospitalid']]);
                    if (false === $result) {
                        writelog(session('uid'), session('uesrname'), '修改编辑器模板[' . $param['name'] . ']失败' . $this->getError(), 2);
                        throw new \Exception();
                    } else {

                        writelog(session('uid'), session('uesrname'), '修改编辑器模板[' . $param['name'] . ']成功', 1);
                        return ['code' => 2,'data' => '',  'msg' => '修改编辑器模板' . $param['name'] . '成功'];
                    }
                }
            } else {


                $result = $validate->check($param);


                if ($result == false) {

                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {

                $id = $this->where('hospitalid',$param['hospitalid'])->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $result = $this->allowField(true)->save($param);
                if (false === $result) {
                        writelog(session('uid'), session('uesrname'), '添加编辑器模板[' . $param['name'] . ']失败' . $this->getError(), 2);
                         throw new \Exception();
                  } else {

                       writelog(session('uid'), session('uesrname'), '添加编辑器模板[' . $param['name'] . ']成功', 1);
                        return ['code' => 1, 'id' => $param['id'],'name'=>$param['name'], 'msg' => '添加编辑器模板' . $param['name'] . '成功'];
                  }

                }

            }

        } catch (\Exception $e) {
            //Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];

        }
    }


//删除编辑器模板
    public function delBjqmb($id)
    {
        try {
            $result = $this->where(['id' => $id, 'hospitalid' => session('hospitalid')])->find()->delete();
            if ($result == false) {
                writelog(session('uid'), session('username'), '删除编辑器模板失败', 2);
                return ['code' => 0, 'data' => '', 'msg' => '删除编辑器模板失败'];
            } else {
                writelog(session('uid'), session('username'), '删除编辑器模板成功', 1);
                return ['code' => 1, 'data' => '', 'msg' => '删删除编辑器模板成功'];
            }
        } catch (PDOException $e) {
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }

    }
}
