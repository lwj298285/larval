<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use traits\model\SoftDelete;
class WjdcModel extends Model
{
//中医体质辨别问卷调查不带前缀
    protected $name = "wjdc";
    use SoftDelete;
    protected $deletetime = 'delete_time';
    /**
     * [ editWjdc参数【判断是新增还是更新体质辨别]
     * @author [李editWjdc勇] [peis999]
     */
    public function editWjdc($param,$djlsh)
    {

        Db::startTrans();
        try {


            $updatabefore=$this->where(['hospitalid'=>session('hospitalid'),'djlsh'=>$djlsh])->select();

            if (empty($updatabefore)) {
                $reuslt = $this->insertAll($param);
                if ($reuslt==false){

                    Db::rollback();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】新增问卷调查(登记流水号=' . $djlsh . ')失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => '新增问卷调查失败'];
                }
            } else {

                foreach ($param as $list) {
                    $reuslt = $this->save($list, ['djlsh' => $list['djlsh'], 'hospitalid' =>$list['hospitalid'], 'tzlx' => $list['tzlx']]);

                    if ($reuslt==false){

                        Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】更新问卷调查(登记流水号=' . $djlsh . ')失败',2);
                        return ['code' => 0, 'data' => '', 'msg' => '更新问卷调查失败'];
                    }
                }


            }

            Db::commit();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】保存问卷调查(登记流水号=' . $djlsh . ')成功',1);
            return ['code' => 1, 'data' => '', 'msg' => '保存问卷调查成功'];

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delWjdc  删除体质辨别问卷调查
     * @param $id $name
     */
    public function delWjdc($djlsh)
    {
        Db::startTrans();
        try {


            $result = $this->where(['djlsh'=>$djlsh,'hospitalid'=>session('hospitalid')])->find()->delete();

            if ($result == false){
                writelog(session('uid'), session('username'), '用户【'.session('username').'】删除问卷调查失败(登记流水号=' . $djlsh . ')', 2);
                Db::rollback();
               return ['code' => 0, 'data' => '', 'msg' => '删除问卷调查失败'];
          } else{
                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除问卷调查成功(登记流水号='.$djlsh.')',1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除问卷调查成功'];
            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }










}