<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;

class FwhyModel extends Model
{
//临床类型
    protected $name = "fwhy";


    /**
     * [getOneLclx 获取临床类型节点数据]
     * @author [李勇] [peis999]
     */
    public function getOneFwhy($id)
    {
        return $this->find($id);
    }


    /**
     * [ editLclx参数【判断是新增还是更新 临床类型]
     * @author [李勇] [peis999]
     */
    public function editFwhy($param)
    {

        try {

            $validate = new Validate([
                ["mc","unique:fwhy,mc={$param['mc']}&isdel=1","服务行业(".$param['mc'].")已存在",]
            ]);


            if (!empty($param['id'])) { //更新
                $result=$validate->check($param);

                if (false === $result) {
                    //writelog(session('uid'),session('uesrname'),'编辑服务行业['.$param['mc'].']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param,['id'=>$param['id']]);  //update不验证
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'编辑服务行业['.$param['mc'].']失败'. $this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    }else {
                        writelog(session('uid'),session('uesrname'),'编辑服务行业['.$param['mc'].']成功',1);
                        return ['code' => 1, 'data' => '', 'msg' => '编辑服务行业' . $param['mc'] . '成功'];
                    }

                }

            } else { //新增
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];

                $result=$validate->check($param);
                if (false === $result) {
                    //writelog(session('uid'),session('uesrname'),'新增服务行业['.$param['mc'].']成失败',2);
                    return ['code' => 0, 'data' => '', 'msg' =>$validate->getError()];
                } else {
                    $result = $this->save($param);  //insert 不验证
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'新增服务行业['.$param['mc'].']失败'. $this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    }else {
                        writelog(session('uid'),session('uesrname'),'新服务行业['.$param['mc'].']成功',1);
                        return ['code' => 1, 'data' => '', 'msg' => '新增服务行业' . $param['mc'] . '成功'];
                    }

                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * delLclx  删除服务行业
     * @param $id $name
     */
    public function delFwhy($id,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where('id',$id)->setField('isdel',0);
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除服务行业' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除服务行业失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除服务行业' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除服务行业成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    //   调整服务行业排序
    public function editSoft($id,$type,$targetid)
        {
            Db::startTrans();
            try{

                $softId=$this->where('id',$id)->value('softid');
                $targerSoftId=$this->where('id',$targetid)->value('softid');
               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

                if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];

                //$map['softid']=['between','lt,gt'];

                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整服务行业排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}