<?php

namespace app\admin\model;
use think\Model;
use thin\Db;
class LogModel extends Model
{
    protected $name = 'log';

    /**
     * 删除日志
     */
    public function delLog($log_id)
    {
        try{
            $this->where('log_id', $log_id)->setField('isdel',0);
            return ['code' => 1, 'data' => '', 'msg' => '删除日志成功'];
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    public function delCurrLog($conWhere)
    {
        try{

            $this->where($conWhere)->setField('isdel',0);
            return ['code' => 1, 'data' => '', 'msg' => '删除当前日志成功'];
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    public function delAllLog()
    {
        try{
            $this->where('isdel',1)->setField('isdel',0);
            return ['code' => 1, 'data' => '', 'msg' => '删除所有日志成功'];
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

}