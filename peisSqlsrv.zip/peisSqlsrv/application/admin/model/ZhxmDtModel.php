<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class ZhxmDtModel extends Model
{
//组合项目表名不带前缀
    protected $name = "zhxm_dt";




    /**
     * [ editZhxmDt参数【 组合项目添加小项】
     * $arrtjxm  小项id数组
     * @author [李勇] [peis999]
     */
    public function addZhxmDt($zhxmid,$param)
    {

        Db::startTrans();
        try{

            $ysztZhxm=Model('YsztModel')->where('zhxmid',$zhxmid)->select();

            if(!empty($ysztZhxm)) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'项目已被登记引用不可编辑小项'];
            }

            $flag = $this->saveAll($param,false);

            if ($flag==true) {

               // $jg=Model('TjxmModel')->alias('tjxm')->join('zhxm_dt dt','tjxm.id=dt.tjxmid and dt.zhxmid='.$zhxmid)->sum('dj');
               // Model('ZhxmModel')->where('id',$zhxmid)->setField('jg',$jg);
                db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】组合项目('.$zhxmid.')添加小项成功)', 1);
                return ['code' => 1, 'data' => '', 'msg' => '组合项目添加体检项目成功'];
            } else {
                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】组合项目('.$zhxmid.')添加小项失败)', 2);
                return ['code' => 0, 'data' => '', 'msg' => '组合项目添加体检项目失败'];
            }

        }catch(PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }


    }


    /**
     *  delTjxm  删除组合体检项目小项
     * @param $id $name
     */


    //删除套餐多个组合项目


    public function delZhxmDt($zhxmid,$tjxmids)
    {
        Db::startTrans();
        try {

            $ysztZhxm=Model('YsztModel')->where('zhxmid',$zhxmid)->select();

            if(!empty($ysztZhxm)) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'项目已被登记引用不可编辑小项'];
            }


            $result = $this->where('zhxmid', $zhxmid)->whereIn('tjxmid',$tjxmids)->delete();

            if ($result == false)
            {
                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】组合项目('.$zhxmid.')删除小项失败)', 2);
                return ['code' => 0, 'data' => '', 'msg' => '组合项目删除体检项目失败'];
            }else{

               // $jg=Model('TjxmModel')->alias('tjxm')->join('zhxm_dt dt','tjxm.id=dt.tjxmid and dt.zhxmid='.$zhxmid)->sum('dj');
               // Model('ZhxmModel')->where('id',$zhxmid)->setField('jg',$jg);
                db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】组合项目('.$zhxmid.')删除小项成功)', 1);
                return ['code' => 1, 'data' => '', 'msg' => '组合项目删除体检项目成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



}