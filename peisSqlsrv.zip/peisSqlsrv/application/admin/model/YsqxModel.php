<?php
namespace app\admin\model;
use think\Db;
use think\exception\PDOException;
use think\Model;
class YsqxModel extends Model{

    protected $name="department_auth";



//批量人员科室授权
    public function depMulAuthEdit($param,$jobnum)
    {
        Db::startTrans();
        try {


                $this->whereIn('jobnum',$jobnum)->delete();
                $result = $this->saveAll($param);  //update不验证
                if (false === $result) {
                    Db::rollback();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】批量编辑人员科室权限失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                } else {
                    Db::commit();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】批量编辑人员科室权限成功',1);
                    return ['code' => 1, 'data' => '', 'msg' => '批量编辑人员科室权限成功'];
                }


        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


//单个授权
    public function depAuthEdit($param,$jobnum)
    {
        Db::startTrans();
        try {



            $this->where('jobnum',$jobnum)->delete();
            if (!empty($param)) {
                $result = $this->saveAll($param);  //update不验证

                if (false === $result) {
                    Db::rollback();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量编辑工号(' . $jobnum . ')科室权限失败', 2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                }

            }

            Db::commit();
            writelog(session('uid'), session('username'), '用户【' . session('username') . '】批量编辑工号(' . $jobnum . ')科室权限成功', 1);
            return ['code' => 1, 'data' => '', 'msg' => '批量编辑工号(' . $jobnum . ')科室权限成功'];

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

}