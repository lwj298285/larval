<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Collection;
use think\Validate;
class TjzdbModel extends Model
{
//体检项目表名不带前缀

    protected $name = "tjzdb";






}