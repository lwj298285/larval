<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 15:51
 */

namespace app\admin\model;
use think\Db;
use think\exception\PDOException;
use think\Model;
use think\Validate;

class ZhxmhsModel extends Model
{
    protected $name = "zhxmhs";


//组合项目函数，组合条件产生诊断

/**

zhxmhsEdit 编辑根据组合项目条件产生诊断
 **/
    public function zhxmhsEdit($param)
    {
      //  Db::startTrans();
     try{
         $validate = new Validate([
             ["zhcondtion","unique:zhxmhs,zhcondtion={$param['zhcondtion']}&isdel=1&zhxmid={$param['zhxmid']}&hospitalid={$param['hospitalid']}","组合项目函数条件已存在",]
         ]);

         if (empty($param['sfyx']))
             $param['sfyx']=0;
         if (empty($param['jrxj']))
             $param['jrxj']=0;


         if(!empty($param['id'])){


             $result=$validate->check($param);

             if($result==false){
                // Db::rollback();
                // writelog(session('uid'),session('username'),'编辑系统【'.$param['mc'].'】参数失败',2);
                 return ['code'=>0,'data'=>'','msg' => $validate->getError()];
             }else{
                 //Db::commit();
                 if (empty($param['sfyx']))
                     $param['sfyx']=0;
                 if (empty($param['jrxj']))
                     $param['jrxj']=0;

                 $result=$this->save($param,['id'=>$param['id'],'hospitalid'=>$param['hospitalid']]);
                 if (false == $result) {
                     writelog(session('uid'),session('username'),'编辑组合项目函数zhxmid='.$param['zhxmid'].',id='.$param['id'].'失败'.$this->getError(),2);
                     return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                 }else {

                     writelog(session('uid'), session('username'), '编辑组合项目函数zhxmid='.$param['zhxmid'].',id='.$param['id'].'成功', 1);
                     return ['code' => 2, 'data' => $param['id'], 'msg' => '编辑组合项目函数成功'];
                 }
             }

         }else{

             $id=$this->where('hospitalid',$param['hospitalid'])->max('id');
             $param['id']=empty($id) ? 1:$id+1;
             $result=$validate->check($param);


             if($result==false){
                // Db::rollback();
                 //writelog(session('uid'),session('username'),'添加系统参数【'.$param['mc'].'】失败',2);
                 return ['code'=>0,'data'=>'','msg' =>$validate->getError()];
             }else{
                 //Db::commit();
                 $result=$this->save($param);
                 if (false === $result) {
                     writelog(session('uid'),session('uesrname'),'添加组合项目函数zhxmid='.$param['zhxmid'].',id='.$param['id'].'失败'.$this->getError(),2);
                     return ['code'=>0,'data'=>'','msg'=>$this->getError()];
                 }else {

                     writelog(session('uid'),session('uesrname'),'添加组合项目函数zhxmid='.$param['zhxmid'].',id='.$param['id'].'成功',1);
                     return ['code'=>1,'data'=>$param['id'],'msg'=>'添加组合项目函数成功'];
                 }

             }
         }

     }catch (PDOException $e){
         //Db::rollback();
      return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];

     }
    }




}