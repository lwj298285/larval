<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use traits\model\SoftDelete;
use think\Validate;

class EditorModel extends Model
{
//套餐设置表名不带前缀
    protected $name = "form";
    use SoftDelete;
    protected $deletetime = 'delete_time';
    protected $autoWriteTimestamp = true;


    public function templeEdit($param){


        if (empty($param['formid'])){ //新增

            $param['formid']=$this->where('hospitalid',session('hospitalid'))->max('formid');
            $param['formid']=empty( $param['formid'])?1: $param['formid']+1;
            $param['hospitalid']=session('hospitalid');
            $this->allowField(true)->insert($param);

        }else{ //编辑


        }

    }


}