<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;
class XjjyModel extends Model
{
//体检项目常见结果建议表名不带前缀
    protected $name = "xjjy";







    /**
     * [ editTjxm参数【判断是新增还是更新 诊断建议]
     * @author [李勇] [peis999]
     */
    public function editXjjy($param)
    {

        Db::startTrans();
        try {



            $validate = new Validate([
                ['zyzd', 'require', '主要诊断不能为空'],
                ['jymc', 'require', '建议名称不能为空'],
                ["zyzd", "unique:xjjy,zyzd={$param['jymc']}&tjlxid={$param['tjlxid']}&isdel=1", "诊断建议已存在"]

            ]);

            $param['jynr']=textAreaStr($param['jynr']);
            $param['explain']=textAreaStr($param['explain']);
            $param['yxjs']=textAreaStr($param['yxjs']);


            if (!empty($param['id'])) { //更新

                $check=$validate->check($param);
                if (false === $check) {
                    return ['code' => 0, 'data' => '', 'id' => $param['id'], 'msg' => $validate->getError()];
                }else {
                    $result = $this->allowField(true)->save($param, ['id' => $param['id']]);  //update不验证
                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑诊断建议失败', 2);
                        return ['code' => 0, 'data' => '', 'id' => $param['id'], 'msg' => $this->getError()];

                    } else {

                        Db::commit();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑诊断建议成功', 1);
                        return ['code' => 1, 'data' => '', 'id' => $param['id'], 'msg' => '编辑诊断建议成功'];
                    }
                }

            } else { //新增

                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $check=$validate->check($param);

                if (false ===$check) {
                    return ['code' => 0, 'data' => '','id'=>'', 'msg' => $validate->getError()];
                }else{
                    $result = $this->allowField(true)->save($param);  //insert 不验证

                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】添加诊断建议失败',2);
                        return ['code' => 0, 'data' => '','id' => '', 'msg' => $this->getError()];
                    } else {
                        Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】添加诊断建议成功',1);
                        return ['code' => 1, 'data' => '','id'=> $param['id'],'msg' => '添加诊断建议成功'];
                    }
                }



            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '','id' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delTjxm  删除体检项目
     * @param $id $name
     */





    public function delXjjy($id,$zyzd,$jymc)
    {
        Db::startTrans();
        try{


            $result=$this->where('id',$id)->setField('isdel',0);

            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除诊断建议' . $zyzd.'-'.$jymc . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除诊断建议失败'];
            }else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除诊断建议'  . $zyzd.'-'.$jymc .  '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除诊断建议成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


}