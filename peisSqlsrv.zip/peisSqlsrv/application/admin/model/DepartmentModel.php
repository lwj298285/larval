<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class DepartmentModel extends Model
{
    protected $name = 'department';

    /**
     * 根据搜索条件获取科室列表信息
     */
    public function getDepartmentsByWhere($map, $Nowpage, $limits)
    {
        return $this->where($map)->page($Nowpage, $limits)->order('sortid')->select();

    }


    /**
     * 根据搜索条件获取所有的科室数量
     * @param $where
     */
    public function getAllDepartments($where)
    {
        return $this->where($where)->count();
    }

    // 其他地方调用有用的体检类型
    public function getDepartments()
    {
        return $this->field('id as depid ,depname,deptype,sortid')
                     ->where(['isdel&status'=>1])
                     ->order('sortid')
                     ->select();
    }


    /**
     * 插入分院信息
     * @param $param
     */
    public function insertDepartment($param)
    {
        try{
			
			$param['id']=($this->max('id'));
			$param['id']=empty($param['id'])?1:$param['id']+1;
            $result = $this->validate('DepartmentValidate')->save($param);
			
            if(false === $result){
                writelog(session('uid'),session('username'),'体检科室【'.$param['depname'].'】添加失败',2);
                return ['code' => -1, 'data' => '', 'msg' => $this->getError()];
            }else{
                writelog(session('uid'),session('username'),'体检科室【'.$param['depname'].'】添加成功',1);
                return ['code' => 1, 'data' => '', 'msg' => '添加体检类科室成功'];
            }
        }catch( PDOException $e){
            return ['code' => -2, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * 编辑科室信息
     * @param $param
     */
    public function editDepartment($param)
    {
        try{
             if(!isset($param['showranger']))
                 $param['showranger']=0;

             if(!isset($param['showtable']))
                 $param['showtable']=0;

            $result =  $this->validate('DepartmentValidate')->save($param, ['id' => $param['id']]);
            if(false === $result){
                writelog(session('uid'),session('username'),'体检类型【'.$param['depname'].'】编辑失败',2);
                return ['code' => 1, 'data' => '', 'msg' => '编辑体检科室失败'];
            }else{
                writelog(session('uid'),session('username'),'体检类型【'.$param['depname'].'】编辑成功',1);
                return ['code' => 1, 'data' => '', 'msg' => '编辑体检科室成功'];
            }
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    /**
     * 根据医院id获取医院信息
     * @param $id
     */
    public function getOneDepartment($id)
    {
        return $this->where('id', $id)->find();
    }


    /**
     * 删除医院
     * @param $id
     */
    public function delDepartment($id)
    {   
	    Db::startTrans();
        try{

            if (Model('TjxmModel')->where(['tjlxid'=>$id,'isdel'=>1])->find()){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => '体检科室已被体检项目引用，不可删除'];

            }

            if (Model('ZhxmModel')->where(['tjlxid'=>$id,'isdel'=>1])->find()){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => '体检科室已被组合项目引用，不可删除'];

            }

            $result=$this->where('id', $id)->setfield('isdel',0);
            //Db::name('admin')->where('hospitalid', $id)->delete();
			//Db::name('hospital_department')->where('hospitalid', $id)->delete();
            if ($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检科室失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检科室成功'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检科室成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检科室成功'];
            }

        }catch( PDOException $e){
			Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
	
	
	
	//定义表关联
	
}