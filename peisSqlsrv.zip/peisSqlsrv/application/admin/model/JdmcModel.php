<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;

class JdmcModel extends Model
{
//临床类型
    protected $name = "jdmc";


    /**
     * [getOneLclx 获取临床类型节点数据]
     * @author [李勇] [peis999]
     */
        public function getOneJdmc($id)
    {
        return $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->select();
    }


    /**
     * [ editLclx参数【判断是新增还是更新 临床类型]
     * @author [李勇] [peis999]
     */
    public function editJdmc($param)
    {

        try {

            $validate = new Validate([
                ["mc","unique:jdmc,mc={$param['mc']}&hospitalid=".session('hospitalid')."&isdel=1","街道名称(".$param['mc'].")已存在",]
            ]);

            if (!empty($param['id'])) { //更新
                $result=$validate->check($param);

                if (false === $result) {
                   // writelog(session('uid'),session('uesrname'),'编辑街道名称['. $param['mc'] .']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param,['id'=>$param['id'],'hospitalid'=>session('hospitalid')]);  //update不验证
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'编辑街道名称['. $param['mc'] .']失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    }else {
                        writelog(session('uid'),session('uesrname'),'编辑街道名称['. $param['mc'] .']成功',2);
                        return ['code' => 1, 'data' => '', 'msg' => '编辑街道名称' . $param['mc'] . '成功'];
                    }
                }

            } else { //新增
                $id = $this->where('hospitalid',session('hospitalid'))->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];
                $param['hospitalid'] = session('hospitalid');

                $result=$validate->check($param);
                if (false === $result) {
                    //writelog(session('uid'),session('uesrname'),'新增街道名称['. $param['mc'] .']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param); //update不验证
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'新增街道名称['. $param['mc'] .']失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    }else {
                        writelog(session('uid'),session('uesrname'),'新增街道名称['. $param['mc'] .']成功',1);
                        return ['code' => 1, 'data' => '', 'msg' => '新增街道名称' . $param['mc'] . '成功'];
                    }
                }

               //insert 不验证


            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * delLclx  删除服务行业
     * @param $id $name
     */
    public function delJdmc($id,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where('id',$id)->setField('isdel',0);
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除街道名称' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除街道名称失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除街道名称' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除街道名称成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    //   调整服务行业排序
    public function editSoft($id,$type,$targetid)
        {
            Db::startTrans();
            try{

                $softId=$this->where('id',$id)->value('softid');
                $targerSoftId=$this->where('id',$targetid)->value('softid');
               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

                if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];

                $map['hospitalid']=['=',session('hospitalid')];

                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整街道名称排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}