<?php

namespace app\admin\model;
use think\exception\PDOException;
use think\Model;
use traits\model\SoftDelete;
use think\Db;
class TjdjviewModel extends Model
{
   public $cusSetField="",$userHaveField="";
    protected $name = 'tjdjbview';
    use SoftDelete;
    protected $deletetime = 'delete_time';





public function  getNlAttr($value)
{
    if (is_int(strpos($this->cusSetField,'nl')) &&  !is_int(strpos($this->userHaveField,'nl'))) {
        if (empty($value))
            return "";
         else
            return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
    }else {
        return $value;
    }
}

 public function  getHyzkAttr($value)
    {

        if (is_int(strpos($this->cusSetField,'hyzk')) &&  !is_int(strpos($this->userHaveField,'hyzk'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //

        } else {
            return $value;
        }
    }

    public function  getMobileAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'mobile')) &&  !is_int(strpos($this->userHaveField,'mobile'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        }else {
            return $value;
        }
    }

    public function  getPhoneAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'phone')) &&  !is_int(strpos($this->userHaveField,'phone'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        }else {
            return $value;
        }
    }


    public function  getAddressAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'address')) &&  !is_int(strpos($this->userHaveField,'address'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        }else {
            return $value;
        }
    }



    public function  getEmailAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'email')) &&  !is_int(strpos($this->userHaveField,'email'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        }else {
            return $value;
        }
    }


    public function  getDwnameAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'dwname')) &&  !is_int(strpos($this->userHaveField,'dwname'))) {
            if (empty($value))
                return "";
            else
               return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        } else {
            return $value;
        }
    }


    public function  getZwAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'zw')) &&  !is_int(strpos($this->userHaveField,'zw'))) {
            if (empty($value))
                return "";
            else
               return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        }else {
            return $value;
        }
    }

    public function  getSfzhAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'sfzh')) &&  !is_int(strpos($this->userHaveField,'sfzh'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        } else {
            return $value;
        }
    }

    public function  getZcAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'zc')) &&  !is_int(strpos($this->userHaveField,'zc'))) {
            if (empty($value))
                return "";
            else
                 return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        } else {
            return $value;
        }
    }


public function  getCsnyrAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'csnyr')) &&  !is_int(strpos($this->userHaveField,'csnyr'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        } else {
            return $value;
        }

    }
 //数据集无法用获取器 只能循环转为对象才能调用获取器
    public function  getXmAttr($value)
    {
        if (is_int(strpos($this->cusSetField,'xm')) &&  !is_int(strpos($this->userHaveField,'xm'))) {

            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //
        }else {
            return $value;
        }


    }


    public function  getSv_emailAttr($value)
    {

        if (is_int(strpos($this->cusSetField,'sv_email')) &&  !is_int(strpos($this->userHaveField,'sv_email'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //

        } else {
            return $value;
        }
    }

    public function  getSv_mobileAttr($value)
    {

        if (is_int(strpos($this->cusSetField,'sv_mobile')) &&  !is_int(strpos($this->userHaveField,'sv_mobile'))) {
            if (empty($value))
                return "";
            else
                return '***';//strpos($this->cusSetField,'xm').'-'.strpos($this->userHaveField,'xm'); //

        } else {
            return $value;
        }
    }

    //定义不存在的表中的字段用于存放当前操作员可看加密字段和体检人员的加密字段
    public function  getCusSetFieldAttr($value)
    {

        return $value;

    }

    public function  getUserHaveFieldAttr($value)
    {
        return $value;
    }




}