<?php
namespace app\admin\model;
use think\Model;
use think\Validate;
use traits\model\SoftDelete;
use think\Db;

class IdcardModel extends Model
{
    protected $name = 'card';
    use SoftDelete;
    protected $deletetime = 'delete_time';
    /**
     * insertCard 新增会员卡
     * @param $param
     */
    public function insertCard($param){

        try {
            Db::startTrans();
            $param['delete_time']=['exp','is null'];
            $validate = new Validate([
                ["cardnum","unique:card,cardnum^hospitalid^delete_time","会员卡(".$param['cardnum'].")已存在",]
            ]);

            $result=$validate->check($param);

            if($result===false){
                Db::rollback();
                return ['code' => 0,'data'=>'','msg' => $validate->getError()];
            }else{

                unset($param['delete_time']);
                $result = $this->allowField(true)->save($param,false);

                if($result === false){
                    Db::rollback();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】添加会员卡（'.$param['cardnum'].'）失败',2);

                    return ['code' => 0,'data'=>'','msg' => $this->getError()];
                }else{
                    Db::commit();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】添加会员卡（'.$param['cardnum'].'）成功',1);

                    return ['code' => 1,'data'=>'','msg' => '添加会员卡成功'];
                }


            }


        }catch(PDOException $e){
            Db::rollback();
            return ['code' => 0,'data'=>'','msg' => $e->getMessage()];
        }
   }

//删除
    public function delCard($cardnum){

        try{
            Db::startTrans();
            $result = $this->where(['cardnum'=>$cardnum,'hospitalid'=>session('hospitalid')])->delete();

            if($result === false)
                throw new \Exception();

            Db::commit();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】销卡（'.$cardnum.'）成功',1);
            return ['code' => 1, 'data' => '', 'msg' => '销卡成功'];

        }catch(\Exception $e){
            Db::rollback();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】销卡（'.$cardnum.'）失败',2);
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //换卡
    public function changeCard($param){

        try{
            Db::startTrans();

            $param['delete_time']=['exp','is null'];
            $param['cardnum']=$param['newvalue'];
            $param['hospitalid']=session('hospitalid');

            $validate = new Validate([
                ["cardnum","unique:card,cardnum^hospitalid^delete_time","会员卡(".$param['cardnum'].")已存在",]
            ]);

            $result=$validate->check($param);

            if($result===false){
                Db::rollback();
                return ['code' => 0,'data'=>'','msg' => $validate->getError()];
            }else {

                $result = $this->where(['cardnum' => $param['oldvalue'], 'hospitalid' => $param['hospitalid']])->setField('cardnum', $param['newvalue']);

                if ($result === false)
                    throw new \Exception();

                Db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】换卡（' . $param['oldvalue'] . '->' . $param['newvalue'] . '）成功', 1);
                return ['code' => 1, 'data' => '', 'msg' => '换卡成功'];
            }

        }catch(\Exception $e){
            Db::rollback();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】换卡（'.$param['oldvalue'].'->'.$param['newvalue'].'）失败',2);
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



//编辑
    public function editCard($param){
        try{

            Db::startTrans();
          /*  $param['delete_time']=['exp','is null'];


            $validate = new Validate([
                ["cardnum","unique:card,cardnum^hospitalid^delete_time,{$param['cardnum']},cardnum","会员卡(".$param['cardnum'].")已存在",]
            ]);


            $result=$validate->check($param);

            if($result===false){
                Db::rollback();
                return ['code' => 0,'data'=>'','msg' => $validate->getError()];
            }else {
                unset($param['delete_time']);*/
            $result = $this->allowField(true)->save($param, ['cardnum' => $param['cardnum'], 'hospitalid' => session('hospitalid')]);

            if ($result === false) {
                Db::rollback();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑会员卡（'.$param['cardnum'].'）失败',2);
                return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
            } else {
                Db::commit();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑会员卡（'.$param['cardnum'].'）成功',1);
                return ['code' => 1, 'data' => '', 'msg' => '编辑会员卡成功'];
            }
           // }
        }catch(PDOException $e){
            Db::rollback();
            return ['code' => 0,'data'=>'','msg' => $e->getMessage()];
        }
    }
}