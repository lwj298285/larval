<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class TjtcDtModel extends Model
{
//体检套餐明细表
    protected $name = "tjtc_dt";

//删除套餐单个组合项目
    public function delSelZhxm($tcid, $zhxmid, $name)
    {
        Db::startTrans();
        try {



            $result = $this->where(['tcid' => $tcid, 'zhxmid' => $zhxmid,'hospitalid'=>session('hospitalid')])->delete();

            if ($result == false) {
                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除个人套餐组合项目' . $name . '失败(ID=' . $tcid . '-' . $zhxmid . ')', 2);
                return ['code' => 0, 'data' => '', 'msg' => '移除套餐组合项目失败'];
            } else {
                $jg=$this->getTcjg($tcid);
                //更新分组套餐价格，如果是打折套餐并且审核过设置未未审核
                Model('TjtcModel')->where(['id'=>$tcid,'hospitalid'=>session('hospitalid')])
                    ->update(['jg'=>$jg,'sfsh'=>['exp','case sfsh when 1 then 0 else 0 end']]);

                Db::execute('exec  SP_Tjtczk '.session('hospitalid').','. $tcid);

                Db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除个人套餐组合项目' . $name . '成功(ID=' . $tcid . '-' . $zhxmid . ')', 1);
                return ['code' => 1, 'data' => $jg, 'msg' => '移除套餐组合项目成功'];
            }

        } catch (PDOException $e) {
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //删除套餐多个组合项目
    public function delMulZhxm($tcid,$zhxmids)
    {
        Db::startTrans();
        try {



            $result = $this->where(['tcid'=>$tcid,'hospitalid'=>session('hospitalid')])->whereIn('zhxmid',$zhxmids)->delete();

           // $logstr=arr2str($param);
            if ($result == false) {
                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除个人套餐多个组合项目失败('.$tcid.'-'.$zhxmids.')', 2);
                return ['code' => 0, 'data' => '', 'msg' => '移除套餐多个组合项目失败'];
            } else {
                $jg=$this->getTcjg($tcid);
                Model('TjtcModel')->where(['id'=>$tcid,'hospitalid'=>session('hospitalid')])
                    ->update(['jg'=>$jg,'sfsh'=>['exp','case sfsh when 1 then 0 else 0 end']]);

                Db::execute('exec  SP_Tjtczk '.session('hospitalid').','. $tcid);
                Db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除个人套餐多个组合项目成功('.$tcid.'-'.$zhxmids . ')', 1);
                return ['code' => 1, 'data' => $jg, 'msg' => '移除套餐组多个合项目成功'];
            }

        } catch (PDOException $e) {
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }





    //更新折扣个人套餐组合项目价格
    public function zhxmjgEdit($tcid,$zhxmdata)
    {



        try {


            Model('TjtcModel')->where(['id'=>$tcid,'hospitalid'=>session('hospitalid')])->setField('sfsh',0);


            foreach ($zhxmdata as $k=>$v){
                $result=$this->where(['hospitalid'=>session('hospitalid'),'tcid'=>$tcid,'zhxmid'=>$v['zhxmid']])->setfield('jg',$v['jg']);

                if ($result==false){

                    return ['code' => 0, 'data' => '', 'msg' => $this->getMessage()];
                }
            }



            writelog(session('uid'), session('username'), '用户【' . session('username') . '】修改个人套餐组合项目价格成功('. session('hospitalid').'-'. $tcid . ')', 1);
            return ['code' => 1,'data'=>'' , 'msg' => '修改套餐组合项目价格成功'];


        } catch (PDOException $e) {
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    //获取套餐所有组合项目价格和  ===套餐原价
    public function getTcjg($tcid)
    {
        $jg= $this->alias('dt')->join('zhxm_hd hd','dt.zhxmid=hd.id')->where(['tcid'=>$tcid,'hospitalid'=>session('hospitalid')])->sum('hd.jg');
        return empty($jg)?0:$jg;

    }



}