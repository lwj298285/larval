<?php
namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;
class JbzdModel extends Model{
    //基本字段
    protected $name='jbzd';

    /**
     * @param $id
     * @return array|false|\PDOStatement|string|Model
     */
public function getOneJbzd($id,$dictype){
    return $this->where(['dictype'=>$dictype,'id'=>$id])->find();
}

public function getAllJbzd($dicType){

    $where['isdel']=['=',1];

    if (!empty($dicType))
        $where['dictype']=['=',$dicType];

    return $this->where($where)->order('dictype,id','asc')->select();
}




    /**
     * @param $param
     * @return array
     */
    public function editJbzd($param)
    {


        //双引号可以直接使用变量

        $validate = new Validate([
            ["name","unique:jbzd,name={$param['name']}&dictype={$param['dictype']}&isdel=1,{$param['id']},id","基本字典名称已存在",]
       ]);



        try {
            if (!empty($param['id'])) { //更新
               // $result = $this->validate($validate)->save($param,['id'=>$param['id'],'dictype'=>$param['dictype']]);  //update不验证
                $result=$validate->check($param);

                if (false === $result) {
                   // writelog(session('uid'),session('uesrname'),'编辑基本字典['.$param['name'].']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $this->save($param,['id'=>$param['id'],'dictype'=>$param['dictype']]);
                    if (false ===$result) {
                        writelog(session('uid'),session('uesrname'),'编辑基本字典['.$param['name'].']失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        writelog(session('uid'),session('uesrname'),'编辑基本字典['.$param['name'].']成功',1);
                        return ['code' => 2, 'data' =>$param, 'msg' => '编辑基本字典' . $param['name'] . '成功'];
                    }

                }

            } else { //新增
                $id = $this->where('dictype',$param['dictype'])->max('id');
                $param['id'] = empty($id) ? 1 : $id+1;
                $param['softid'] = $param['id'];
                $result =$validate->check($param); //insert 不验证
              //  $result = $this->validate('JbzdValidate')->insert($param);  //insert 不验证
                if (false ===$result) {
                    //writelog(session('uid'),session('uesrname'),'新增基本字典['.$param['name'].']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $this->save($param);
                    if (false ===$result) {
                        writelog(session('uid'),session('uesrname'),'新增基本字典['.$param['name'].']失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        writelog(session('uid'),session('uesrname'),'新增基本字典['.$param['name'].']成功',1);
                        return ['code' => 1, 'data' => $param , 'msg' => '新增基本字段' . $param['name'] . '成功'];
                    }

                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * @param $id
     * @param $name
     * @return array
     */
    public function delJbzd($id,$name,$dictype)
    {
        Db::startTrans();
        try{

            $result=$this->where(['id'=>$id,'dictype'=>$dictype])->setField('isdel',0);
            if($result==false) {
                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除基本字段'.$name.'失败(ID='.$id.')',2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除基本字段失败'];
            }else{

                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除基本字段'.$name.'成功(ID='.$id.')',1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除基本字段成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * @param $id
     * @param $type
     * @param $targetid
     * @return array
     */
    public function editSoft($id,$dictype,$type,$targetid)
    {
        Db::startTrans();
        try{

          //  $map=[];
            $map=['dictype'=>$dictype];
            $where=['dictype'=>$dictype,'id'=> $id];
            $softId=$this->where('id',$id)->value('softid');
            $targerSoftId=$this->where('id',$targetid)->value('softid');
            // $softId=$this->field('softid')->get($id);
            // $targerSoftId=$this->field('softid')->get($targetid);

            /*if ($softId >$targerSoftId)
                $map['softid']=['between',$targerSoftId.','. $softId];
            else
                $map['softid']=['between',$softId.','.$targerSoftId];*/

            //$map['softid']=['between','lt,gt'];

            if ($type=="prev") {

                if ($softId >$targerSoftId)
                {
                    $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                    $this->where($map)->setInc('softid');
                    $this->where($where)->setField('softid', $targerSoftId);
                } else{
                    $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                    $this->where($map)->setDec('softid');
                    $this->where($where)->setField('softid', $targerSoftId-1);
                }


            }else{

                if ($softId >$targerSoftId)
                {
                    $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                    $this->where($map)->setInc('softid');
                    $this->where($where)->setField('softid', $targerSoftId+1);
                } else{
                    $map['softid']=['between',($softId+1).','.$targerSoftId];
                    $this->where($map)->setDec('softid');
                    $this->where($where)->setField('softid', $targerSoftId);
                }

            }

            Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '调整基本字段排序成功'];

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
}