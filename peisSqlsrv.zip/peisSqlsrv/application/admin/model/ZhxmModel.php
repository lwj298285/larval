<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;
class ZhxmModel extends Model
{
//组合项目表名不带前缀
    protected $name = "zhxm_hd";


    /**
     * [getOneZhxm获取组合体检项目节点数据]
     * @author [李勇] [peis999]
     */
    public function getOneZhxm($id)
    {
        return $this->find($id);
    }


    /**
     * [ editTjxm参数【判断是新增还是更新 组合体检项目]
     * @author [李勇] [peis999]
     */
    public function editZhxm($param)
    {


        try {

            Db::startTrans();


           /* if(empty($param['lclxid'])){
                unset($param['lclxid']);*/
                $validate = new Validate([
                    ["mc","unique:zhxm_hd,mc={$param['mc']}&tjlxid={$param['tjlxid']}&isdel=1","组合项目(".$param['mc'].")已存在",]
                ]);
           /* }else{
                $validate = new Validate([
                    ["mc","unique:zhxm_hd,mc={$param['mc']}&tjlxid={$param['tjlxid']}&lclxid={$param['lclxid']}&isdel=1","组合项目(".$param['mc'].")已存在",]
                ]);

            }*/


            if(empty($param['sglbbh']))
                $param['sglbbh']=null;

            if(empty($param['sgggbh']))
                $param['sgggbh']=null;


            if(empty($param['bblx']))
                $param['bblx']=null;

            if(empty($param['zdzk']))
                $param['zdzk']=null;

            if(empty($param['sfdz']))
                $param['sfdz']=0;


            if (!empty($param['id'])) { //更新

               /* if(Model('TjjlbModel')->find(['zhxmid'=>$param['id']])) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' =>'项目已被引用不可编辑'];
                }*/

               if(!isset($param['status']))
                    $param['status']=0;

                if(!isset($param['sfxybb']))
                    $param['sfxybb']=0;


                if(!isset($param['sfwbxm']))
                    $param['sfwbxm']=0;

                $result=$validate->check($param);
                if (false === $result) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {


                    $currzhxm=$this->get($param['id']);


                    //组合项目原价格发送改变 更新 分组套餐和 个人套餐价格。
                    if ($currzhxm->sfdz!=$param['sfdz'] || floatval($currzhxm->jg)!=floatval($param['jg']) || floatval($currzhxm->zdzk)!=floatval($param['zdzk'])){


                        if (floatval($currzhxm->jg)!=floatval($param['jg'])){
                            //分组套餐价格更新,打折分组套餐为未审核状态

                            Db::execute(' update hd set hd.jg=hd.jg-' . $currzhxm->jg . '+' . $param['jg'] . ' ,sfsh= case sfsh when 1 then 0 else 0 end'
                                . ' from peis_dwfz_hd as hd, peis_dwfz_tc as tc'
                                . ' where hd.hospitalid=tc.hospitalid and hd.dwid=tc.dwid and hd.id=tc.fzid and tc.zhxmid=' . $param['id']);


                            //个人套餐价格更新，打折个人套餐为未审核状态

                            Db::execute(' update hd set hd.jg=hd.jg-'.$currzhxm->jg.'+'.$param['jg'].' ,sfsh= case sfsh when 1 then 0 else 0 end'
                                                        .' from peis_tjtc_hd as hd, peis_tjtc_dt as dt'
                                                        .' where hd.hospitalid=dt.hospitalid  and hd.id=dt.tcid and dt.zhxmid='.$param['id']);
                        }

                        //更新组合项目
                        $currzhxm->allowField(true)->update($param);


                        //重新分配打折分组套餐组合项目价格
                        $zkdwfz= Db::query(' select hd.* from peis_dwfz_hd as hd, peis_dwfz_tc as tc '
                                             .' where hd.hospitalid=tc.hospitalid and hd.dwid=tc.dwid and hd.id=tc.fzid  '
                                             .' and hd.zk is not null and  hd.zkhjg  is not null and tc.zhxmid='.$param['id']);


                        foreach ($zkdwfz as $k=>$v){

                            Db::execute('exec  SP_Dwfzzk ' . $v['hospitalid']. ',' . $v['dwid'] . ',' . $v['id']);


                        }



                        //重新分配打折个人套餐组合项目价格
                        $zkgrtc= Db::query(' select hd.*  from peis_tjtc_hd as hd, peis_tjtc_dt as dt '
                                           .' where hd.hospitalid=dt.hospitalid and hd.id=dt.tcid '
                                           .' and hd.zk  is not null and  hd.zkhjg  is not null and dt.zhxmid='.$param['id']);


                        foreach ($zkgrtc as $k=>$v){

                            Db::execute('exec  SP_Tjtczk ' . $v['hospitalid'].  ',' . $v['id']);


                        }



                    }else{

                       $currzhxm->allowField(true)->update($param);

                    }



                    Db::commit();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑组合项目' . $param['mc'] . '成功(ID=' . $param['id'] . ')', 1);
                    return ['code' => 2, 'data' => $param, 'msg' => '编辑组合项目' . $param['mc'] . '成功'];

                }

            } else { //新增




                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;

                //因为检验科条码128c为偶数问题 医院  + 登记流水号  + 组合项目 必须为偶数 各个单项也设成偶数
              /*  if (empty($id))
                    $param['id']=10;
                else if(strlen($id+1)%2==0)
                    $param['id']=$id+1;
                else
                    $param['id']=($id+1)*10;*/



                $param['softid'] = $param['id'];

                $result=$validate->check($param);


                if (false === $result) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->allowField(true)->save($param);  //insert 不验证
                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加组合项目' . $param['mc'] . '失败(ID=' . $param['id'] .$this->getError(). ')', 2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        Db::commit();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加组合项目' . $param['mc'] . '失败(ID=' . $param['id'] . ')', 1);
                        return ['code' => 1, 'data' => $param, 'msg' => '添加组合项目' . $param['mc'] . '成功'];
                    }
                }
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delTjxm  删除组合体检项目
     * @param $id $name
     */
    public function delZhxm($id,$name)
    {
        Db::startTrans();
        try{

            if(!empty(Model('TjjlbModel')->where('zhxmid',$id)->select())) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'组合项目已被登记引用不可删除'];
            }



            if((Model('TjtcModel')->alias('hd')
                    ->join('tjtc_dt dt','hd.id=dt.tcid ','left')
                    ->where('zhxmid',$id)
                    ->count())>0){
                return ['code' => 0, 'data' => '', 'msg' =>'组合项目已被套餐引用不可删除'];
            }

           /* if(!empty(Model('TjtcDtModel')->where('zhxmid',$id)->select())) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'组合项目已被套餐引用不可删除'];
            }*/

           /* if(!empty(Model('DwfzDtModel')->where('zhxmid',$id)->select())) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'组合项目已被分组套餐引用不可删除'];
            }*/


            if((Model('DwfzModel')->alias('hd')
                    ->join('dwfz_tc dt','hd.id=dt.fzid ','left')
                    ->where('zhxmid',$id)
                    ->count())>0){
                return ['code' => 0, 'data' => '', 'msg' =>'组合项目已被分组套餐引用不可删除'];
            }

            $result=$this->where('id',$id)->setField('isdel',0);
            if($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除组合项目' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除组合项目' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //调整体检项目排序
        public function editSoft($tjlxid,$id,$type,$targetid)
        {
            Db::startTrans();
            try{


                $softId=$this->where('id',$id)->value('softid');

                $targerSoftId=$this->where('id',$targetid)->value('softid');
                $map['tjlxid']=['=',$tjlxid];


               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

               /* if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];

                //$map['softid']=['between','lt,gt'];
                */




                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整组合项目排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}