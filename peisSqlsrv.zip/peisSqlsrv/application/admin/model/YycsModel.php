<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 15:51
 */
namespace app\admin\model;
use think\Db;
use think\exception\PDOException;
use think\Model;
use think\Validate;

class YycsModel extends Model
{
    protected $name = "hospital_param";
    //添加及更新医院参数
    public function yycsEdit($param){
        // Db::startTrans();
        try{


            if(!empty($param['id'])){
                $validate = new Validate([
                    ["mc","unique:hospital_param,mc={$param['mc']}&isdel=1&hospitalid=".session('hospitalid').",{$param['id']},id","医院参数编码(".$param['mc'].")已存在",],
                    ["zwmc","unique:hospital_param,zwmc={$param['zwmc']}&isdel=1&hospitalid=".session('hospitalid').",{$param['id']},id","医院参数名称(".$param['zwmc'].")已存在",]
                ]);
                $result=$validate->check($param);
                if($result==false){
                    // Db::rollback();
                    writelog(session('uid'),session('username'),'编辑医院【'.$param['mc'].'】参数失败',2);
                    return ['code'=>0,'data'=>'','msg' => $validate->getError()];
                }else{
                    // Db::commit();
                    $result=$this->save($param,['id'=>$param['id'],'hospitalid'=>session('hospitalid')]);
                    if (false === $result) {
                        writelog(session('uid'),session('username'),'编辑医院【'.$param['mc'].'】参数失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    }else{
                        writelog(session('uid'), session('username'), '编辑医院【' . $param['mc'] . '】参数成功', 1);
                        return ['code' => 1, 'data' => '', 'msg' => '编辑医院' . $param['mc'] . '参数成功'];
                    }
                }
            }else{


                $validate = new Validate([
                    ["mc","unique:hospital_param,mc={$param['mc']}&isdel=1&hospitalid=".session('hospitalid'),"医院参数编码(".$param['mc'].")已存在",],
                    ["zwmc","unique:hospital_param,zwmc={$param['zwmc']}&isdel=1&hospitalid=".session('hospitalid'),"医院参数名称(".$param['zwmc'].")已存在",]
                ]);

                $id=$this->where('hospitalid',session('hospitalid'))->max('id');
                $param['id']=empty($id) ? 1:$id+1;
                $param['softid']=$param['id'];
                $param['hospitalid']=session('hospitalid');
                $param['isdel']=1;
                $result=$validate->check($param);
                // $result=$this->validate("YycsValidate")->check($param);
                if($result==false){
                    // Db::rollback();
                    writelog(session('uid'),session('username'),'添加医院参数【'.$param['mc'].'】失败',2);
                    return ['code'=>0,'data'=>'','msg' =>$validate->getError()];
                }else{
                    // Db::commit();
                    $result=$this->save($param);
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'添加医院参数['.$param['mc'].']失败'.$this->getError(),2);
                        return ['code'=>0,'data'=>'','msg'=>$this->getError()];
                    }else{
                        writelog(session('uid'),session('uesrname'),'添加医院参数['.$param['mc'].']成功',1);
                        return ['code'=>1,'data'=>'','msg'=>'添加医院参数'.$param['mc'].'成功'];
                    }
                }
            }
        }catch(PDOException $e){
            // Db::rollback();
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
        }
    }


    //删除医院参数
    public function delYycs($id){
        try{
            $result=$this->where(['id'=>$id,'isdel'=>1,'hospitalid'=>session('hospitalid')])->delete();
            if($result==false){
                writelog(session('uid'),session('username'),'删除医院参数失败',2);
                return ['code'=>0,'data'=>'','msg'=>'删除医院参数失败'];
            }else{
                writelog(session('uid'),session('username'),'删除医院参数成功',1);
                return ['code'=>1,'data'=>'','msg'=>'删除医院参数成功'];
            }
        }catch(PDOException $e){
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
        }
    }


    //排序
    public function editSoft($id,$targetid,$type){
        // Db::startTrans();
        try{
           $softId=$this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->value('softid');
           $targetSoftId=$this->where(['id'=>$targetid,'hospitalid'=>session('hospitalid')])->value('softid');
            if($type=="prev"){
                if($softId>$targetSoftId){
                    $map['softid']=['between',$targetSoftId.','.($softId-1)];
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setInc('softid');
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setField('softid',$targetSoftId);
                }else{
                    $map['softid']=['between',($softId+1).','.($targetSoftId-1)];
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setDec('softid');
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setField('softid',($targetSoftId-1));
                }
            }else{
                if($softId>$targetSoftId){
                    $map['softid']=['between',($targetSoftId+1).','.($softId-1)];
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setInc('softid');
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setField('softid',($targetSoftId+1));
                }else{
                    $map['softid']=['between',($softId+1).','.$targetSoftId];
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setDec('softid');
                    $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->setField('softid',$targetSoftId);
                }
            }
            // Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '调整医院参数排序成功'];
        }catch(PDOException $e){
            // Db::rollback();
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
        }
    }
}