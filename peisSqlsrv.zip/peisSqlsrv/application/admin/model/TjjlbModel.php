<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class TjjlbModel extends Model
{
    //体检组合项目
    protected $name = "tjjlb";

}