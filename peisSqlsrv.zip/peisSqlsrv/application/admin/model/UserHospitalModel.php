<?php

namespace app\admin\model;
use think\Model;
//use think\model\Merge;
use think\Db;
use think\Validate;
class UserHospitalModel extends Model
{
//体检项目常见结果表名不带前缀
    protected $name = "admin_hospital";


}