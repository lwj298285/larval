<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;

class UserType extends Model
{
    protected  $name = 'auth_group';

    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;

    /**
     * [getRoleByWhere 根据条件获取角色列表信息]
     * @author [李勇] 
     */
    public function getRoleByWhere($map, $Nowpage, $limits)
    {
        return $this->where($map)->page($Nowpage, $limits)->order('sortid asc')->select();
    }



    /**
     * [getRoleByWhere 根据条件获取所有的角色数量]
     * @author [李勇] [peis999]
     */
    public function getAllRole($where)
    {
        return $this->where($where)->count();
    }



    /**
     * [insertRole 插入角色信息]
     * @author [李勇] [peis999]
     */    
    public function insertRole($param)
    {
        try{

            if (empty($param['status']))
                $param['status']=0;



			$param['id']=(Db::name('auth_group')->max('id')+1);
			if (empty($param['sortid']))
                $param['sortid']=$param['id'];

            $result =  $this->validate( 'RoleValidate')->save($param);
			
            if(false === $result){               
                return ['code' => -1, 'data' => '', 'msg' => $this->getError()];
            }else{
                return ['code' => 1, 'data' => '', 'msg' => '添加角色成功'];
            }
        }catch( PDOException $e){
            return ['code' => -2, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    /**
     * [editRole 编辑角色信息]
     * @author [李勇] [peis999]
     */  
    public function editRole($param)
    {
        try{
            if (empty($param['status']))
                $param['status']=0;


            $validate = new Validate([
                ["title", "unique:auth_group,title={$param['title']}&isdel=1,{$param['id']},id", '角色已经存在']
            ]);
            $result=$validate->check($param);

            if(false === $result){
                return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
            }else{
                 $this->save($param, ['id' => $param['id']]);
                return ['code' => 1, 'data' => '', 'msg' => '编辑角色成功'];
            }
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    /**
     * [getOneRole 根据角色id获取角色信息]
     * @author [李勇] [peis999]
     */ 
    public function getOneRole($id)
    {
        return $this->where('id', $id)->find();
    }



    /**
     * [delRole 删除角色]
     * @author [李勇] [peis999]
     */ 
    public function delRole($id)
    {
        Db::startTrans();
        try{
            $this->where('id', $id)->setField('isdel',0);
            Db::name('admin')->where('groupid', $id)->setfield('isdel',0);
            writelog(session('uid'),session('username'),'用户【'.session('username').'】删除角色(ID='.$id.')及所包含的操作员成功',1);
            Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '删除角色成功及所包含的操作员成功'];
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    /**
     * [getRole 获取所有的角色信息]
     * @author [李勇] [peis999]
     */ 
    public function getRole()
    {
        return $this->select();
    }


    /**
     * [getRole 获取角色的权限节点]
     * @author [李勇] [peis999]
     */ 
    public function getRuleById($id)
    {
        $res = $this->field('rules')->where('id',$id)->find();
        return $res['rules'];
    }


    /**
     * [editAccess 分配权限]
     * @author [李勇] [peis999]
     */ 
    public function editAccess($param)
    {
        try{
            $this->save($param, ['id' => $param['id']]);
            return ['code' => 1, 'data' => '', 'msg' => '分配权限成功'];

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    /**
     * [getRoleInfo 获取角色信息]
     * @author [李勇] [peis999]
     */ 
    public function getRoleInfo($id){

        $result = Db::name('auth_group')->where('id', $id)->find();
        if(is_null($result['rules'])){
            $where = '';
        }else{
            $where = 'id in('.$result['rules'].')';
        }

        $res = Db::name('auth_rule')->field('name')->where($where)->select();

        foreach($res as $key=>$vo){
            if('#' != $vo['name']){
                $result['name'][] = $vo['name'];
            }
        }
      
		
        return $result;
    }
}