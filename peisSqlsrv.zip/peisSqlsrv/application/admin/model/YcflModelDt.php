<?php
namespace app\admin\model;
use think\Db;
use think\exception\PDOException;
use think\Model;
class YcflModelDt extends Model{
    protected $name="jbmb_ycfl_dt";




 //移除异常分类体检项目
    public function delYcflTjxm($jbmbid,$ycflid,$tjxmid,$name)
    {
        Db::startTrans();
        try{

            $result = $this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid,'tjxmid'=>$tjxmid])->delete();
            if ($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除异常分类体检项目' . $name . '失败(ID=' . $jbmbid .'-'.$ycflid .'-'.$tjxmid .')', 2);
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => '移除异常分类体检项目失败'];
            } else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除异常分类体检项目' . $name . '成功(ID=' . $jbmbid. '-'.$ycflid .'-'.$tjxmid . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '移除异常分类体检项目成功'];

            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    //移除异常分类体检项目（多选）
    public function delYcfMullSelTjxm($jbmbid,$ycflid,$tjxmids){
        Db::startTrans();
        try{
           $result=$this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid])->whereIn('tjxmid',$tjxmids)->delete();
            if($result==false){
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除异常分类体检项目失败('. $jbmbid .'-'.$ycflid .'-'.$tjxmids .')', 2);
                Db::rollback();
                return ['code'=>1,'data'=>'','msg'=>'移除异常分类体检项目失败'];

            }else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除异常分类体检项目成功('. $jbmbid .'-'.$ycflid .'-'.$tjxmids .')', 2);
                Db::commit();
                return ['code'=>1,'data'=>'','msg'=>'移除异常分类体检项目成功'];
            }

        }catch (PDOException $e){
            Db::rollback();
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
        }
    }
}