<?php
namespace app\admin\model;
use think\Validate;
use think\Db;
use think\exception\PDOException;
use think\Model;
class DwbmModel extends Model
{
    protected $name = "dwbm";

    //双击添加/更新单位部门信息
    public function editDwbm($param)
    {
        $validate = new Validate([
            ["mc","unique:dwbm,mc={$param['mc']}&dwid={$param['dwid']}","部门名称已存在"]
        ]);
        try {
            if (empty($param['id'])) { //新增部门
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];
                $result=$validate->check($param);
                if (false === $result) {
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加部门失败', 2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {

                    $this->allowField(true)->save($param);
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加部门成功',1);
                    return ['code' => 1, 'data' =>$param, 'msg' => '添加部门成功'];
                }
            } else {//编辑部门
                $result=$validate->check($param);

                if (false === $result) {
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑部门失败', 2);
                    return ['code' => 0, 'data' => '', 'msg' =>$validate->getError()];
                } else {
                    $this->save($param,['dwid'=> $param['dwid'],'id'=>$param['id']]);
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑部门成功',1);
                    return ['code' => 2, 'data' => $param, 'msg' => '编辑部门成功'];
                }
            }
        } catch (PDOException $e) {
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //删除单位部门信息
    public function delDwbm($id)
    {
        Db::startTrans();
        try{
            $this->where('id', $id)->delete();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】删除单位部门(ID='.$id.')成功',1);
            Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '删除单位部门成功'];
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    /**
     * editSoft 排序
     * @author [俞晴] [peis999]
     */
    public function editSoft($id,$type,$targetid)
    {
        Db::startTrans();
        try{

            $softId=$this->where('id',$id)->value('softid');
            $targerSoftId=$this->where('id',$targetid)->value('softid');

            if ($softId >$targerSoftId)
                $map['softid']=['between',$targerSoftId.','. $softId];
            else
                $map['softid']=['between',$softId.','.$targerSoftId];

            if ($type=="prev") {

                if ($softId >$targerSoftId)
                {
                    $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                    $this->where($map)->setInc('softid');
                    $this->where('id', $id)->setField('softid', $targerSoftId);
                } else{
                    $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                    $this->where($map)->setDec('softid');
                    $this->where('id', $id)->setField('softid', $targerSoftId-1);
                }


            }else{

                if ($softId >$targerSoftId)
                {
                    $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                    $this->where($map)->setInc('softid');
                    $this->where('id', $id)->setField('softid', $targerSoftId+1);
                } else{
                    $map['softid']=['between',($softId+1).','.$targerSoftId];
                    $this->where($map)->setDec('softid');
                    $this->where('id', $id)->setField('softid', $targerSoftId);
                }
            }

            Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '调整单位部门排序成功'];

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

}
