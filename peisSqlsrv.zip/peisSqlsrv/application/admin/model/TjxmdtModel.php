<?php

namespace app\admin\model;
use think\Model;
use app\admin\model\TjxmModel;
use think\Db;

class TjxmdtModel extends Model
{
//体检项目表名不带前缀
    protected $name = "tjxm_dt";


    /**
     * [getOneTjxmDt 获取体检项目及所属医院细节数据]
     * @author [李勇] [peis999]
     */
    public function getOneTjxmDt($id)
    {

         // $tjxm=TjxmModel::with('TjxmDts');
        //$tjxm->TjxmDts()->where('hospitalid',session('hospitalid'))->select();
        // return $tjxm->TjxmDts()->where('hospitalid',session('hospitalid'))->select();
        //$tjxm->has('TjxmDts','>',1))->select();
        // $tjxm->haswhere('TjxmDts',['hospitalid'=>session('hospitalid')])->select();
       // $tjxm=TjxmModel::get($id);
      //  $tjxm->haswhere('TjxmDts',['hospitalid'=>session('hospitalid')])->select();
       // $tjxm.
        $tjxm= new TjxmModel();
        return $tjxm->alias('xm')->join('tjxm_dt dt','xm.id=dt.tjxmid','left')
            ->where(function($query){
                $query->where('hospitalid',session('hospitalid'))->whereor('hospitalid','null');
            })->find($id);

    }
    //定义关联到体检项目
  public function Tjxm()
    {
        // return $this->find($id);

        return $this->belongsTo('TjxmModel','id','tjxmid');
    }

    /**
     * [ editTjxm参数【判断是新增还是更新 体检项目]
     * @author [李勇] [peis999]
     */
    public function editTjxmdt($param)
    {

        try {

            //unset($param['tjlxname']);
           // unset($param['name']);
            if (!empty($param['tjxmid'])) { //更新

                unset($param['id']);//去掉提交非表字段或者用$this->field（)->save（）；
                $result = $this->save($param,['tjxmid'=>$param['tjxmid'],'hospitalid'=>session('hospitalid')]);  //update不验证
                if (false === $result) {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检项目'. $param['mc'].'失败(ID='.$param['tjxmid'].')',2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检项目细节成功(ID='.$param['tjxmid'].')',1);
                    return ['code' => 1, 'data' => '', 'msg' => '编辑体检项目细节成功'];
                }

            } else { //新增
                $param['tjxmid']= $param['id'];
                $param['hospitalid']=session('hospitalid');
                unset($param['id']);
                $result = $this->save($param);  //insert 不验证

                if (false === $result) {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检项目细节失败(ID='.$param['tjxmid'].')',2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检项目细节失败(ID='.$param['tjxmid'].')',1);
                    return ['code' => 1, 'data' => '', 'msg' => '添加体检项目细节成功'];
                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delTjxm  删除体检项目
     * @param $id $name
     */
    public function delTjxmdt($tjxmid,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where(['tjxmid'=>$tjxmid,'hospitalid'=>session('hospitalid')])->delete();

            if ($result == false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检项目' . $name . '细节失败(ID=' . $tjxmid . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目细节失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检项目' . $name . '细节成功(ID=' . $tjxmid . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目细节成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



}