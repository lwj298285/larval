<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class YcflModel extends Model
{
//临床类型
    protected $name = "jbmb_ycfl_hd";


    /**
     * [getOneLclx 获取临床类型节点数据]
     * @author [李勇] [peis999]
     */
        public function getOneYcfl($jbmbid,$ycflid)
    {
        return $this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid])->find();
    }


    /**
     * [ editLclx参数【判断是新增还是更新 临床类型]
     * @author [李勇] [peis999]
     */
    public function editYcfl($param)
    {

        try {

            if (!empty($param['ycflid'])) { //更新

                if(!isset($param['status']))
                    $param['status']=0;

                $result = $this->save($param,['ycflid'=>$param['ycflid'],'jbmbid'=>$param['jbmbid']]);  //update不验证
                if (false === $result) {
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    return ['code' => 1, 'data' => '', 'msg' => '编临异常分类' . $param['ycflmc'] . '成功'];
                }

            } else { //新增
                $id = $this->where('jbmbid',$param['jbmbid'])->max('ycflid');
                $param['ycflid'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['ycflid'];
                $result = $this->save($param);  //insert 不验证

                if (false === $result) {
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    return ['code' => 1, 'data' => '', 'msg' => '新增异常分类' . $param['ycflmc'] . '成功'];
                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * delYcfl 删除异常分类
     * @param $jbmbid,$ycflid $name
     */
    public function delYcfl($jbmbid,$ycflid,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid])->setField('isdel',0);
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除异常分类' . $name . '失败(ID=' .$jbmbid.'-'.$ycflid . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除异常分类失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除异常分类' . $name . '成功(ID=' .$jbmbid.'-'.$ycflid . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除异常分类成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    //   调整异常分类排序
    public function editSoft($jbmbid,$ycflid,$type,$targetid)
        {
            Db::startTrans();
            try{

                $softId=$this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid])->value('softid');
                $targerSoftId=$this->where(['jbmbid'=>$jbmbid,'ycflid'=>$targetid])->value('softid');
               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

               /* if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];*/
                $map['jbmbid']=['=',$jbmbid];

                $where['jbmbid']=['=',$jbmbid];
                $where['ycflid']=['=',$ycflid];

                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where($where)->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where($where)->setField('softid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where($where)->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where($where)->setField('softid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整异常分类排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}