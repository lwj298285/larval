<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Collection;
use think\Validate;
class TjxmModel extends Model
{
//体检项目表名不带前缀
    protected $name = "tjxm";


    //定义项目细节一对多关联
    public function TjxmDts()
    {
        return $this->hasMany('TjxmdtModel','tjxmid','id','','left')->field('sxsc,mrrs,xmyq');
    }



    //获取器 改变是否计入小结获取值显示
    public function getJrxjAttr($value)
    {

        $Jrxj=[0=>'否',1=>'是'];

        return $Jrxj[$value];
    }

    //获取器 改变是否对比获取值显示
    public function getSfdbAttr($value)
    {

        $Sfdb=[0=>'否',1=>'是'];

        return $Sfdb[$value];
    }

    //获取器 改变性别取值显示
    public function getXbAttr($value)
    {

        $Xb=['%'=>'所有','1'=>'男','0'=>'女'];

        return $Xb[$value];
    }

    //获取器 改变性别取值显示
    public function getJglxAttr($value)
    {

        $Xb=['0'=>'文字','1'=>'数值'];

        return $Xb[$value];
    }
    /**
     * [getOneTjxm 获取体检项目节点数据]
     * @author [李勇] [peis999]
     */
    public function getOneTjxm($id)
    {
       $tjxm= $this->find($id);
        //因为有设置获取器getdata 为了获取原始数据
        return $tjxm->getData();
    }



    /**
     * [ editTjxm参数【判断是新增还是更新 体检项目]
     * @author [李勇] [peis999]
     */
    public function editTjxm($param)
    {

       // Db::startTrans();
        try {



            if(empty($param['xmlxid'])){
                unset($param['xmlxid']);
                $validate = new Validate([
                    ["mc","unique:tjxm,mc={$param['mc']}&tjlxid={$param['tjlxid']}&isdel=1","体检项目(".$param['mc'].")已存在",]
                ]);
            }else{
                $validate = new Validate([
                    ["mc","unique:tjxm,mc={$param['mc']}&tjlxid={$param['tjlxid']}&xmlxid={$param['xmlxid']}&isdel=1","体检项目(".$param['mc'].")已存在",]
                ]);

            }

            if (!empty($param['id'])) { //更新

                if(!isset($param['status']))
                    $param['status']=0;

                if(!isset($param['jrxj']))
                    $param['jrxj']=0;

                if(!isset($param['sfdb']))
                    $param['sfdb']=0;



                $result=$validate->check($param);

                if (false === $result) {
                  //  Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result =  $this->allowField(true)->save($param,['id'=>$param['id']]);
                    //return ['code' => 1, 'data' => '', 'msg' => '编辑体检项目' . $param['mc'] . '成功'];
                    if (false === $result) {
                       // Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检项目'. $param['mc'].'失败(ID='.$param['id'].$this->getError().')',2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                    } else {
                        //Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检项目'.$param['mc'].'成功(ID='.$param['id'].')',1);
                        return ['code' => 2, 'data' => $param, 'msg' => '编辑体检项目' . $param['mc'] . '成功'];
                    }
                }




            } else { //新增
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];
                $result=$validate->check($param);

                if (false === $result) {
                   // Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->allowField(true)->save($param);
                    //return ['code' => 1, 'data' => '', 'msg' => '编辑体检项目' . $param['mc'] . '成功'];

                    if (false === $result) {
                        //Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】添加体检项目'. $param['mc'].'失败(ID='.$param['id'].$this->getError().')',2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                       // Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】添加体检项目'. $param['mc'].'失败(ID='.$param['id'].')',1);
                        return ['code' => 1, 'data' =>$param, 'msg' => '添加体检项目' . $param['mc'] . '成功'];
                    }
                }





            }

        }catch( PDOException $e){
            //Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delTjxm  删除体检项目
     * @param $id $name
     */
    public function delTjxm($id,$name)
    {
        Db::startTrans();
        try {

            if(!empty(Model('YsztModel')->where('xmid',$id)->select())) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'体检项目已被体检引用不可删除'];
            }

            if((Model('ZhxmModel')->alias('hd')
                              ->join('zhxm_dt dt','hd.id=dt.zhxmid and hd.isdel=1','left')
                              ->where('tjxmid',$id)
                              ->count())>0){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'体检项目已被组合项目引用不可删除'];
            }
            $result = $this->where('id', $id)->setField('isdel', 0);

            if ($result == false){
                writelog(session('uid'), session('username'), '用户【'.session('username').'】删除体检项目' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
               return ['code' => 1, 'data' => '', 'msg' => '删除体检项目失败'];
          } else{
                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除体检项目'.$name.'成功(ID='.$id.')',1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目成功'];
            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //调整体检项目排序
        public function editSoft($tjlxid,$xmlxid,$id,$type,$targetid)
        {
            Db::startTrans();
            try{


                $softId=$this->where('id',$id)->value('softid');

                $targerSoftId=$this->where('id',$targetid)->value('softid');
                $map['tjlxid']=['=',$tjlxid];
                if (!empty($xmlxid))
                   $map['xmlxid']=['=',$xmlxid];

               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

               /* if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];

                //$map['softid']=['between','lt,gt'];
                */




                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId-1);
                    }


                }else if($type=="next"){

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where('id', $id)->setField('softid', $targerSoftId);
                    }

                }else{
                    if(!empty($xmlxid))
                        $this->where('id', $id)->setField('xmlxid', $xmlxid);
                    else
                        $this->where('id', $id)->setField('xmlxid', null);

                }

                Db::commit();
                if ($type=="inner")
                     $msg="项目分类成功";
                else
                     $msg="调整体检项目排序成功";

                return ['code' => 1, 'data' => '', 'msg' => $msg];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }




        //------------------------获取体检项目数结构-----------------------------------------------------

    public function giveTjxmTree($map)
    {

        //获取所有体检类型
        $result = Db::name('department')->field('id as depid ,depname,softid')
            ->where(['isdel&status'=>1])
            ->order('softid')
            ->select();


        //获取当前体检类型下的体检项目
        $alltjxm= Db::name('tjxm  xm')->join('lclx lc','lc.id=lclxid','left')
            ->field('tjlxid,lclxid,lclxname, xm.id as xmid ,mc,xm.softid as xmsoftid')
            ->where($map)
            ->where('xm.isdel',1)
            ->order('lclxid,xmsoftid')
            ->select();

        $str = '[{"id":"0","name":"体检项目维护", "open":"true","childOuter":"false","children":[';

        if  ($result) {

            foreach ($result as $key => $vo) {

                //自定义函数，去除包含某一个值得数组

            /*    function delValue($arr,$vo['depid'])
                {
                    foreach ($arr as $key=>$value){
                        if($value['tjlxid']==){
                            return true;
                        }
                        return false;
                    }
                }
                $tjxm=array_filter( $alltjxm,"delValue");
                sort($tjxm);//重新生成索引下标
*/
               $tjxm=array_filter($alltjxm,$alltjxm['tjlxid']=$vo['depid']);

                if  ($tjxm) {
                    //体检项目有数据
                    $lclxid="";
                    $isStart=true;
                  //增加有体检项目体检类型目录
                    $str .= '{ "id": "' . $vo['depid']. '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","pid":"0","children":[';
                  //增加体检项目目录

                    foreach ($tjxm as $k => $v) {

                      if ( $vo['depid']==$v['tjlxid']) {
                          //判断临床类型有无数据增加临床类型目录
                          if (!empty($v['lclxid'])) {

                              //有不同临床类型结束之前临床类型
                              if ($v['lclxid'] != $lclxid && $isStart === false) {
                                  $str = substr($str, 0, -1);
                                  $str .= ']},';
                              }
                              //相同的临床类型目录只增加一次
                              if ($v['lclxid'] != $lclxid) {
                                  $str .= '{ "id": "' . $v['lclxid'] . '","name":"' . $v['lclxname'] . '","childOuter":"false","open":"false","pid":"' . $vo['depid'] . '","children":[';
                                  $lclxid = $v['lclxid'];

                              }


                              $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $v['lclxid'] . '"},';

                              $isStart = false;

                          } else {
                              //有体检项目无临床类型 ，之前的体检项目有临床类型没有结束结束之前的临床类型集合
                              if ($isStart === false) {
                                  $str = substr($str, 0, -1);
                                  $str .= ']},';
                                  $isStart = true;
                              }

                              $str .= '{ "id": "' . $v['xmid'] . '","name":"' . $v['mc'] . '","childOuter":"false","open":"false","pid":"' . $vo['depid'] . '"},';

                          }
                      }



                    }

                    //数据采集完成后，之前的体检项目有临床类型没结束的结束之前的临床类型
                    if ( $isStart===false) {
                        $str=substr($str, 0, -1);
                        $str .=']},';

                    }
                    //去除体检项目集合后一位逗号
                    $str=substr($str, 0, -1);

                    $str .=']},'; //添加当前体检类型目录体检项目结束

                }else{
                  //增加无体检项目体检类型目录
                    $str .= '{ "id": "' . $vo['depid']. '","name":"' . $vo['depname'] . '","childOuter":"false","open":"false","pid":"0","iconSkin":"diy02"},';

                }


            }

           //去除体检类型集合最后一位逗号
           $str=substr($str, 0, -1);

        }//判断体检类型有无数据

        //顶级目录结束
        $str.=']}]';


        return $str;


    }






}