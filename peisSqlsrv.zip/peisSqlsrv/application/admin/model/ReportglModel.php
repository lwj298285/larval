<?php
namespace app\admin\model;
use think\exception\PDOException;
use think\Model;
use think\Db;
use think\Validate;

class ReportglModel extends Model{
  protected $name='report';


   //添加及更新报表模板信息
  public function editReport($param){

      $validate=new Validate([
         [ 'mbmc',"unique:report,name={$param['name']}&mbmc={$param['mbmc']}","报表模板名称已存在!",]
      ]);
Db::startTrans();
      try{
           if(isset($param['isdefault']) ) {
               $param['isdefault'] = 1;
               $this->where(['name'=>$param['name']])->setField('isdefault',0);
           }else {
               $param['isdefault'] = 0;
           }

           if (!empty($param['id'])){
               $result=$validate->check($param);
               if (false === $result) {
                   Db::rollback();
                   return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
               } else {

                  $flag=$this->save($param,['id'=>$param['id']]);
                  if($flag==false){
                      Db::rollback();
                      writelog(session('uid'),session('username'),'编辑报表模板【'.$param['mbmc'].'】失败',2);
                      return  ['code'=>0,'data'=>'','msg'=>'编辑报表模板失败'];
                  }else{
                      Db::commit();
                      writelog(session('uid'),session('username'),'编辑报表模板【'.$param['mbmc'].'】成功',1);
                      return  ['code'=>2,'data'=>$param,'msg'=>'编辑报表模板成功'];
                  }

               }
           }else{
               $id=$this->max('id');
               $param['id']=empty($id) ? 1:$id+1;
               $param['sortid'] = $param['id'];
               $param['hospitalid'] = session('hospitalid');
               $result =$validate->check($param);
               if (false ===$result) {
                   Db::rollback();
                   return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
               } else {
                   $flag=$this->save($param);
                   if($flag==false){
                       Db::rollback();
                       writelog(session('uid'),session('username'),'添加报表模板【'.$param['mbmc'].'】失败',2);
                       return  ['code'=>0,'data'=>'','msg'=>'添加报表模板失败'];
                   }else{
                       Db::commit();
                       writelog(session('uid'),session('username'),'添加报表模板【'.$param['mbmc'].'】成功',1);
                       return  ['code'=>1,'data'=>$param,'msg'=>'添加报表模板成功'];
                   }


               }
           }
      }catch (PDOException $e){
       Db::rollback();
       return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];

      }

    }

//删除报表模板信息
public function delReport($id){
    try{
        $result=$this->where(['id'=>$id,'isdel'=>1])->delete();
        if($result==false){
            writelog(session('uid'),session('username'),"删除报表模板失败(ID='.$id.')",2);
            return  ['code'=>0,'data'=>'','msg'=>'删除报表模板失败'];
        }else{
            writelog(session('uid'),session('username'),'删除报表模板成功(ID='.$id.')',1);
            return  ['code'=>1,'data'=>$id,'msg'=>'删除报表模板成功'];
        }
    }catch (PDOException $e){
        return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
    }

}


//编辑报表报表模板参数
    public function  editMbcs($param)
    {
        try {
            $flag = $this->save($param, ['id' => $param['id']]);
            if ($flag == false) {
                Db::rollback();
                writelog(session('uid'), session('username'), '编辑报表模板【id:' . $param['id'] . '】参数失败', 2);
                return ['code' => 0, 'data' => '', 'msg' => '编辑报表模板参数失败'];
            } else {
                Db::commit();
                writelog(session('uid'), session('username'), '编辑报表模板【id:' . $param['id'] . '】参数成功', 1);
                return ['code' => 1, 'data' => $param, 'msg' => '编辑报表模板成功'];
            }
        }catch (PDOException $e){
            Db::rollback();
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];

        }
 }


        //排列顺序
public function  editSoft($id,$targetid,$type){
        Db::startTrans();
        try{
         $softId=$this->where(['id'=>$id])->value('sortid');
          $targetSoftId=$this->where('id',$targetid)->value('sortid');
            if($type=="prev"){
               if($softId>$targetSoftId){
                   $map['sortid']=['between',$targetSoftId.','.($softId)];
                   $this->where($map)->setInc('sortid');
                   $this->where('id',$id)->setField('sortid',$targetSoftId);
               }else{
                   $map['sortid']=['between',($softId+1).','.($targetSoftId-1)];
                   $this->where($map)->setDec('sortid');
                   $this->where('id',$id)->setField('sortid',($targetSoftId-1));
               }
            }else{
                if ($softId >$targetSoftId)
                {
                    $map['sortid'] = ['between', ($targetSoftId+1) . ',' . ($softId-1)];
                    $this->where($map)->setInc('sortid');
                    $this->where('id',$id)->setField('sortid',$targetSoftId+1);
                } else{
                    $map['sortid']=['between',($softId+1).','.$targetSoftId];
                    $this->where($map)->setDec('sortid');
                    $this->where('id',$id)->setField('sortid', $targetSoftId);
                }
            }
            Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '调整报表模板排序成功'];

        }catch (PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }





}