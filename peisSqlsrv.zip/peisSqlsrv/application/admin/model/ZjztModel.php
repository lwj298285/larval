<?php
namespace app\admin\model;
use think\Db;
use think\Config;
use think\exception\PDOException;
use think\Model;
class YsztModel extends Model{
    protected $name='tjjlmxb';




//录入体检小项信息
    public function editJg($params,$zhxmid){

            try {
               Db::startTrans();
                //$lrtj=$this->where(['xh'=>$param['xh'],'zhxmid'=>$zhxmid])->delete();
                if (!empty($zhxmid)) { //更新
                    $result = $this->saveAll($params,$zhxmid,false);  //update不验证
                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑('.$params['jobnum'].')录入体检失败',2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                    } else {
                        Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑('.$params['jobnum'].')录入体检成功',1);
                        return ['code' => 1, 'data' => '', 'msg' => '编辑录入体检成功'];
                    }

                } else { //新增
                    $result = $this->saveAll($params,false);  //insert 不验证
                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】新增('.$params['jobnum'].')录入体检失败',2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】新增('.$params['jobnum'].')录入体检成功',1);
                        return ['code' => 1, 'data' => '', 'msg' => '新增录入体检成功'];
                    }

                }

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}