<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/6/28
 * Time: 15:51
 */

namespace app\admin\model;
use think\Db;
use think\exception\PDOException;
use think\Model;
use think\Validate;

class XtcsModel extends Model
{
    protected $name = "param";
//添加及更新系统参数
    public function xtcsEdit($param)
    {
      //  Db::startTrans();
     try{
         $validate = new Validate([
             ["mc","unique:param,mc={$param['mc']}&isdel=1","系统参数编码(".$param['mc'].")已存在",],
             ["zwmc","unique:param,zwmc={$param['zwmc']}&isdel=1","系统参数名称(".$param['zwmc'].")已存在",]
         ]);


         if(!empty($param['id'])){
             $result=$validate->check($param);

             if($result==false){
                // Db::rollback();
                // writelog(session('uid'),session('username'),'编辑系统【'.$param['mc'].'】参数失败',2);
                 return ['code'=>0,'data'=>'','msg' => $validate->getError()];
             }else{
                 //Db::commit();
                 $result=$this->save($param,['id'=>$param['id']]);
                 if (false === $result) {
                     writelog(session('uid'),session('username'),'编辑系统【'.$param['mc'].'】参数失败'.$this->getError(),2);
                     return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                 }else {

                     writelog(session('uid'), session('username'), '编辑系统【' . $param['mc'] . '】参数成功', 1);
                     return ['code' => 1, 'data' => '', 'msg' => '编辑系统' . $param['mc'] . '参数成功'];
                 }
             }
         }else{
             $id=$this->max('id');
             $param['id']=empty($id) ? 1:$id+1;
             $param['softid']=$param['id'];
             $result=$validate->check($param);


             if($result==false){
                // Db::rollback();
                 //writelog(session('uid'),session('username'),'添加系统参数【'.$param['mc'].'】失败',2);
                 return ['code'=>0,'data'=>'','msg' =>$validate->getError()];
             }else{
                 //Db::commit();
                 $result=$this->save($param);
                 if (false === $result) {
                     writelog(session('uid'),session('uesrname'),'添加系统参数['.$param['mc'].']失败'.$this->getError(),2);
                     return ['code'=>0,'data'=>'','msg'=>$this->getError()];
                 }else {

                     writelog(session('uid'),session('uesrname'),'添加系统参数['.$param['mc'].']成功',1);
                     return ['code'=>1,'data'=>'','msg'=>'添加系统参数'.$param['mc'].'成功'];
                 }

             }
         }

     }catch (PDOException $e){
         //Db::rollback();
      return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];

     }
    }
//删除系统参数
public function delXtcs($id){
 try{
     $result=$this->where(['id'=>$id,'isdel'=>1])->delete();
     if($result==false){
         writelog(session('uid'),session('username'),'删除系统参数失败',2);
         return ['code'=>0,'data'=>'','msg'=>'删除系统参数失败'];
     }else{
       writelog(session('uid'),session('username'),'删除系统参数成功',1);
        return ['code'=>1,'data'=>'','msg'=>'删除系统参数成功'];
     }
 }catch (PDOException $e){
     return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
 }

}
//排序
public function editSoft($id,$targetid,$type){
    Db::startTrans();
    try{
       $softId=$this->where('id',$id)->value('softid');
       $targetSoftId=$this->where('id',$targetid)->value('softid');
        if($type=="prev"){
            if($softId>$targetSoftId){
                $map['softid']=['between',$targetSoftId.','.($softId-1)];
                $this->where('id',$id)->setInc('softid');
                $this->where('id',$id)->setField('softid',$targetSoftId);
            }else{
                $map['softid']=['between',($softId+1).','.($targetSoftId-1)];
                $this->where('id',$id)->setDec('softid');
                $this->where('id',$id)->setField('softid',($targetSoftId-1));
            }
        }else{
            if($softId>$targetSoftId){
                $map['softid']=['between',($targetSoftId+1).','.($softId-1)];
                $this->where('id',$id)->setInc('softid');
                $this->where('id',$id)->setField('softid',($targetSoftId+1));
            }else{
                $map['softid']=['between',($softId+1).','.$targetSoftId];
                $this->where('id',$id)->setDec('softid');
                $this->where('id',$id)->setField('softid',$targetSoftId);
            }
        }
        Db::commit();
        return ['code' => 1, 'data' => '', 'msg' => '调整系统参数排序成功'];

    }catch (PDOException $e){
        Db::rollback();
        return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
    }

}
}