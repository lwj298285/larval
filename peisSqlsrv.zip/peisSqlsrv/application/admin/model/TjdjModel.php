<?php

namespace app\admin\model;
use think\exception\PDOException;
use think\Model;
use think\model\Collection;
use traits\model\SoftDelete;
use think\Db;
use mail\Phpmailer;
use sms\Sms;
class TjdjModel extends Model
{
    protected $name = 'tjdjb';
    use SoftDelete;
    protected $deletetime = 'delete_time';

//获取器将时间戳转为日期yyyy-mm-dd格式
    /*public function  getDjrqAttr($value)
    {
        if (!is_null($value))
            return date('Y-m-d',$value);
    }
    public function  getTjrqAttr($value)
    {
        if (!is_null($value))
         return date('Y-m-d',$value);
    }
    public function  getCsnyrAttr($value)
    {
        if (!is_null($value))
           return date('Y-m-d',$value);
    }

   public function  getXbAttr($value)
    {
        $xb=[0=>'女',1=>'男',2=>'不详'];
        return $xb[$value];
    }*/

    /**
     * 删除体检登记
     */




//添加/更新体检登记信息


    public function editTjdj($param,$zhxms)
    {


        try {
            Db::startTrans();


            /* if (!empty($param['tjbh']) && !empty($param['tjcs'])) {
                 $djflag = $this->where(['tjbh' => $param['tjbh'], 'tjcs' => $param['tjcs'], 'hospitalid' => session('hospitalid')])->find();
             }*/


            foreach ($param as $k => $v) {

                if (empty($v) && $k != 'xb' && $k != 'jmfs')
                    $param[$k] = null;

            }

            if (empty($param['jmfs']))
                $param['jmfs'] = NULL;

            //if (!empty($djflag)) { //更新
            if (!empty($param['djlsh'])) { //更新
//编辑根据体检进度判断是否可编辑
                // $jdbz = Model('TjdjModel')->where(['tjbh' => $param['tjbh'], 'tjcs' => $param['tjcs'],'hospitalid'=>session('hospitalid')])->value('jdbz');
                $jdbz = Model('TjdjModel')->where(['djlsh' => $param['djlsh'], 'hospitalid' => session('hospitalid')])->value('jdbz');
                /*if (intval($jdbz) != 0 && intval($jdbz) != 1  &&intval($jdbz) != 10 && !empty($jdbz)) {
                    Db::rollback();
                    return ['code' => 0, 'tjbh' => '','djlsh' => '', 'data' => '', 'msg' => $param['xm'] . '(已经在检，个人信息不可编辑！)'];
                }*/


                //判断体检进度  如果已经总检不可编辑，如果是已缴费/待总检/预存总检状态; 可以编辑
                if (intval($jdbz) >= 40 && !empty($jdbz)) {

                    Db::rollback();
                    return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $param['xm'] . '(已经总检，个人信息不可编辑！)'];
                }


//更新登记人员套餐组合项目
                $zhxm = [];
                $oldzhxms = [];
                $delzhxms = [];
                $newzhxms = [];
//写入登记人员套餐组合项目

                //已经存在的组合项目
                $exsitzhxms = Model('TjjlbModel')->alias('tj')->field('xh,zhxmid,hd.mc,tcwxm,xmdj')
                    ->join('zhxm_hd hd', 'tj.zhxmid=hd.id')
                    ->where(['tjbh' => $param['tjbh'], 'tjcs' => $param['tjcs'], 'hospitalid' => session('hospitalid')])
                    ->select();

                //组织数据库已存在组合项目与需要保存项目为相同数组格式求交集
                if (count($exsitzhxms) > 0){
                    foreach ($exsitzhxms as $k => $v) {
                        $oldzhxms[$k]['xh'] = $v['xh'];
                        $oldzhxms[$k]['zhxmid'] = $v['zhxmid'];
                        $oldzhxms[$k]['mc'] = $v['mc'];
                        $oldzhxms[$k]['tcwxm'] = $v['tcwxm'];
                        $oldzhxms[$k]['xmdj'] = $v['xmdj'];

                        if (!empty($v['xh']))
                            $xh = $v['xh'];

                    }
               }

                $delzhxms = $oldzhxms;
                if (!empty($zhxms))
                    $newzhxms = $zhxms;
                else
                    $zhxms=[];

            //去除需保存已经存在项目（待新增）
                if (count($newzhxms) > 0){
                        foreach ($newzhxms as $k => $v) {

                            if (in_array($v, $oldzhxms))
                                unset($newzhxms[$k]);
                        }
                  }

                //找到已存在无需保存项目（待删除）
                if (count($delzhxms) > 0) {
                    foreach ($delzhxms as $k => $v) {

                        if (in_array($v, $zhxms))
                            unset($delzhxms[$k]);
                    }
                }




                //检查序号是否为空如果为空说明之前不存在项目

                if (count($delzhxms) > 0 && !empty($xh)) {
                    $delzhxmid = array_column($delzhxms, 'zhxmid');
                    Model('TjjlbModel')->where(['xh' => $xh, 'hospitalid' => session('hospitalid'), 'zhxmid' => ['in', $delzhxmid]])->delete();
                    Model('YsztModel')->where(['xh' => $xh, 'hospitalid' => session('hospitalid'), 'zhxmid' => ['in', $delzhxmid]])->delete();
                } else {
                    if (empty($xh)) {
                        $xh = Model('TjjlbModel')->where('hospitalid', session('hospitalid'))->max('xh');
                        $xh = empty($xh) ? 1 : $xh + 1;
                    }
                }


                if (count($newzhxms) > 0) {


                    foreach ($newzhxms as $key => $v) {
                        $zhxm[$key]['xh'] = $xh;
                        $zhxm[$key]['hospitalid'] = session('hospitalid');
                        $zhxm[$key]['tjbh'] = $param['tjbh'];
                        $zhxm[$key]['tjcs'] = $param['tjcs'];
                        $zhxm[$key]['zhxmid'] = $v['zhxmid'];
                        $zhxm[$key]['xmdj'] = $v['xmdj'];
                        $zhxm[$key]['tcwxm'] = $v['tcwxm'];

                        //获取组合项目小项塞入数组待写入体检结果表中
                        $zhxmxm = Model('ZhxmDtModel')->alias('dt')
                            ->join('tjxm', 'dt.tjxmid=tjxm.id')
                            ->field('tjxmid as xmid,jrxj,dw,ckxx as minckz,cksx as maxckz,memockz')
                            ->where('zhxmid', $v['zhxmid'])->select();

                        $xm = [];

                        if (count($zhxmxm) > 0)

                            foreach ($zhxmxm as $k => $value) {


                                $xm[$k]['xh'] = $xh;
                                $xm[$k]['zhxmid'] = $v['zhxmid'];
                                $xm[$k]['xmid'] = $value->xmid;
                                $xm[$k]['dw'] = $value->dw;
                                $xm[$k]['jrxj'] = $value->jrxj;
                                $xm[$k]['minckz'] = $value->minckz;
                                $xm[$k]['maxckz'] = $value->maxckz;
                                $xm[$k]['memockz'] = $value->memockz;
                                $xm[$k]['hospitalid'] = session('hospitalid');

                            }


                            $tjjlmxb = new YsztModel();
                            $result = $tjjlmxb->saveAll($xm, false);

                            if (false === $result) {
                                Db::rollback();
                                writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑登记信息' . $param['tjbh'] . '-' . $param['tjcs'] . '失败', 2);
                                return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $tjjlmxb->getError()];
                            }

                    }


                }


                if (count($zhxm) > 0)
                    //保存体检组合项目
                    $result = Model('TjjlbModel')->saveAll($zhxm, false);
                else
                    $result = true;


                if (false === $result) {
                    Db::rollback();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑登记信息' . $param['tjbh'] . '-' . $param['tjcs'] . '失败', 2);
                    return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $this->getError()];
                } else {

                    foreach ($param as $k => $v) {

                        if ($v == "***")
                            unset($param[$k]);

                    }

                    //判断是否有新增项目 如果有 进度标志置为在检
                    if (count($newzhxms) > 0) {
                        $jdbz = self::where(['djlsh' => $param['djlsh'], 'hospitalid' => session('hospitalid')])->value('jdbz');
                        if (intval($jdbz) >= 20)
                            $param['jdbz'] = 20;

                    } else if (count($delzhxms) > 0) {
                        //有删除还未体检项目的,查看登记人员是否还有未小结项目,jsover 0弃检 ， 16退费不管
                        $exsitxm = Model('TjjlbModel')
                            ->where(['xh' => $xh, 'hospitalid' => session('hospitalid'),'jsover'=>['in','10,15,20']])
                            ->column('jsover');

                        //有删除项目，取出登记有项目，如果全为已检项目 jdbz设为30，如果无有效项目或者不全为已检项目jdbz不变
                       // print_r(array_key_exists('20',$exsitxm));exit();// print_r($exsitxm);print_r(array_count_values($exsitxm));print_r($exsitxm['20']);print_r(array_count_values($exsitxm)[$exsitxm['20']]); exit();
                        if (array_key_exists('20',$exsitxm)) {
                            if (count($exsitxm) > 0 && count($exsitxm) == array_count_values($exsitxm)[$exsitxm['20']]) {

                                $param['jdbz'] = 30;
                            }
                        }


                    }

                    if (empty($param['tjlb']))
                        $param['tjlb']=0;

                    $result = self::save($param, ['djlsh' => $param['djlsh'], 'hospitalid' => session('hospitalid')]);


                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑登记信息' . $param['tjbh'] . '-' . $param['tjcs'] . '失败', 2);
                        return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $this->getError()];
                    } else {

                        Db::commit();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑登记信息' . $param['tjbh'] . '-' . $param['tjcs'] . '成功', 1);
                        return ['code' => 1, 'tjbh' => $param['tjbh'], 'djlsh' => $param['djlsh'], 'data' => 'edit', 'msg' => '编辑登记信息成功']; //'编辑登记信息成功'
                    }
                }
                //加密字段不更新



            } else { //新增
//以前有登记记录添加新的体检记录
                $djlsh = (int)$this->withTrashed()->where(['hospitalid' => session('hospitalid'), 'djrq' => $param['djrq']])->max('djlsh');

                $djlshstr=$str=str_replace('-','',$param['djrq']);

                if (empty($djlsh) || strpos($djlsh,$djlshstr)===false)
                    $djlsh=str_replace('-', '', $param['djrq']).'0001';
                else
                    $djlsh =$djlsh + 1; //addZero(5, $djlsh + 1, '0');


               // $djlsh=str_replace('-', '', $param['djrq']).$djlsh;

                $param['djlsh'] = $djlsh;
               // $param['tjpc'] = str_replace('-', '', $param['tjrq']);
                $param['djry'] = session('realname');
                $rowdata['wzbgyzm'] =  generateWeirdStr(4).session('hospitalid');
                $param['hospitalid'] = session('hospitalid');

                if (empty($param['tjlb']))
                    $param['tjlb']=0;

                if (!empty($param['tjbh']) && !empty($param['tjcs'])) {

                    //已存在人员新的登记有加密信息的调取最后一次体检数据替换加密数据
                    $cusdate=$this->where(['tjbh' => $param['tjbh'],'hospitalid' => session('hospitalid')])->order('tjcs','desc')->find();

                    foreach ($param as $k=>$v){

                        if ($v=="***")
                            $param[$k]=$cusdate[$k];

                    }

                    $result = $this->save($param);  //insert 不验证

                } else {
//以前无登记信息
                    $param['tjbh'] =$djlsh;// str_replace('-', '', $param['djrq']) . $djlsh;
                    $result = $this->save($param);

                }

                if (false === $result) {

                    Db::rollback();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】新增登记信息'.$param['tjbh'].'-'.$param['tjcs'].'失败',2);
                    return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $this->getError()];

                } else {
                    $zhxm = [];

                  //写入登记人员套餐组合项目
                    if (is_array($zhxms)) {
                        $xh = Model('TjjlbModel')->where('hospitalid',session('hospitalid'))->max('xh');
                        $xh = empty($xh) ? 1 : $xh + 1;
                        foreach ($zhxms as $key => $v) {
                            $zhxm[$key]['xh'] = $xh;
                            $zhxm[$key]['hospitalid'] = session('hospitalid');
                            $zhxm[$key]['tjbh'] = $param['tjbh'];
                            $zhxm[$key]['tjcs'] = $param['tjcs'];
                            $zhxm[$key]['zhxmid'] = $v['zhxmid'];
                            $zhxm[$key]['xmdj'] = $v['xmdj'];
                            $zhxm[$key]['tcwxm'] = $v['tcwxm'];


                            //获取组合项目小项塞入数组待写入体检结果表中
                            $zhxmxm=Model('ZhxmDtModel')->alias('dt')
                                ->join('tjxm','dt.tjxmid=tjxm.id')
                                ->field('tjxmid as xmid,jrxj,dw,ckxx as minckz,cksx as maxckz,memockz')
                                ->where('zhxmid',$v['zhxmid'])->select();

                            // 保存体检组合项目小项
                            $xm=[];
                            foreach ( $zhxmxm as $k =>$value) {


                                $xm[$k]['xh']=$xh;
                                $xm[$k]['zhxmid']=$v['zhxmid'];
                                $xm[$k]['xmid']=$value->xmid;
                                $xm[$k]['dw']=$value->dw;
                                $xm[$k]['jrxj']=$value->jrxj;
                                $xm[$k]['minckz']=$value->minckz;
                                $xm[$k]['maxckz']=$value->maxckz;
                                $xm[$k]['memockz']=$value->memockz;
                                $xm[$k]['hospitalid']=session('hospitalid');

                            }


                            $tjjlmxb=new YsztModel();
                            $result= $tjjlmxb->saveAll($xm,false);

                            if (false ===$result ) {
                                Db::rollback();
                                writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑登记信息' . $param['tjbh'] . '-' . $param['tjcs'] . '失败', 2);
                                return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' =>  $tjjlmxb->getError()];
                            }


                        }

                       //保存体检组合项目
                        $result = Model('TjjlbModel')->allowField(true)->saveAll($zhxm, false);

                    }

                    if (false === $result){
                        Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】新增登记信息'.$param['tjbh'].'-'.$param['tjcs'].'失败',2);
                        return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $this->getError()];
                    } else {

                        Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】新增登记信息'.$param['tjbh'].'-'.$param['tjcs'].'成功',1);
                        return ['code' => 1,  'tjbh' => $param['tjbh'],'djlsh' => $param['djlsh'], 'data' => 'add', 'msg' =>'新增登记信息成功' ];
                    }
                }


            }

        } catch (PDOException $e) {
            Db::rollback();
            return ['code' => 0, 'tjbh' => '', 'djlsh' => '', 'data' => '', 'msg' => $e->getMessage()];
        }


    }



  //确认登记预登记信息
    public function ydjQr($data){

        Db::startTrans();

        try{

           // $result=$this->saveAll($data);

                foreach ($data as $k => $v){

                    $result=$this->where($v)->setField(['jdbz'=>10,'tjrq'=>Date("Y-m-d"),'djrq'=>Date("Y-m-d"),'djry'=>session('realname')]);

                    if ($result===false) {
                        Db::rollback();
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】确认预登记信息'.$v['tjbh'].'-'.$v['tjcs'].'失败', 2);
                        return ['code' => 0, 'data' => '', 'msg' => '确认登记失败!'];
                    }

            }

            Db::commit();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】确认预登记信息成功',1);
            return ['code' => 1, 'data' => '','msg'=>'确认登记成功!'] ;

        }catch(PDOException $e){

            Db::rollback();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】确认预登记信息失败',2);
            return ['code' => 0, 'data' => '','msg'=>$e->getMessage()];

        }


}

        //获取当前日期体检登记
    public function getTjdjList($datetype,$startdate,$enddate,$tjbh="")

    {

        try {

            $map['djrq'] = ['=', Date("Y-m-d")];

            if ($datetype == 'tjrq') {
                unset($map);
                if (!empty($startdate) && !empty($enddate)) {
                    $map['tjrq'] = ['between', [$startdate, $enddate]];
                }else{
                    $map['tjrq'] = ['=', Date("Y-m-d")];
                }

            } else {

                if (!empty($startdate) && !empty($enddate))
                    $map['djrq'] = ['between', [$startdate, $enddate]];

            }


            if (!empty($tjbh))
                $map['tjbh|xm|djlsh'] = ['like', '%'.$tjbh.'%'];
            // $map['djrq'] = ['bet(ween', [strtotime($startdate), strtotime($enddate)]];
            // return  $this->alias('dj')->join('admin','djry=admin.id and dj.hospitalid=admin.hospitalid','left')->field('dj.*,real_name')->where(['djrq'=>strtotime(Date("Y-m-d")),'dj.hospitalid'=>session('hospitalid')])->select();


            $data=$this->where($map)
                ->where(['hospitalid'=>session('hospitalid'),'qjtag'=>1])
                ->select();

           // return $data;
            return ['code' => 1, 'data' => $data, 'msg' => 'ok'];

        }catch(PDOException $e){

            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];

        }

    }


    //预存总检及总检生成
    public function editZj($param,$zdparam){
       try{
           Db::startTrans();
           $param['jdbz']=input('param.jdbz');

           if( $param['jdbz']==35)
               $jdbz='预存总检';

           if( $param['jdbz']==40)
               $jdbz='总检';

           $param['jcrq']= Date("Y-m-d");

           $result = $this->allowField(true)->save($param, ['tjbh' => $param['tjbh'], 'tjcs' => $param['tjcs'], 'hospitalid' => session('hospitalid')]);
           if($result==false){
               Db::rollback();
               writelog(session('uid'),session('username'),'用户【'.session('username').'】'.$param['tjbh'].','.$param['tjcs'].','.$jdbz.'失败',2);
               return ['code'=>0,'data'=>'','msg'=>$this->getError()];
           }else{

               if (is_array($zdparam)) {



                   foreach ($zdparam as $key => $v) {


                        if ($v['sfxyjy']=='false')
                            $v['sfxyjy']=null;
                        else
                            $v['sfxyjy']=1;

                        TjzdbModel::update(['jy'=>$v['jy'],'sfxyjy'=> $v['sfxyjy']],['hospitalid' => session('hospitalid'), 'xh' => $v['xh'], 'zhxmid' =>$v['zhxmid'],'zdid'=>$v['zdid']]);
                        $jydata= model('XjjyModel')->find($v['zdid']);

                        if (!empty($v['jy']) && empty($jydata->jynr)){
                            $jydata->jynr=textAreaStr($v['jy']);
                            $jydata->save();

                        }



                   }


               }

               Db::commit();
               writelog(session('uid'),session('username'),'用户【'.session('username').'】'.$param['tjbh'].','.$param['tjcs'].','.$jdbz.'成功',1);
               return ['code'=>1,'data'=>'','msg'=>$jdbz.'成功'];
           }

       }catch (PDOException $e){
           Db::rollback();
           return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
       }


    }



    //取消总检生成还原待总检状态
    public function deleteZj($tjbh,$tjcs){
        try{
            Db::startTrans();
            $result=$this->where(['tjbh'=>$tjbh,'tjcs'=>$tjcs,'jdbz'=>['>',35],'hospitalid'=>session('hospitalid')])
                ->setField(['jdbz'=>30,'zs'=>'','jy'=>'','tjbz'=>NULL,'bljkz'=>NULL,'jcys'=>'','czy'=>'','jcrq'=>'']);
            if($result===false){
                Db::rollback();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】取消总检'.$tjbh.','.$tjcs.','.session('hospitalid').'失败',2);
                return ['code'=>0,'data'=>'','msg'=>'取消总检失败'];
            }else{
                Db::commit();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】取消总检'.$tjbh.','.$tjcs.','.session('hospitalid').'成功',1);
                return ['code'=>1,'data'=>'','msg'=>'取消总检成功'];
            }

        }catch (PDOException $e){
            Db::rollback();
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
        }


    }

    //保存复查通知信息
    public function fcTzSave($param){
        try{
            Db::startTrans();
            $result=$this->save($param,['tjbh'=>$param['tjbh'],'tjcs'=>$param['tjcs'],'hospitalid'=>session('hospitalid')]);
            if($result==false){
                Db::rollback();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】保存复查通知失败',2);
                return ['code'=>0,'data'=>'','msg'=>'保存复查通知失败!'];
            }else{

                Db::commit();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】保存复查通知成功',1);
                return ['code'=>1,'data'=> $result,'msg'=>'保存复查通知成功!'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code'=> 0, 'data'=> '', 'msg'=> $e->getMessage()];
        }
    }

    //发送复查通知及保存信息
    //$isfs,短信接收人
    //$content 发送内容
    public function fcTzSend($param,$mobile,$content){
        try{
           // Db::startTrans();
            //通过手机发送复查通知
            $sms=new sms($mobile,$content);
            $flag=$sms->sendSms();

            if( $flag!=="num=0"){
               // $result=$this->save($param,['tjbh'=>$param['tjbh'],'tjcs'=>$param['tjcs'],'hospitalid'=>session('hospitalid')]);
               // Db::rollback();
                //writelog(session('uid'), session('username'), '用户【' . session('username') . ')】短信发送复查通知失败(体检编号: ' . $param['tjbh'] . '体检次数:' . $param['tjcs'] . ')', 2);
                // Db::commit();
                //writelog(session('uid'), session('username'), '用户【' . session('username') . ')】短信发送复查通知成功(体检编号: ' . $param['tjbh'] . '体检次数:' . $param['tjcs'] . ')', 1);
                $result=$this->save($param,['tjbh'=>$param['tjbh'],'tjcs'=>$param['tjcs'],'hospitalid'=>session('hospitalid')]);

                if ( $result===false)
                    return ['code' => 2, 'data' => $result, 'msg' => '发送短信成功，记录失败!'];
                else
                    return ['code' => 1, 'data' => $result, 'msg' => '发送复查通知成功'];

            }else{

                return ['code' => 0, 'data' => '', 'msg' => '短信发送复查通知失败'];

            }
        }catch (ErrorException $e){
           // Db::rollback();
            return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
        }
    }
}