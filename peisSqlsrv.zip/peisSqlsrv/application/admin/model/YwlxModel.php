<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;

class YwlxModel extends Model
{
	//体检单位
	protected $name = "ywlx";
	
	
	/**
	 * [getOneYwlx获取指定体检类型]
	 * @author [李勇] [peis999]
	 */
	public function getOneYwlx($id)
	{
		return $this->find($id);
	}
	
	/**
	 * [getAllYwlx 获取全部体检类型]
	 * @author [李勇] [peis999]
	 */
	public function getAllYwlx()
	{
		return $this->where('isdel',1)->order('id asc')->select();
	}





	/**
	 * [ editYwlx参数【判断是新增还是更新 体检单位]
	 * @author [李勇] [peis999]
	 */
	public function editYwlx($param)
	{


       // Db::startTrans();
		try {

            $deitfs=$param['editfs'];
            unset($param['editfs']);
            if (!empty($deitfs=="edit")) { //更新


                $result= $this->validate('YwlxValidate')->save($param, ['id' => $param['id']]);

                if (false === $result) {
                   // Db::rollback();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑业务类型'. $param['mc'].'失败(ID='.$param['id'].$this->getError().')',2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {

                   // Db::commit();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑业务类型'. $param['mc'].'成功(ID='.$param['id'].')',1);
                    return ['code' => 2, 'data' => $param, 'msg' => '编辑业务类型' . $param['mc'] . '成功'];

                }
				
			} else { //新增


                $param['softid']=$param['id'];
                $findid=$this->find($param['id']);
                if (!empty($findid)){
                   // Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => 'ID已存在,不能输入重复的ID'];

                }


                $result = $this->validate('YwlxValidate')->save($param);

                if (false === $result) {
                    //Db::rollback();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】新增业务类型'. $param['mc'].'失败(ID='.$param['id'].$this->getError().')',2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {

                   // Db::commit();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】新增业务类型'. $param['mc'].'成功(ID='.$param['id'].')',1);
                    return ['code' => 1, 'data' => $param, 'msg' => '新增业务类型' . $param['mc'] . '成功'];


                }
            }
			
		}catch( PDOException $e){
           // Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}




	/**
	 * delYwlx  删除体业务类型
	 * @param $id $name
	 */
	public function delYwlx($id)
	{
		Db::startTrans();
		try{

           /* if (Model('TjdjModel')->where('ywlxid',$id)->find()){

                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => '业务类型已被引用，不可删除'];
             }*/


			$result=$this->where('id|pid',$id )->delete();
            if ($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检业务类型失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => '删除业务类型失败'];
            } else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检业务类型成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除业务类型成功'];

            }
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
	/**
	 * editSoft 排序
	 * @author [李勇] [peis999]
	 */
	public function editSoft($id,$type,$targetid)
	{
		Db::startTrans();
		try{
			
			$softId=$this->where('id',$id)->value('softid');
			$targerSoftId=$this->where('id',$targetid)->value('softid');
			// $softId=$this->field('softid')->get($id);
			// $targerSoftId=$this->field('softid')->get($targetid);
			
			if ($softId >$targerSoftId)
				$map['softid']=['between',$targerSoftId.','. $softId];
			else
				$map['softid']=['between',$softId.','.$targerSoftId];
			
			//$map['softid']=['between','lt,gt'];
			
			if ($type=="prev") {
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId);
				} else{
					$map['softid']=['between',($softId+1).','.($targerSoftId-1)];
					$this->where($map)->setDec('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId-1);
				}
				
				
			}else{
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId+1);
				} else{
					$map['softid']=['between',($softId+1).','.$targerSoftId];
					$this->where($map)->setDec('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId);
				}
				
			}
			
			Db::commit();
			return ['code' => 1, 'data' => '', 'msg' => '调整业务类型排序成功'];
			
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
}