<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class JbmbCjjgModel extends Model
{
//疾病模板
    protected $name = "jbmb_cjjg";


    /**
     * [ jbmbAddCjjg参数【添加疾病模板常见结果]
     * @author [李勇] [peis999]
     */
    public function jbmbAddCjjg($param)
    {

        Db::startTrans();
        try {

           //新增
                $softid = $this->where(['jbmbid'=>$param['jbmbid']])->max('softid');
                $softid  = empty($softid) ? 1 : $softid + 1;
                $param['softid'] =  $softid ;
               // $param['jbmbid']=$jbmbid;
               // $param['tjlxid']=$tjlxid;
               // $param['cjjgid']=$cjjgid;
                $result = $this->save($param);  //insert 不验证

                if (false == $result) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    Db::commit();
                    return ['code' => 1, 'data' => '', 'msg' => '新增疾病模板常见结果成功'];
                }


        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }




    //添加疾病模板多项常见结果
    public function jbmbAddsCjjg($param)
    {
        Db::startTrans();
         try {

                 $softid = $this->where(['jbmbid'=>$param[0]['jbmbid']])->max('softid');
                 $softid  = empty($softid) ? 1 : $softid + 1;
                 //$param['softid'] =  $softid ;
                 $i=0;
                 foreach ($param as $k=>$v)
                 {
                     $param[$i]['softid']=$softid;
                     $softid++;
                     $i++;

                 }
                 $result = $this->saveAll($param, false);
                 if (false==$result) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' =>  $this->getError()];
                 }else {
                    Db::commit();
                    return ['code' => 1, 'data' => '', 'msg' => '新增疾病模板常见结果成功'];
                 }
            } catch (PDOException $e) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }

    }

    /**
     * delJbmbCjjg  删除疾病模板疾病信息
     * @param $jbmbid $cjjgid $name
     */
    public function delJbmbCjjg($jbmbid,$cjjgid,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where(['jbmbid'=>$jbmbid,'cjjgid'=>$cjjgid])->delete();
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除疾病模板疾病信息' . $name . '失败(ID=' .$jbmbid.'-'.$cjjgid . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除疾病模板失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除疾病模板疾病信息' . $name . '成功(ID=' .$jbmbid.'-'.$cjjgid . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除疾病模板疾病信息成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    //删除疾病模板（多个常见结果）
    public function delMulcjjg($jbmbid,$cjjgids)
    {
        Db::startTrans();
        try {

            $result = $this->where('jbmbid',$jbmbid)->whereIn('cjjgid',$cjjgids)->delete();
            // $logstr=arr2str($param);
            if ($result == false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除疾病模板多个常见结果失败('. $jbmbid . "-".$cjjgids.')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '移除疾病模板多个常见结果失败'];
            } else {

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】移除疾病模板多个常见结果成功('. $jbmbid .  '-' .$cjjgids . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '移除疾病模板多个常见结果成功'];
            }

        } catch (PDOException $e) {
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //   调整疾病模板疾病信息排序
    public function editCjjgSoft($jbmbid,$cjjgid,$type,$targetid)
    {
        Db::startTrans();
        try{

            $softId=$this->where(['jbmbid'=>$jbmbid,'cjjgid'=>$cjjgid])->value('softid');
            $targerSoftId=$this->where(['jbmbid'=>$jbmbid,'cjjgid'=>$targetid])->value('softid');
            // $softId=$this->field('softid')->get($id);
            // $targerSoftId=$this->field('softid')->get($targetid);

            $where['jbmbid']=['=',$jbmbid];
            $where['cjjgid']=['=',$cjjgid];


            $map['jbmbid']=['=',$jbmbid];

           /* if ($softId >$targerSoftId)
                $map['softid']=['between',$targerSoftId.','. $softId];
            else
                $map['softid']=['between',$softId.','.$targerSoftId];*/


            if ($type=="prev") {

                if ($softId >$targerSoftId)
                {
                    $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                    $this->where($map)->setInc('softid');
                    $this->where( $where)->setField('softid', $targerSoftId);
                } else{
                    $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                    $this->where($map)->setDec('softid');
                    $this->where( $where)->setField('softid', $targerSoftId-1);
                }


            }else{

                if ($softId >$targerSoftId)
                {
                    $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                    $this->where($map)->setInc('softid');
                    $this->where( $where)->setField('softid', $targerSoftId+1);
                } else{
                    $map['softid']=['between',($softId+1).','.$targerSoftId];
                    $this->where($map)->setDec('softid');
                    $this->where($where)->setField('softid', $targerSoftId);
                }

            }

            Db::commit();
            return ['code' => 1, 'data' => '', 'msg' => '调整疾病模板疾病信息排序成功'];

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
}