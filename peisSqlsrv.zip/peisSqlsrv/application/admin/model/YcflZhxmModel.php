<?php
namespace app\admin\model;
use think\Db;
use think\exception\PDOException;
use think\Model;
class YcflZhxmModel extends Model{
    protected $name='jbmb_ycfl_zhxm';

    //移除异常分类组合项目
    /**
     * @param $jbmbid
     * @param $ycflid
     * @param $zhxmid
     * @param $name
     * @return array
     */
    public function delYcflZhxmSel($jbmbid,$ycflid,$zhxmid,$name){
            Db::startTrans();
            try{
                $result=$this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid,'zhxmid'=>$zhxmid])->delete();
                if($result==false){
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】移除组合项目'.$name.'失败(ID='.$jbmbid.'-'.$ycflid.'-'.$zhxmid.')',2);
                    Db::rollback();
                    return ['code'=>0,'data'=>'','msg'=>'移除组合项目失败'];
                }else{
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】移除组合项目'.$name.'成功(ID='.$jbmbid.'-'.$ycflid.'-'.$zhxmid.')',2);
                    Db::commit();
                    return ['code'=>1,'data'=>'','msg'=>'移除组合项目成功'];
                }

            }catch (PDOException $e){
                Db::rollback();
                return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
            }
    }

    //移除异常分类组合项目(多选)
    /**
     * @param $jbmbid
     * @param $ycflid
     * @param $zhxmids
     * @return array
     */
    public function delYcfMulSelZhxm($jbmbid,$ycflid,$zhxmids){
            Db::startTrans();
            try{
                $result=$this->where(['jbmbid'=>$jbmbid,'ycflid'=>$ycflid])->whereIn('zhxmid',$zhxmids)->delete();
                if($result==false){
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】移除组合项目失败(ID='.$jbmbid.'-'.$ycflid.'-'.$zhxmids.')',2);
                    Db::rollback();
                    return ['code'=>0,'data'=>'','msg'=>'移除组合项目失败'];
                }else{
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】移除组合项目成功(ID='.$jbmbid.'-'.$ycflid.'-'.$zhxmids.')',2);
                    Db::commit();
                    return ['code'=>1,'data'=>'','msg'=>'移除组合项目成功'];
                }

            }catch (PDOException $e){
                Db::rollback();
                return ['code'=>0,'data'=>'','msg'=>$e->getMessage()];
            }

    }
}