<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class HospitalModel extends Model
{
    protected $name = 'hospital';

    /**
     * 根据搜索条件获取医院列表信息
     */
    public function getHospitalsByWhere($map, $Nowpage, $limits)
    {
        return $this->where($map)->page($Nowpage, $limits)->order('id desc')->select();
    }

    /**
     * 根据搜索条件获取所有的医院数量
     * @param $where
     */
    public function getAllHospitals($where)
    {
        return $this->where($where)->count();
    }

    /**
     * 插入分院信息
     * @param $param
     */
    public function insertHospital($param)
    {
        try{
			
			$id=$this->max('id');

            if (empty($id))
                $param['id']=1000;
            else if(strlen($id+1)%2==0)
                $param['id']=$id+1;
            else
                $param['id']=($id+1)*10;

			//$param['id']=empty($id)?10:strlen($id+1)%2==0?$id+1:($id+1)*10;
            //清除 省市请求参数 因为表没这两个字段
            unset($param['province']);
            unset($param['city']);
            if (!isset($param['status']))
                $param['status']=0;
            //根据所在区域生成医院流水号
            $param['towncode']=$param['towncode']."-".addZero(4,$param['id'],"0");
            $result = $this->validate('HospitalValidate')->save($param);

            if(false === $result){
                writelog(session('uid'),session('username'),'医院【'.$param['hospitalname'].'】添加失败',2);
                return ['code' => -1, 'data' => '', 'msg' => $this->getError()];
            }else{
                writelog(session('uid'),session('username'),'医院【'.$param['hospitalname'].'】添加成功',1);
                return ['code' => 1, 'data' => '', 'msg' => '添加分院成功'];
            }
        }catch( PDOException $e){
            return ['code' => -2, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * 编辑医院信息
     * @param $param
     */
    public function editHospital($param)
    {

        try{

            if (!isset($param['status']))
                $param['status']=0;

            $result = $this->validate('HospitalValidate')->save($param,['id' => $param['id']]);
            //$result =  $this->save($param, ['id' => $param['id'],'hospitalid'=> $param['hospitalid']]);
            if(false === $result){
                writelog(session('uid'),session('username'),'编辑医院【'.$param['hospitalname'].'】信息失败',2);
                return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
            }else{
                writelog(session('uid'),session('username'),'编辑医院【'.$param['hospitalname'].'】信息成功',1);
                return ['code' => 1, 'data' => '', 'msg' => '编辑医院成功'];
            }
        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }

    }


    /**
     * 根据医院id获取医院信息
     * @param $id
     */
    public function getOneHospital($id)
    {
        return $this->where('id', $id)->find();
    }


    /**
     * 删除医院
     * @param $id
     */
    public function delHospital($id)
    {   
	    Db::startTrans();
        try{

            $restlt=$this->where('id', $id)->setfield('isdel',0);
            Db::name('admin')->where('hospitalid', $id)->setfield('isdel',0);
			//Db::name('department')->where('hospitalid', $id)->setfield('isdel',0);
            if ( $restlt==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除医院(ID=' . $id . ')及医院【科室和操作员】失败', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除医院及医院【科室和操作员】失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除医院(ID=' . $id . ')及医院【科室和操作员】成功', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除医院及医院【科室和操作员】成功'];
            }

        }catch( PDOException $e){
			Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
	
	
	
	//定义表关联
	
}