<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class SgggModel extends Model
{
	//试管规格
	protected $name = "tjjylx";
	
	
	/**
	 * [getOneSggg 获取节点数据]
	 * @author [俞晴] [peis999]
	 */
	public function getOneSggg($id)
	{
		return $this->find($id);
	}
	
	
	/**
	 * [ editSggg参数【判断是新增还是更新 试管规格]
	 * @author [俞晴] [peis999]
	 */
	public function editSggg($param)
	{
		
		try {
			
			if (!empty($param['id'])) { //更新
				$result = $this->validate('SgggValidate')->save($param,['id'=>$param['id']]);  //update不验证
				if (false === $result) {
					return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
				} else {
					return ['code' => 1, 'data' => '', 'msg' => '编辑试管规格' . $param['lxname'] . '成功'];
				}
				
			} else { //新增
				$id = $this->max('id');
				$param['id'] = empty($id) ? 1 : $id + 1;
				$param['lxtype'] = 'SGGG';
				$param['softid'] = $param['id'];
				$result = $this->validate('SgggValidate')->save($param);  //insert 不验证
				
				if (false === $result) {
					return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
				} else {
					return ['code' => 1, 'data' => '', 'msg' => '新增试管规格' . $param['lxname'] . '成功'];
				}
				
			}
			
		}catch( PDOException $e){
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
	/**
	 * delLclx  删除试管规格
	 * @param $id $name
	 */
	public function delSggg($id,$name)
	{
		Db::startTrans();
		try{
			
			$result=$this->where('id',$id)->setField('isdel',0);
            if($result==false) {
                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除试管规格'.$name.'失败(ID='.$id.')',2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除试管规格失败'];
            }else{

                writelog(session('uid'),session('username'),'用户【'.session('username').'】删除试管规格'.$name.'成功(ID='.$id.')',1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除试管规格成功'];
            }
			
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
	
	/**
	 * editSoft 排序
	 * @author [俞晴] [peis999]
	 */
	public function editSoft($id,$type,$targetid)
	{
		Db::startTrans();
		try{
			
			$softId=$this->where('id',$id)->value('softid');
			$targerSoftId=$this->where('id',$targetid)->value('softid');
			// $softId=$this->field('softid')->get($id);
			// $targerSoftId=$this->field('softid')->get($targetid);
			
			if ($softId >$targerSoftId)
				$map['softid']=['between',$targerSoftId.','. $softId];
			else
				$map['softid']=['between',$softId.','.$targerSoftId];
			
			//$map['softid']=['between','lt,gt'];
			
			if ($type=="prev") {
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId);
				} else{
					$map['softid']=['between',($softId+1).','.($targerSoftId-1)];
					$this->where($map)->setDec('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId-1);
				}
				
				
			}else{
				
				if ($softId >$targerSoftId)
				{
					$map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
					$this->where($map)->setInc('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId+1);
				} else{
					$map['softid']=['between',($softId+1).','.$targerSoftId];
					$this->where($map)->setDec('softid');
					$this->where('id', $id)->setField('softid', $targerSoftId);
				}
				
			}
			
			Db::commit();
			return ['code' => 1, 'data' => '', 'msg' => '调整试管规格排序成功'];
			
		}catch( PDOException $e){
			Db::rollback();
			return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
		}
	}
}