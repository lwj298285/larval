<?php

namespace app\admin\model;
use think\Model;
//use think\model\Merge;
use think\Db;
use think\Validate;
class CjjgModel extends Model
{
//体检项目常见结果表名不带前缀
    protected $name = "cjjg";


/* 定义关联模型列表 不适用
    protected  $relationModel = ['xjjy'];
    // 定义关联外键
    protected $fk = 'xmjgid';
    protected $mapFields = [
        // 为混淆字段定义映射
        'tjlxid' =>  'keyword.tjlxid',
        'tjxmid' =>  'keyword.tjxmid',
        'jytjlxid'=>  'xjjy.tjlxid',
        'jytjxmid'=>  'xjjy.tjxmid',

    ];*/

    /**
     * [getOneTjxm 获取体检项目常见结果列表]
     * @author [李勇] [peis999]
     */
    public function getList($tjxmid)
    {
        return $this->where(['tjxmid'=>$tjxmid,'isdel'=>1])->order('softid')->select();
    }

    /**
     * [ editCjjg参数【判断是新增还是更新 常见结果]
     * @author [李勇] [peis999]
     */
    public function editCjjg($param)
    {

        try {


            if (empty($param['lclxid'])) {
                $validate = new Validate([
                    ['ms', 'require', '描述不能为空'],
                    ["ms", "unique:cjjg,ms={$param['ms']}&tjlxid={$param['tjlxid']}&tjxmid={$param['tjxmid']}&isdel=1", "诊断建议已存在"]

                ]);



            }else{
                $validate = new Validate([
                    ['ms', 'require', '描述不能为空'],
                    ["ms", "unique:cjjg,ms={$param['ms']}&tjlxid={$param['tjlxid']}&lclxid={$param['lclxid']}&tjxmid={$param['tjxmid']}&isdel=1", "诊断建议已存在",]
                ]);
            }

            if (!empty($param['id'])) { //更新


                $check=$validate->check($param);
                if (false === $check) {
                    return ['code' => 0, 'data' => '', 'id' => $param['id'], 'msg' => $validate->getError()];
                }else {
                    $result = $this->allowField(true)->save($param, ['id' => $param['id']]);  //update不验证
                    if (false === $result) {
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑体检项目常见结果' . $param['ms'] . '失败(ID=' . $param['id'] . $this->getError(). ')', 2);
                        return ['code' => 0, 'data' => '', 'id' =>$param['id'], 'msg' => $this->getError()];

                    } else {
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】编辑体检项目常见结果' . $param['ms'] . '成功(ID=' . $param['id'] . ')', 1);
                        return ['code' => 1, 'data' => '', 'id' => $param['id'], 'msg' => '编辑体检项目常见结果' . $param['ms'] . '成功'];
                    }
                }

            } else { //新增
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];

                $check=$validate->check($param);

                if (false === $check) {
                    return ['code' => 0, 'data' => '', 'id' => '', 'msg' => $validate->getError()];
                }else {
                    $result = $this->allowField(true)->save($param);  //insert 不is证

                    if (false === $result) {
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加体检项目常见结果' . $param['ms'] . '失败(ID=' . $param['id'] . $this->getError(). ')', 2);
                        return ['code' => 0, 'data' => '', 'id' => '', 'msg' => $this->getError()];
                    } else {
                        writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加体检项目常见结果' . $param['ms'] . '成功(ID=' . $param['id'] . ')', 1);
                        return ['code' => 1, 'data' => '', 'id' => $param['id'], 'msg' => '添加体检项目常见结果' . $param['ms'] . '成功'];
                    }
                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '','id'=>'', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delCjjg 删除体检项目结果
     * @param $id $name
     */
    public function delCjjg($id,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where(['id'=>$id])->setField('isdel',0);
            if( $result==false)
            {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检项目常见结果' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目常见结果失败'];
            }else{
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除体检项目常见结果' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除体检项目常见结果成功'];

            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //调整体检项目结果排序
        public function editSoft($param)
        {

            try {

                // if (!empty($param)) { //更新

                $result = $this->validate("CjjgValidate")->saveAll($param,true);  //update排序
                if (false === $result) {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检结果排序失败',1);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                } else {
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑体检结果排序成功',1);
                    return ['code' => 1, 'data' => '', 'msg' => '编辑体检结果排序成功'];
                }

            }catch( PDOException $e){
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }

        }
}