<?php

namespace app\admin\model;
use think\Model;
use think\Db;

class XzqyModel extends Model
{
//行政区域
    protected $name = "region";


    /**
     * [getOneXzqy 获取某个行政区域]
     * @author [李勇] [peis999]
     */
    public  function getOneXzqy($id)
    {
        return $this->where('isdel',1)->find($id);
    }



    public function getArea($type,$pid)
    {

        $data= $this->where(['type'=>$type,'pid'=>$pid,'isdel'=>1])->select();

        return $data;

    }

    /**
     * [ editXzqy参数【判断是新增还是更新 行政区域]
     * @author [李勇] [peis999]
     */
    public function editXzqy($param)
    {


        try {

            if (!empty($param['id'])) { //更新
                $result = $this->validate('XzqyValidate')->save($param,['id'=>$param['id']]);  //update不验证
                if (false === $result) {
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    return ['code' => 1, 'data' => '', 'msg' => '编临行政区域' . $param['name'] . '成功'];
                }

            } else { //新增


                $param['pid'] = empty($param['pid']) ? 0 :$param['pid'];

                if ($param['pid']==0) {
                    $param['type'] = 1;
                }else{

                    $param['type'] = ((int)$this->where('id',$param['pid'] )->value('type'))+1;
                }

                $pidMaxCld = (int)$this->where('pid',$param['pid'] )->max('id');


                if ( empty($pidMaxCld)){
                    switch ($param['type']){

                        case 1:
                            $param['id'] =110000;
                            break;
                        case 2:
                            $param['id'] =$param['pid']+100;
                            break;
                        case 3:
                            $param['id'] =$param['pid']+1;
                            break;
                        default:


                    }

                }else{

                    switch ($param['type']){

                        case 1:
                            $param['id'] =$pidMaxCld+10000;
                            break;
                        case 2:
                            $param['id'] =$pidMaxCld+100;
                            break;
                        case 3:
                            $param['id'] =$pidMaxCld+1;
                            break;
                        default:


                    }
                }

                $result = $this->validate('XzqyValidate')->save($param);  //insert 不验证


                if (false === $result) {
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    return ['code' => 1, 'data' => '', 'msg' => '新增行政区域' . $param['name'] . '成功'];
                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }


    }

    /**
     * delXzqy  删除行政区域
     * @param $id $name
     */
    public function delXzqy($ids,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where('id','in',$ids)->setField('isdel',0);
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除行政区域' . $name . '失败(ID=' . $ids . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除行政区域失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除行政区域' . $name . '成功(ID=' . $ids . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除行政区域成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



}