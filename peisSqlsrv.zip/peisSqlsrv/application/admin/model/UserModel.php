<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use mail\Phpmailer;
use sms\Sms;

class UserModel extends Model
{
    protected $name = 'admin';

    /**
     * 根据搜索条件获取用户列表信息
     */
    public function getUsersByWhere($map, $Nowpage, $limits)
    {
		$tbprefix=config("database.prefix");
        return $this->field($tbprefix.'admin.*,title, hospitalname')
            ->join($tbprefix.'auth_group', $tbprefix.'admin.groupid ='.$tbprefix.'auth_group.id','left')
            ->join($tbprefix.'hospital',$tbprefix.'admin.hospitalid ='.$tbprefix.'hospital.id','left')
            ->where($map)->page($Nowpage, $limits)->order('id desc')->select();
		
		
		
    }

    /**
     * 根据搜索条件获取所有的用户数量
     * @param $where
     */
    public function getAllUsers($where)
    {
        return $this->where($where)->count();
    }

    /**
     * insertUser()插入用户信息
     * @param $param
     */
    public function insertUser($param)
    {
        Db::startTrans();

        try {

            if (!empty($param['hospitalid']))
            {

                $id = Db::name('admin')->where('hospitalid', $param['hospitalid'])->max('id');
                $param['id']=empty($id)?1:$id+1;
                $towncode=Db::name('hospital')->where('id',$param['hospitalid'])->find();
                $jobnum=$towncode['towncode'];
                $param['jobnum']= $jobnum."-".addZero(3,$param['id'],"0");
            }else{

                $id = Db::name('admin')->where('hospitalid', '=', 0)->max('id');
                $param['id']=empty($id)?1:$id+1;
                $param['jobnum'] = $param['id'];
             }

            if (!isset($param['sfzjys']))
                $param['sfzjys']=0;

            $param['password']=encrypt($param['jobnum'].'@'.$param['password'],'E');

            $result = $this->allowField(true)->validate('UserValidate')->save($param,false);


            if(false === $result){
                Db::rollback();
                return ['code' => 0, 'jobnum' => '','id' => '','msg' => $this->getError()];
            }else{

                $accdata = ['uid' => $param['id'], 'group_id' => $param['groupid'], 'hospital_id' => $param['hospitalid']];
                Db::name('auth_group_access')->insert($accdata);
                Db::commit();
                writelog(session('uid'),session('username'),'用户【'.$param['username'].'】添加成功',1);
                return ['code' => 1, 'jobnum' => $param['jobnum'],'id' => $param['id'], 'msg' => '添加用户成功'];
            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'jobnum' => '','id' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * [editUser( 编辑用户信息]
     * @author [李勇] [peis999]
     */
    public function editUser($param)
    {
        try{

          Db::startTrans();

          if(empty($param['password'])){
               unset($param['password']);
           }else{
                 $param['password']=encrypt($param['jobnum'].'@'.$param['password'],'E');

           }

            if (!isset($param['sfzjys']))
                $param['sfzjys']=0;

           $result =  $this->allowField(true)->validate('UserValidate')->save($param, ['jobnum' => $param['jobnum']]);

            if(false === $result){
                Db::rollback();
                return ['code' => 0, 'jobnum' => '','id' => '', 'msg' => $this->getError()];
            }else{
                Db::name('auth_group_access')->where(['uid' => $param['id'], 'hospital_id' => $param['hospitalid']])->setfield('group_id',$param['groupid']);
                Db::commit();
                writelog(session('uid'),session('username'),'编辑用户【'.$param['username'].'】信息成功',1);
                return ['code' => 1, 'jobnum' =>  $param['jobnum'],'id' => $param['id'], 'msg' => '编辑用户成功'];
            }
        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'jobnum' => '','id' => '', 'msg' => $e->getMessage()];
        }

    }



    /**
     * x修改用户密码
     * @$uid 用户id,$hospitalid医院id,$password新密码
     */
    public function editPassword($uid,$hospitalid,$password)
    {
       // Db::startTrans();

        try{
            $result =  $this->validate('UserValidate')->where(['id' =>$uid,'hospitalid'=>$hospitalid])->update(['password'=>$password]);
            if(false === $result){
                //Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
            }else{
               // Db::commit();
                writelog(session('uid'),session('username'),'用户【'.session('username').'】修改密码成功',1);
                return ['code' => 1, 'data' => '', 'msg' => '修改密码成功'];
            }
        }catch( PDOException $e){
           // Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }




    /**
     * 根据管理员id获取角色信息
     * @param $id
     */
    public function getOneUser($id,$hospitalid)
    {
        return $this->where(['id'=>$id,'hospitalid'=>$hospitalid])->find();
    }


    /**
     * 删除管理员y
     * @param $id
     */
    public function delUser($jobnum)
    {
        Db::startTrans();
        try{

            $result=$this->where('jobnum',$jobnum)->setField('isdel',0);

            if ($result===false)
                throw new \Exception();

            Db::commit();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】删除操作员工号（'.$jobnum.'）成功',1);
            return ['code' => 1, 'data' => '', 'msg' => '删除管理员成功'];

        }catch( \Exception $e){
            Db::rollback();
            writelog(session('uid'),session('username'),'用户【'.session('username').'】删除操作员工号（'.$jobnum.'）失败',2);
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * 重置用户密码并发通过邮件或者手机号码找回
     * @param $id
     */
    public function resetPassword($uid,$jobnum,$username,$hospitalid,$email,$mobile,$newpassword)
    {
        Db::startTrans();
        try{
            if(config('forgetpwd')=='email') {
                //通过邮件重置用户密码
                $mailer = new Phpmailer();
                $context = '你好, ' . $username . '! 重置后您的新密码为' . $newpassword . '，登录后可自行修改！';
                $flag = $mailer->mail($email, $context, '重置密码');
                if ($flag['code'] == 1) {

                    $result= $this->where('email', $email)->setfield('password', encrypt($jobnum.'@'.$newpassword));
                    if ($result==false) throw  new \Exception();


                } else {
                    Db::rollback();
                    writelog($uid, $username, '用户【' . $username . ')】重置密码失败' . $flag['msg'] . '(ID=' . $uid . ')', 2, $hospitalid);
                    return ['code' => $flag['code'], 'data' => '', 'msg' => $flag['msg']];

                }
            }else{
                   //通过手机重置用户密码

                 $sms=new sms($mobile,'用户：'.$username.'您重置后的新密码为：'.$newpassword);
                 $result=$sms->sendSms();


                 if ($result!=='num=0')

                    $result= $this->where('mobile', $mobile)->setfield('password', encrypt($jobnum.'@'.$newpassword));
                    if ($result==false) throw  new \Exception();

                 else {
                     Db::rollback();
                     writelog($uid, $username, '用户【' . $username . ')】重置密码失败(ID=' . $uid . ')', 2, $hospitalid);
                     return ['code' => 0, 'data' => '', 'msg' => '手机密码重置失败'];
                 }
            }

            Db::commit();
            writelog($uid, $username, '用户【' . $username . ')】重置密码成功(ID=' . $uid . ')', 1, $hospitalid);
            return ['code' => 1, 'data' => '', 'msg' => '重置密码成功'];

        }catch( \Exception $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }
}