<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Validate;

class LclxModel extends Model
{
//临床类型
    protected $name = "lclx";


    /**
     * [getOneLclx 获取临床类型节点数据]
     * @author [李勇] [peis999]
     */
    public function getOneLclx($id)
    {
        return $this->find($id);
    }


    /**
     * [ editLclx参数【判断是新增还是更新 临床类型]
     * @author [李勇] [peis999]
     */
    public function editLclx($param)
    {

        try {

            $validate = new Validate([
                ["lclxname","unique:lclx,lclxname={$param['lclxname']}&isdel=1","临床类型(".$param['lclxname'].")已存在",]
            ]);

            if (!empty($param['id'])) { //更新


                $result=$validate->check($param);

                 //update不验证
                if (false === $result) {
                   // writelog(session('uid'),session('uesrname'),'编辑临床类型['.$param['lclxname'].']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param, ['id' => $param['id']]);
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'编辑临床类型['.$param['lclxname'].']失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        writelog(session('uid'),session('uesrname'),'编辑临床类型['.$param['lclxname'].']成功',1);
                       return ['code' => 1, 'data' => '', 'msg' => '编辑临床类型' .$param['lclxname'].'成功'];
                   }
                }

            } else { //新增
                $id = $this->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['sortid'] = $param['id'];

                $result=$validate->check($param);

                if (false === $result) {
                    //writelog(session('uid'),session('uesrname'),'新增临床类型['.$param['lclxname'].']失败',2);
                    return ['code' => 0, 'data' => '', 'msg' => $validate->getError()];
                } else {
                    $result = $this->save($param);  //insert 不验证
                    if (false === $result) {
                        writelog(session('uid'),session('uesrname'),'新增临床类型['.$param['lclxname'].']失败'.$this->getError(),2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                    } else {
                        writelog(session('uid'),session('uesrname'),'新增临床类型['.$param['lclxname'].']成功',1);
                        return ['code' => 1, 'data' => '', 'msg' => '新增临床类型' . $param['lclxname'] . '成功'];
                    }

                }

            }

        }catch( PDOException $e){
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     * delLclx  删除临床类型
     * @param $id $name
     */
    public function delLclx($id,$name)
    {
        Db::startTrans();
        try{

            $result=$this->where('id',$id)->setField('isdel',0);
            //Db::name('auth_group_access')->where(array('uid'=>$id,'group_id'=>$groupid,'hospital_id'=>$hospitalid))->delete();
            if ( $result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除临床类型' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除临床类型失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除临床类型' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除临床类型成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

        public function editSoft($id,$type,$targetid)
        {
            Db::startTrans();
            try{

                $softId=$this->where('id',$id)->value('sortid');
                $targerSoftId=$this->where('id',$targetid)->value('sortid');
               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

                if ($softId >$targerSoftId)
                    $map['sortid']=['between',$targerSoftId.','. $softId];
                else
                    $map['sortid']=['between',$softId.','.$targerSoftId];

                //$map['softid']=['between','lt,gt'];

                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['sortid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('sortid');
                        $this->where('id', $id)->setField('sortid', $targerSoftId);
                    } else{
                        $map['sortid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('sortid');
                        $this->where('id', $id)->setField('sortid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['sortid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('sortid');
                        $this->where('id', $id)->setField('sortid', $targerSoftId+1);
                    } else{
                        $map['sortid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('sortid');
                        $this->where('id', $id)->setField('sortid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整临床类型排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}