<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use think\Collection;
use think\Validate;
class XmdzModel extends Model
{
//体检项目表名不带前缀

    protected $name = "xmdz";



   /***
   addXmdz 添加LIS项目对照
    * @param xmid,lisxmid,hospitalid
   ***/
    public function addXmdz($param)
    {

        Db::startTrans();
        try {

            $validate = new Validate([
                ["xmid","unique:xmdz,xmid={$param['xmid']}&isdel=1&lisxmid={$param['lisxmid']}&hospitalid={$param['hospitalid']}","项目对照已存在",]
            ]);


            $result=$validate->check($param);

            if (false === $result) {

                return ['code' => 0, 'data' => '', 'msg'  => $validate->getError()];
            } else {


                $result = $this->allowField(true)->save($param);
                if (false === $result) {
                    Db::rollback();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加项目对照失败' . $this->getError() . ')', 2);
                    return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
                } else {
                    Db::commit();
                    writelog(session('uid'), session('username'), '用户【' . session('username') . '】添加项目对照成功)', 1);
                    return ['code' => 1, 'data' => '', 'msg' => '添加项目对照成功'];

                }


            }



        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }



    /***
    delXmdz 添加LIS项目对照
     * @param xmid,lisxmid,hospitalid
     ***/
    public function delXmdz($param)
    {

        Db::startTrans();
        try {



            $result = $this->where(['hospitalid'=>session('hospitalid'),'xmid'=>$param['xmid'],'lisxmid'=>$param['lisxmid']])->setField('isdel', 0);
            if (false === $result) {
                Db::rollback();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除项目对照(xmid='.$param['xmid'].',lisxmid='.$param['lisxmid'].')失败' . $this->getError(), 2);
                return ['code' => 0, 'data' => '', 'msg' => $this->getError()];
            } else {
                Db::commit();
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除项目对照(xmid='.$param['xmid'].',lisxmid='.$param['lisxmid'].')成功', 1);
                return ['code' => 1, 'data' => '', 'msg' => '删除项目对照成功'];

            }


        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


}