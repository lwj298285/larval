<?php

namespace app\admin\model;
use think\Model;
use think\Db;
use traits\model\SoftDelete;
use think\Validate;

class TjtcModel extends Model
{
//套餐设置表名不带前缀
    protected $name = "tjtc_hd";
    use SoftDelete;
    protected $deletetime = 'delete_time';


    /**
     * [getOneTjtc获取体检套餐]
     * @author [李勇] [peis999]
     */
    public function getOneTjtc($id)
    {
        return $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->find();
    }


    /**
     * [ editTjxm参数【判断是新增还是更新 组合体检项目]
     * @author [李勇] [peis999]
     */
    public function editTjtc($param)
    {

        try {
            if(!isset($param['status']))
                $param['status']=0;

            if(!isset($param['sfwzyytc']))
                $param['sfwzyytc']=0;

            if(empty($param['zk']))
                $param['zk']=null;

            if(empty($param['zkhjg']))
                $param['zkhjg']=null;

            if(empty($param['jg']))
                $param['jg']=null;

            $param['hospitalid']=session('hospitalid');
           // $param['delete_time']=['exp','is null'];
           //  $param['mcpym']=getfirstchar( $param['mc']);


            Db::startTrans();
            if (!empty($param['id'])) { //更新

              /*  $validate = new Validate([
                     //["mc","unique:tjtc_hd,mc={$param['mc']}&hospitalid=".session('hospitalid')."&delete_time is null,{$param['id']},id","体检套餐(".$param['mc'].")已存在",]
                    ["mc","unique:tjtc_hd,mc^hospitalid^delete_time,{$param['id']},id","体检套餐(".$param['mc'].")已存在",]
                ]);
                $result=$validate->check($param);*/

                $result=$this->where(['mc'=>$param['mc'],'hospitalid'=>session('hospitalid'),'id'=>['<>',$param['id']]])->count();

                if ($result>0) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' =>'套餐名称已经存在!'];

                } else {
                  //  unset($param['delete_time']);
                    $currtjtc= $this->where (['id' => $param['id'], 'hospitalid' =>$param['hospitalid']])->find();

                    //折扣没有审核


                    if ($currtjtc->zk != $param['zk'] || floatval($currtjtc->zkhjg) != floatval($param['zkhjg'])) {

                        if ($param['zk'] == null || $param['zkhjg'] == null ) {
                            Model('TjtcDtModel')->where(['hospitalid' => session('hospitalid'), 'tcid' => $param['id']])->setField('jg', null);
                            $param['sfsh'] = 0;
                            $currtjtc->update($param, ['id' => $param['id'], 'hospitalid' => $param['hospitalid']]);
                        }else {
                            $currtjtc->update($param, ['id' => $param['id'], 'hospitalid' => $param['hospitalid']]);
                            Db::execute('exec  SP_Tjtczk ' . session('hospitalid') . ',' . $param['id']);
                        }


                    }else{

                        $currtjtc->update($param, ['id' => $param['id'], 'hospitalid' => $param['hospitalid']]);

                    }

                    Db::commit();
                    writelog(session('uid'),session('username'),'用户【'.session('username').'】编辑个人套餐项目'.$param['mc'].'成功(ID='.$param['id'].')',1);
                    return ['code' => 2, 'data' =>$param, 'msg' => '编辑套餐项目' . $param['mc'] . '成功'];

                    }



            } else { //新增


                $id = $this->withTrashed('hospitalid',session('hospitalid'))->max('id');
                $param['id'] = empty($id) ? 1 : $id + 1;
                $param['softid'] = $param['id'];

                /*$validate = new Validate([
                     ["mc","unique:tjtc_hd,mc={$param['mc']}&hospitalid=".session('hospitalid'),"体检套餐(".$param['mc'].")已存在",]
                    //["mc","unique:tjtc_hd,mc^hospitalid={:session('hospitalid')}^delete_time","体检套餐(".$param['mc'].")已存在",]
                ]);
                //update不验证
                $result=$validate->check($param);*/
                $result=$this->where(['mc'=>$param['mc'],'hospitalid'=>session('hospitalid')])->count();

                if ($result>0) {
                    Db::rollback();
                    return ['code' => 0, 'data' => '', 'msg' => '套餐名称已经存在!'];
                } else {
                    unset($param['delete_time']);
                    $result = $this->save($param);  //insert 不验证
                    if (false === $result) {
                        Db::rollback();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】添加个人套餐项目'. $param['mc'].'失败(ID='.$param['id'].$this->getError().')',2);
                        return ['code' => 0, 'data' => '', 'msg' => $this->getError()];

                    } else {
                        Db::commit();
                        writelog(session('uid'),session('username'),'用户【'.session('username').'】添加个人套餐项目'. $param['mc'].'成功(ID='.$param['id'].')',1);
                        return ['code' => 1, 'data' => $param, 'msg' => '添加套餐项目' . $param['mc'] . '成功'];

                    }

                }

            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }

    /**
     *  delTjxm  删除组合体检项目
     * @param $id $name
     */
    public function delTjtc($id,$name)
    {
        Db::startTrans();
        try{

            //增加套餐判断是否被引用，如果被引用不可删除

            if(!empty(Model('TjdjModel')->where(['tjlb'=>0,'tcid'=>$id,'hospitalid'=>session('hospitalid')])->select())) {
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' =>'套餐已被体登记检引用不可删除'];
            }

           // $result=$this->where('id',$id)->setField('isdel',0);


            $result = $this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->find()->delete();

            if($result==false) {
                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除套餐项目' . $name . '失败(ID=' . $id . ')', 2);
                Db::rollback();
                return ['code' => 1, 'data' => '', 'msg' => '删除套餐项目失败'];
            }else{

                writelog(session('uid'), session('username'), '用户【' . session('username') . '】删除套餐项目' . $name . '成功(ID=' . $id . ')', 1);
                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '删除套餐项目成功'];
            }

        }catch( PDOException $e){
            Db::rollback();
            return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
        }
    }


    //调整套餐项目排序
        public function editSoft($id,$type,$targetid)
        {
            Db::startTrans();
            try{


                $softId=$this->where(['id'=>$id,'hospitalid'=>session('hospitalid')])->value('softid');

                $targerSoftId=$this->where(['id'=>$targetid,'hospitalid'=>session('hospitalid')])->value('softid');

                $map['hospitalid']=['=',session('hospitalid')];
               // $softId=$this->field('softid')->get($id);
               // $targerSoftId=$this->field('softid')->get($targetid);

               /* if ($softId >$targerSoftId)
                    $map['softid']=['between',$targerSoftId.','. $softId];
                else
                    $map['softid']=['between',$softId.','.$targerSoftId];

                //$map['softid']=['between','lt,gt'];
                */




                if ($type=="prev") {

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', $targerSoftId . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where(['id'=> $id,'hospitalid'=>session('hospitalid')])->setField('softid', $targerSoftId);
                    } else{
                        $map['softid']=['between',($softId+1).','.($targerSoftId-1)];
                        $this->where($map)->setDec('softid');
                        $this->where(['id'=> $id,'hospitalid'=>session('hospitalid')])->setField('softid', $targerSoftId-1);
                    }


                }else{

                    if ($softId >$targerSoftId)
                    {
                        $map['softid'] = ['between', ($targerSoftId+1) . ',' . ($softId-1)];
                        $this->where($map)->setInc('softid');
                        $this->where(['id'=> $id,'hospitalid'=>session('hospitalid')])->setField('softid', $targerSoftId+1);
                    } else{
                        $map['softid']=['between',($softId+1).','.$targerSoftId];
                        $this->where($map)->setDec('softid');
                        $this->where(['id'=> $id,'hospitalid'=>session('hospitalid')])->setField('softid', $targerSoftId);
                    }

                }

                Db::commit();
                return ['code' => 1, 'data' => '', 'msg' => '调整组合项目排序成功'];

            }catch( PDOException $e){
                Db::rollback();
                return ['code' => 0, 'data' => '', 'msg' => $e->getMessage()];
            }
        }
}