INSERT INTO [PEISCLOUDE].[dbo].[peis_TJXM]
           ([tjlxid]
           ,[xmlxid]
           ,[id]
           ,[mc]
           ,[pyjm]
           ,[wbjm]
           ,[dw]
           ,[ckxx]
           ,[cksx]
           ,[pgts]
           ,[pdts]
           ,[zcts]
           ,[xb]
           ,[softid]
           ,[jrxj]
           ,[status]
           ,[jglx]
           ,[sfdb]
           ,[isdel])
     VALUES
           (<tjlxid, int,>
           ,<xmlxid, int,>
           ,<id, int,>
           ,<mc, varchar(255),>
           ,<pyjm, varchar(100),>
           ,<wbjm, varchar(100),>
           ,<dw, varchar(20),>
           ,<ckxx, varchar(20),>
           ,<cksx, varchar(20),>
           ,<pgts, varchar(20),>
           ,<pdts, varchar(20),>
           ,<zcts, varchar(255),>
           ,<xb, char(1),>
           ,<softid, int,>
           ,<jrxj, tinyint,>
           ,<status, tinyint,>
           ,<jglx, tinyint,>
           ,<sfdb, tinyint,>
           ,<isdel, tinyint,>)
GO

