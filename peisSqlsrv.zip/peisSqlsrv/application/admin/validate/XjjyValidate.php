<?php

namespace app\admin\validate;

use think\Validate;

class XjjyValidate extends Validate
{
    protected $rule = [
        ['zyzd', 'require', '主要诊断不能为空'],
        ['jymc', 'require', '建议名称不能为空'],
       // ['code', 'require', '验证码不能为空']
    ];

}