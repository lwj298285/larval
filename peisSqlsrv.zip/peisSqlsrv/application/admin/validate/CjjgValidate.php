<?php

namespace app\admin\validate;

use think\Validate;

class CjjgValidate extends Validate
{
    protected $rule = [
        ['ms', 'require', '描述不能为空'],
	   
    ];

}