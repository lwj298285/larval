<?php

namespace app\admin\validate;

use think\Validate;

class UserValidate extends Validate
{
    protected $rule = [
       ['username','unique:admin','用户名已存在'],
	   ['email','unique:admin','邮件已被注册'],
	   ['mobile','unique:admin','手机号码已被注册']
    ];

}