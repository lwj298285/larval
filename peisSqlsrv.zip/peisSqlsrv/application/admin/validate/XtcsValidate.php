<?php
namespace app\admin\validate;
use think\Validate;
class XtcsValidate extends Validate
{
protected $rule=[
    [
    'mc', 'unique:param','系统参数名称已存在！'
]
];
}