<?php
namespace app\admin\validate;
use think\Validate;

class SgggValidate extends Validate
{
	protected $rule = [
		['lxname', 'unique:Tjjylx', '试管规格名称已经存在']
	];
}