<?php
namespace app\admin\validate;

use think\Validate;

class TjtcValidate extends Validate
{
	protected $rule = [
		['mc', 'unique:tjtc_hd', '套餐名称已经存在']
	];
}