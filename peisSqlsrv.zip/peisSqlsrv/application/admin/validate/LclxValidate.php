<?php

namespace app\admin\validate;
use think\Validate;

class LclxValidate extends Validate
{
    protected $rule = [
        ['lclxname', 'unique:lclx', '临床类型已经存在']
    ];

}