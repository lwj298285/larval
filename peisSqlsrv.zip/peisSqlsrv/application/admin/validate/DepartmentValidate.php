<?php

namespace app\admin\validate;

use think\Validate;

class DepartmentValidate extends Validate
{
    protected $rule = [
        ['depname', 'unique:department', '体检类型已经存在']
    ];

}