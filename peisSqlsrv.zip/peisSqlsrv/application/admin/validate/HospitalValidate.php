<?php

namespace app\admin\validate;

use think\Validate;

class HospitalValidate extends Validate
{
    protected $rule = [
        ['hospitalname', 'unique:hospital', '医院已经存在'],
		['email', 'unique:hospital', '此邮件已被注册'],
		['tel', 'unique:hospital', '此固话已被注册']
    ];

}