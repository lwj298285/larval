<?php

namespace app\admin\validate;
use think\Validate;

class FwhyValidate extends Validate
{
    protected $rule = [
        ['mc', 'unique:fwhy', '服务行业已经存在']
    ];

}