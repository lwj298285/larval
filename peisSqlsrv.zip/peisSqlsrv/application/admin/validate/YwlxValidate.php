<?php

namespace app\admin\validate;

use think\Validate;

class YwlxValidate extends Validate
{
    protected $rule = [
        ['mc', 'unique:ywlx', '体检业务类型已经存在'],

    ];

}