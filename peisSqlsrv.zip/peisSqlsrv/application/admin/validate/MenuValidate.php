<?php

namespace app\admin\validate;

use think\Validate;

class MenuValidate extends Validate
{
    protected $rule = [
       ['sort','^[1-9]\d*$','排序只能为正整数'],
	   
    ];

}