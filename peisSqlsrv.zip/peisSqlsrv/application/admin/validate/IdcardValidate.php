<?php

namespace app\admin\validate;

use think\Validate;

class IdcardValidate extends Validate
{
    protected $rule = [
       ['cardnum','unique:card','ID卡号已存在'],

    ];

}