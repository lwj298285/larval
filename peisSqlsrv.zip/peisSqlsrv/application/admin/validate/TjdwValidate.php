<?php
namespace app\admin\validate;
use think\Validate;

class TjdwValidate extends Validate
{
	protected $rule = [
		['dwname', 'unique:Tjdw', '单位名称已经存在']
	];
}