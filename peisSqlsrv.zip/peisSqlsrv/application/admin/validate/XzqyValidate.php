<?php

namespace app\admin\validate;
use think\Validate;

class XzqyValidate extends Validate
{
    protected $rule = [
        ['name', 'unique:region', '区域名称已存在']
    ];

}