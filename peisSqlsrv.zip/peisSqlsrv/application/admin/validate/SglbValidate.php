<?php
namespace app\admin\validate;
use think\Validate;

class SglbValidate extends Validate
{
	protected $rule = [
		['lxname', 'unique:Tjjylx', '试管类别名称已经存在']
	];
}