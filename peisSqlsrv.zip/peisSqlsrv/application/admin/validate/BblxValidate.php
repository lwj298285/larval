<?php
namespace app\admin\validate;
use think\Validate;

class BblxValidate extends Validate
{
	protected $rule = [
		['bblxname', 'unique:Tjbblx', '标本类型已经存在']
	];
}