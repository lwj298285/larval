<?php
namespace app\admin\validate;
use think\Validate;

class JylxValidate extends Validate
{
	protected $rule = [
		['lxname', 'unique:Tjjylx', '检验类型名称已经存在']
	];
}