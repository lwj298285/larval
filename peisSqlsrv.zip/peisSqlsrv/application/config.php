<?php

return [



    'auto_start'   => true,
    'url_route_on' => true,

    //错误错误不存在页面404跳转
    // 异常页面的模板文件
    'exception_tmpl'         => THINK_PATH . 'tpl' . DS . 'think_exception.tpl',
    //'exception_tmpl'         => THINK_PATH . 'tpl' . DS . '404.html', 
    // 错误显示信息,非调试模式有效
    'error_message'          => '页面错误！请稍后再试～',
    // 显示错误信息
    'show_error_msg'         => false,
    // 异常处理handle类 留空使用 \think\exception\Handle
    'exception_handle'       => '',

    'url_route_on' => true,
    'app_trace' =>  false,// 开启应用Trace调试
    'trace' => [
        'type' => 'html',// 在当前Html页面显示Trace信息,显示方式console、html
    ],
    'sql_explain' => true,// 是否需要进行SQL性能分析
    'extra_config_list' => ['database', 'route', 'validate'],//各模块公用配置

    //日志写入

    'log'                    => [
        // 日志记录方式，内置 file socket 支持扩展
        'type'  => 'file', //test 没有日志记录
        // 日志保存目录
        'path'  => LOG_PATH,
        // 日志记录级别
        'level' => [],
    ],

    'app_debug' =>true,
    'default_module' => 'admin',//默认模块
    'default_filter' => 'trim,strip_tags,htmlspecialchars',


    // +----------------------------------------------------------------------
    // | 缓存设置
    // +----------------------------------------------------------------------
    'cache' =>  [
        // 使用复合缓存类型
        'type'  =>  'complex',
        // 默认使用的缓存
        'default'   =>  [
            // 驱动方式
            'type'   => 'File',
            // 缓存保存目录
            'path'   => CACHE_PATH,
        ],
        // 文件缓存
        'file'   =>  [
            // 驱动方式
            'type'   => 'file',
            // 设置不同的缓存保存目录
            'path'   => RUNTIME_PATH . 'file/',
        ],
        // redis缓存
        'redis'   =>  [
            // 驱动方式
            'type'   => 'redis',
            // 服务器地址
            'host'       => '127.0.0.1',
        ],
    ],
    // 默认全局过滤方法 用逗号分隔多个


    // +----------------------------------------------------------------------
    // | 缓存设置
    // +----------------------------------------------------------------------
    'auth_key' => 'JUD6FCtZsqrmVXc2apev4TRn3O8gAhxbSlH9wfPN', //默认数据加密KEY
    'pages'    => '10',//分页数
    'salt'     => 'wZPb~yxvA!ir38&Z',//加密串


    // +----------------------------------------------------------------------
    // | 数据库设置
    // +----------------------------------------------------------------------
    'data_backup_path'     => '../data/',   //数据库备份路径必须以 / 结尾；
    'data_backup_part_size' => '20971520',  //该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M
    'data_backup_compress' => '1',          //压缩备份文件需要PHP环境支持gzopen,gzwrite函数        0:不压缩 1:启用压缩
    'data_backup_compress_level' => '9',    //压缩级别   1:普通   4:一般   9:最高


    // +----------------------------------------------------------------------
    // | 极验验证,请到官网申请ID和KEY，http://www.geetest.com/
    // +----------------------------------------------------------------------
    'verify_type' =>true,   //验证码类型：0无验证， 1数字验证码
    'gee_id'  => 'ca1219b1ba907a733eaadfc3f6595fad',
    'gee_key' => '9977de876b194d227b2209df142c92a0',
    'MOBILE_HEAD'=>'18|15|13|14|17',


    //忘记密码重置密码找回方式 email(邮件方式)  mobile(手机方式）
    'forgetpwd'=>'mobile',
    //发送邮件初始设置 邮件服务器 端口  管理员邮箱  密码
    'smtp_host'=>'smtp.qq.com',
    'smtp_port'=>'465',
    'smtp_addr'=>'343697406@qq.com',
    'smtp_pass'=>'2351624an_mas',
    'content_type'=>'text/html',

    //短信设置
    'sms'=>['url'=>'http://203.81.21.34/send/gsend.asp?','name'=>'jmzmxdt','pwd'=>'2351624mas','aliax'=>'[深圳九明珠]'],

    //字典类型
    'zdlx'=>['QYXZ'=>'企业性质','JCJYLX'=>'检查检验类型','HYZK'=>'婚姻状况','ZZGX'=>'政治关系','BXLB'=>'病性类别','RYLB'=>'人员类别','MZ'=>'民族','NLDW'=>'年龄单位','LQFS'=>'领取方式','SGGG'=>'试管规格','SGLB'=>'试管类别','BBLX'=>'标本类型','BBFL'=>'报表分类'],

    //体重 身高  血压 项目ID
    'xmid'=>['TZID'=>11,'SGID'=>12,'XYID'=>13,'SSYID'=>15,'SZYID'=>16,'BMIID'=>17,'SLZID'=>18,'SLYID'=>19],




];