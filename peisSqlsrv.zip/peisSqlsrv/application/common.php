<?php
use taobao\AliSms;
use think\Config;

    function arrToOne($multi) {
        $arr = array();
        foreach ($multi as $key => $val) {
            if( is_array($val) ) {
                $arr = array_merge($arr, arrToOne($val));
            } else {
                $arr[] = $val;
            }
        }
        return $arr;
    }

	/**
	 * 字符串截取，支持中文和其他编码
	 */
	function msubstr($str, $start = 0, $length, $charset = "utf-8", $suffix = true) {
		if (function_exists("mb_substr"))
			$slice = mb_substr($str, $start, $length, $charset);
		elseif (function_exists('iconv_substr')) {
			$slice = iconv_substr($str, $start, $length, $charset);
			if (false === $slice) {
				$slice = '';
			}
		} else {
			$re['utf-8'] = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
			$re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
			$re['gbk'] = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
			$re['big5'] = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
			preg_match_all($re[$charset], $str, $match);
			$slice = join("", array_slice($match[0], $start, $length));
		}
		return $suffix ? $slice . '...' : $slice;
	}


	//在1-20间随机产生12个不重复的值
	 
 //生成随机码
    function generateWeirdStr($var){
		$table='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		$len=rand($var,$var);
		$text='';
		for($i=0;$i<$len;$i++){
			$ch=$table[rand(0,61)];
			$text.=$ch;
		}
		return $text;
}


/*
 * get_json_emlement 获取的JSON文件
* @access public 表示函数对外公开
* @param $_xmlfile xml文件
* $_html 从JSON中取出的数据数组
* */
function get_json_emlement($_jsonfile,$index,$maintag){
	$_html = array();
	if(file_exists(APP_PATH.$_jsonfile)){
		$dicData= json_decode(file_get_contents(APP_PATH.$_jsonfile), true);
		/*$dicdeptype=$dicData[0][$maintag][0]['$salvetag'];
		$dicShoWranger=$dicData[0]['department'][1]['showranger'];
		$dicShowtable=$dicData[0]['department'][2]['showtable'];
		$dicNoduleModel=$dicData[0]['department'][3]['nodulemodel'];*/
		

		$_html=$dicData[$index][$maintag];
		
		
		
		
	}else{
	   _alert_back("文件不存在");
	}
	return  $_html;
}


/*
 * _set_xml将信息写入XML文件
* @access public 表示函数对外公开
* @param $_xmlfile xml文件
* @param $_clean 要写入的信息的数组
* */
function _set_xml($_xmlfile,$_clean){
	$_fp = @fopen('newuser.xml','w');
	if(!$_fp){
		exit('系统错误，文件不存在！');
	}
	flock($_fp,LOCK_EX);
	$_string = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "<vip>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "\t<id>{$_clean['id']}</id>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "\t<username>{$_clean['username']}</username>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "\t<sex>{$_clean['sex']}</sex>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "\t<face>{$_clean['face']}</face>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "\t<email>{$_clean['email']}</email>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "\t<qq>{$_clean['url']}</qq>\r\t";
	fwrite($_fp, $_string,strlen($_string));
	$_string = "</vip>";
	fwrite($_fp, $_string,strlen($_string));
	flock($_fp,LOCK_UN);
	fclose($_fp);
}


/**
* 验证手机号是否正确
* @author 李勇
* @param INT $mobile
移动：134、135、136、137、138、139、150、151、152、157、158、159、182、183、184、187、188、178(4G)、147(上网卡)；

联通：130、131、132、155、156、185、186、176(4G)、145(上网卡)；

电信：133、153、180、181、189 、177(4G)；

卫星通信：1349

虚拟运营商：170
*/
function check_mobile($mobile) {
    if (!is_numeric($mobile)) {
        return false;
    }
    return preg_match('#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#', $mobile) ? true : false;
 }
//国家标准检验身份证是否有效
function is_idcard($id) 
{ 
  $id = strtoupper($id); 
  $regx = "/(^\d{15}$)|(^\d{17}([0-9]|X)$)/"; 
  $arr_split = array(); 
  if(!preg_match($regx, $id)) 
  { 
    return FALSE; 
  } 
  if(15==strlen($id)) //检查15位 
  { 
    $regx = "/^(\d{6})+(\d{2})+(\d{2})+(\d{2})+(\d{3})$/"; 
  
    @preg_match($regx, $id, $arr_split); 
    //检查生日日期是否正确 
    $dtm_birth = "19".$arr_split[2] . '/' . $arr_split[3]. '/' .$arr_split[4]; 
    if(!strtotime($dtm_birth)) 
    { 
      return FALSE; 
    } else { 
      return TRUE; 
    } 
  } 
  else      //检查18位 
  { 
    $regx = "/^(\d{6})+(\d{4})+(\d{2})+(\d{2})+(\d{3})([0-9]|X)$/"; 
    @preg_match($regx, $id, $arr_split); 
    $dtm_birth = $arr_split[2] . '/' . $arr_split[3]. '/' .$arr_split[4]; 
    if(!strtotime($dtm_birth)) //检查生日日期是否正确 
    { 
      return FALSE; 
    } 
    else
    { 
      //检验18位身份证的校验码是否正确。 
      //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。 
      $arr_int = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2); 
      $arr_ch = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'); 
      $sign = 0; 
      for ( $i = 0; $i < 17; $i++ ) 
      { 
        $b = (int) $id{$i}; 
        $w = $arr_int[$i]; 
        $sign += $b * $w; 
      } 
      $n = $sign % 11; 
      $val_num = $arr_ch[$n]; 
      if ($val_num != substr($id,17, 1)) 
      { 
        return FALSE; 
      } //phpfensi.com 
      else
      { 
        return TRUE; 
      } 
    } 
  } 
  
}


//函数encrypt($string,$operation,$key)中$string：需要加密解密的字符串；$operation：判断是加密还是解密，E表示加密，D表示解密；$key：密匙。
function encrypt($string,$operation,$key=''){
    $key=md5(config('auth_key'));
    $key_length=strlen($key);
    $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;
    $string_length=strlen($string);
    $rndkey=$box=array();
    $result='';
    for($i=0;$i<=255;$i++){
        $rndkey[$i]=ord($key[$i%$key_length]);
        $box[$i]=$i;
    }
    for($j=$i=0;$i<256;$i++){
        $j=($j+$box[$i]+$rndkey[$i])%256;
        $tmp=$box[$i];
        $box[$i]=$box[$j];
        $box[$j]=$tmp;
    }
    for($a=$j=$i=0;$i<$string_length;$i++){
        $a=($a+1)%256;
        $j=($j+$box[$a])%256;
        $tmp=$box[$a];
        $box[$a]=$box[$j];
        $box[$j]=$tmp;
        $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
    }
    if($operation=='D'){
        if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8)){
            return substr($result,8);
        }else{
            return'';
        }
    }else{
        return str_replace('=','',base64_encode($result));
    }
}



//添在字符串前面添加知道字符操作
function addZero($len,$str,$addstr){

    //$lenstr=strleb($str);
   // $lenzero=$len-$lenstr;
   return str_pad($str,$len, $addstr, STR_PAD_LEFT);


}
//将 输入控件下 换行符转为html 换行符
function textAreaStr($str)
{
    if ($str) {
        $pattern = array(
            //'/ /',//半角下空格
            //'/　/',//全角下空格
            '/\r\n/',//window 下换行符
            '/\n/',//Linux && Unix 下换行符
        );
        //$replace = array('&nbsp;','&nbsp;','<br/>','<br/>');
        $replace = array('<br/>', '<br/>');
        return preg_replace($pattern, $replace, $str);
    }
}

    /**
     * @name linq and 实现
     * @param array $socure
     * @param array $condition key: $socure中的key value: 和$socure中相对应的值相比较 全部为真才为真
     * @return multitype:|boolean
     */
    function arrWhereAnd($socure, array $condition)
    {

        return array_filter($socure, function ($value) use ($condition) {
            $re = true;
            foreach ($condition as $k => $v) {
                if (!isset($value[$k]) || $value[$k] != $v) {
                    $re = false;
                    break;
                }
            }
            return $re;
        });
    }


    function arrWhereBitwise($socure, array $condition)
    {

        return array_filter($socure, function ($value) use ($condition) {
            $re = true;
            foreach ($condition as $k => $v) {
                if (($value[$k] & $v) > 0) {
                    $re = false;
                    break;
                }
            }
            return $re;
        });
    }

    /**
     * @name linq or 实现
     * @param array $socure
     * @param array $condition key: $socure中的key value: 和$socure中相对应的值相比较 存在为真就为真
     * @return multitype:|boolean
     */
    function arrWhereOr($socure, array $condition)
    {

        return array_filter($socure, function ($value) use ($condition) {
            $re = false;
            foreach ($condition as $k => $v) {
                if ($value[$k] == $v) {
                    $re = true;
                    break;
                }
            }
            return $re;
        });
    }

 //1、 arrWhereAnd是通过array_filter 的特性，然后匹配$condition 这个数组中的键值对，将$condition 中的所有键值通过&&筛选返回针对源数组筛选之后的结果。

//2、arrWhereBitwise是将$conditon 中的键值对通过按位与的方式确定筛选结果

//3、arrWhereOr是将$condtion 中的键值对通过|| 筛选确定筛选结果。


/** php 发送流文件
 * @param  String  $url  接收的路径
 * @param  String  $file 要发送的文件
 * @return boolean
 */
function sendStreamFile($url, $file){

    if(file_exists($file)){

        $opts = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'content-type:application/x-www-form-urlencoded',
                'content' => file_get_contents($file)
            )
        );

        $context = stream_context_create($opts);
        $response = file_get_contents($url, false, $context);
        $ret = json_decode($response, true);
        return $ret['success'];

    }else{
        return false;
    }

}

//$ret = sendStreamFile('http://localhost/fdipzone/receiveStreamFile.php', 'send.txt');
//var_dump($ret);


//receiveStreamFile.php
//[php] view plain copy

/** php 接收流文件
 * @param  String  $file 接收后保存的文件名
 * @return boolean
 */
function receiveStreamFile($receiveFile){

    $streamData = isset($GLOBALS['HTTP_RAW_POST_DATA'])? $GLOBALS['HTTP_RAW_POST_DATA'] : '';

    if(empty($streamData)){
        $streamData = file_get_contents('php://input');
    }

    if($streamData!=''){
        $ret = file_put_contents($receiveFile, $streamData, true);
    }else{
        $ret = false;
    }

    return $ret;

}

//$receiveFile = 'receive.txt';
//$ret = receiveStreamFile($receiveFile);
//echo json_encode(array('success'=>(bool)$ret));





//计算年龄
function datediffage($before, $after) {
   // return $before.'-'.$after;

    if ($before>$after) {
        $b = getdate((int)$after);
        $a = getdate((int)$before);
    }
    else {
        $b = getdate((int)$before);
        $a = getdate((int)$after);
    }
    return $a['mday'].'-'.$b['mday'];

    $n = array(1=>31,2=>28,3=>31,4=>30,5=>31,6=>30,7=>31,8=>31,9=>30,10=>31,11=>30,12=>31);
    $y=$m=$d=0;
    if ($a['mday']>=$b['mday']) { //天相减为正
        if ($a['mon']>=$b['mon']) {//月相减为正
            $y=$a['year']-$b['year'];$m=$a['mon']-$b['mon'];
        }
        else { //月相减为负，借年
            $y=$a['year']-$b['year']-1;$m=$a['mon']-$b['mon']+12;
        }
        $d=$a['mday']-$b['mday'];
    }
    else {  //天相减为负，借月
        if ($a['mon']==1) { //1月，借年
            $y=$a['year']-$b['year']-1;$m=$a['mon']-$b['mon']+12;$d=$a['mday']-$b['mday']+$n[12];
        }
        else {
            if ($a['mon']==3) { //3月，判断闰年取得2月天数
                $d=$a['mday']-$b['mday']+($a['year']%4==0?29:28);
            }
            else {
                $d=$a['mday']-$b['mday']+$n[$a['mon']-1];
            }
            if ($a['mon']>=$b['mon']+1) { //借月后，月相减为正
                $y=$a['year']-$b['year'];$m=$a['mon']-$b['mon']-1;
            }
            else { //借月后，月相减为负，借年
                $y=$a['year']-$b['year']-1;$m=$a['mon']-$b['mon']+12-1;
            }
        }
    }




    if($y!=0)
        return $y;//['nl'=>$y,'dw'=>'岁'];

    if ($m!=0)
        return $m; // ['nl'=>$m,'dw'=>'月'];

    if ($d!==0)
        return $d;//['nl'=>$d,'dw'=>'天'];
    //return ($y==0?'':$y.'岁').($m==0?'':$m.'个月').($d==0?'':$d.'天');
}


function pdfToJpg($pdfFile,$jpgFile,$savePath){

//make sure that apache has permissions to write in this folder!
//(common problem)

//execute ImageMagick command 'convert' and convert PDF
//to JPG with applied settings
exec('convert "'.$pdfFile.'" -colorspace RGB -resize 800 "'.$jpgFile.'"', $output, $return_var);

if($return_var == 0)
    print "Conversion OK";
else
    print "Conversion failed.".$output;

}

?>
